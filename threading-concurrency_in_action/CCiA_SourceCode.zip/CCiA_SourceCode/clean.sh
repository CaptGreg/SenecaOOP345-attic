for f in *.cpp 
do
  b=`basename $f .cpp`
  if test -f $b ; then
    rm $b
  fi
done

for f in *.c 
do
  b=`basename $f .c`
  if test -f $b ; then
    rm $b
  fi
done
