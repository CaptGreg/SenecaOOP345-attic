for f in *.cpp 
do
  b=`basename $f .cpp`
  if !(test -x $b) ; then
    clang++ -std=c++11 -pthread $b.cpp -o  $b
  fi
done
