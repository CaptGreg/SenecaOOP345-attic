#include <stdio.h>
#include "cfun.h"

void cfun()
{
    printf("c-code function cfun\n");
    
    // printf("c-code cfun: calling c++ cppFun\n");
    // cppFun();
    // printf("c-code cfun: cppFun returned\n");
}
