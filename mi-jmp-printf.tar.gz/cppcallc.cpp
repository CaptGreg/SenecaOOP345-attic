#include <iostream>

#include "cfun.h"

// extern "C" { void cfun(); }

// void cfun();

int main(int argc, char**argv)
{
    std::cout << "cpp code: calling c-code\n";

    cfun();

    std::cout << "cpp code: c-code returned\n";
}
