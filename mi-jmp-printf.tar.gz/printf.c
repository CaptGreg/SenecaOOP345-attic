#include <stdio.h>

void myFunc();
void myFunc()
{
}


int main(int argc, char **argv)
{
	printf("Hi there\n");
	myFunc();
}

