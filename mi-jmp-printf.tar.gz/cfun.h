#pragma once



#ifdef __cplusplus
extern "C" {
#endif

extern void cfun(); 

#ifdef __cplusplus
}
#endif
