#include <iostream>
#include <boost/version.hpp>

int main() {
    std::cout << "Boost version: " << BOOST_VERSION << std::endl;
}
