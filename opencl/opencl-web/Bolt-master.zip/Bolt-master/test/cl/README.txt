############################################################################                                                                                     
#   � 2012,2014 Advanced Micro Devices, Inc. All rights reserved.                                     
#                                                                                    
#   Licensed under the Apache License, Version 2.0 (the "License");   
#   you may not use this file except in compliance with the License.                 
#   You may obtain a copy of the License at                                          
#                                                                                    
#       http://www.apache.org/licenses/LICENSE-2.0                      
#                                                                                    
#   Unless required by applicable law or agreed to in writing, software              
#   distributed under the License is distributed on an "AS IS" BASIS,              
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.         
#   See the License for the specific language governing permissions and              
#   limitations under the License.                                                   

############################################################################                                                                                     

* Need to install the OpenCL 1.2 Preview, which includes support for C++ Static Kernel Language and new C++ Wrapper API.
* Document:
[ ] How to use BOLT_FUNCTOR
[ ] How to use DEFINE_TYPENAME
[ ] How to use #include files to define functor.


TODO:
* Move code from "reader.cpp" to bolt.lib file.
* Need a default CPU path if OpenCL is not available.
