#ifndef THRUST_SORT_HPP
#define THRUST_SORT_HPP

template <typename T>
void thrust_sort(T *begin, T *end);

#endif
