How to Run Independent sample
=============================

    1. Set AMDAPPSDKSAMPLESROOT to unzipped folder
    2. Move to sample folder.  Ex : samples/opencl/cl/app/Reduction
    3. use make or .sln file to build sample


Note : It is assumed that AMD APP SDK developer package installed already. Please install, If it is not installed.