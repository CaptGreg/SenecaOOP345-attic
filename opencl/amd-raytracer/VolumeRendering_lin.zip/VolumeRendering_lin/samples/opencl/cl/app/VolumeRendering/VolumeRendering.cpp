/* ============================================================

Copyright (c) 2009 Advanced Micro Devices, Inc.  All rights reserved.

Redistribution and use of this material is permitted under the following 
conditions:

Redistributions must retain the above copyright notice and all terms of this 
license.

In no event shall anyone redistributing or accessing or using this material 
commence or participate in any arbitration or legal action relating to this 
material against Advanced Micro Devices, Inc. or any copyright holders or 
contributors. The foregoing shall survive any expiration or termination of 
this license or any agreement or access or use related to this material. 

ANY BREACH OF ANY TERM OF THIS LICENSE SHALL RESULT IN THE IMMEDIATE REVOCATION 
OF ALL RIGHTS TO REDISTRIBUTE, ACCESS OR USE THIS MATERIAL.

THIS MATERIAL IS PROVIDED BY ADVANCED MICRO DEVICES, INC. AND ANY COPYRIGHT 
HOLDERS AND CONTRIBUTORS "AS IS" IN ITS CURRENT CONDITION AND WITHOUT ANY 
REPRESENTATIONS, GUARANTEE, OR WARRANTY OF ANY KIND OR IN ANY WAY RELATED TO 
SUPPORT, INDEMNITY, ERROR FREE OR UNINTERRUPTED OPERA TION, OR THAT IT IS FREE 
FROM DEFECTS OR VIRUSES.  ALL OBLIGATIONS ARE HEREBY DISCLAIMED - WHETHER 
EXPRESS, IMPLIED, OR STATUTORY - INCLUDING, BUT NOT LIMITED TO, ANY IMPLIED 
WARRANTIES OF TITLE, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, 
ACCURACY, COMPLETENESS, OPERABILITY, QUALITY OF SERVICE, OR NON-INFRINGEMENT. 
IN NO EVENT SHALL ADVANCED MICRO DEVICES, INC. OR ANY COPYRIGHT HOLDERS OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, PUNITIVE,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, REVENUE, DATA, OR PROFITS; OR 
BUSINESS INTERRUPTION) HOWEVER CAUSED OR BASED ON ANY THEORY OF LIABILITY 
ARISING IN ANY WAY RELATED TO THIS MATERIAL, EVEN IF ADVISED OF THE POSSIBILITY 
OF SUCH DAMAGE. THE ENTIRE AND AGGREGATE LIABILITY OF ADVANCED MICRO DEVICES, 
INC. AND ANY COPYRIGHT HOLDERS AND CONTRIBUTORS SHALL NOT EXCEED TEN DOLLARS 
(US $10.00). ANYONE REDISTRIBUTING OR ACCESSING OR USING THIS MATERIAL ACCEPTS 
THIS ALLOCATION OF RISK AND AGREES TO RELEASE ADVANCED MICRO DEVICES, INC. AND 
ANY COPYRIGHT HOLDERS AND CONTRIBUTORS FROM ANY AND ALL LIABILITIES, 
OBLIGATIONS, CLAIMS, OR DEMANDS IN EXCESS OF TEN DOLLARS (US $10.00). THE 
FOREGOING ARE ESSENTIAL TERMS OF THIS LICENSE AND, IF ANY OF THESE TERMS ARE 
CONSTRUED AS UNENFORCEABLE, FAIL IN ESSENTIAL PURPOSE, OR BECOME VOID OR 
DETRIMENTAL TO ADVANCED MICRO DEVICES, INC. OR ANY COPYRIGHT HOLDERS OR 
CONTRIBUTORS FOR ANY REASON, THEN ALL RIGHTS TO REDISTRIBUTE, ACCESS OR USE 
THIS MATERIAL SHALL TERMINATE IMMEDIATELY. MOREOVER, THE FOREGOING SHALL 
SURVIVE ANY EXPIRATION OR TERMINATION OF THIS LICENSE OR ANY AGREEMENT OR 
ACCESS OR USE RELATED TO THIS MATERIAL.

NOTICE IS HEREBY PROVIDED, AND BY REDISTRIBUTING OR ACCESSING OR USING THIS 
MATERIAL SUCH NOTICE IS ACKNOWLEDGED, THAT THIS MATERIAL MAY BE SUBJECT TO 
RESTRICTIONS UNDER THE LAWS AND REGULATIONS OF THE UNITED STATES OR OTHER 
COUNTRIES, WHICH INCLUDE BUT ARE NOT LIMITED TO, U.S. EXPORT CONTROL LAWS SUCH 
AS THE EXPORT ADMINISTRATION REGULATIONS AND NATIONAL SECURITY CONTROLS AS 
DEFINED THEREUNDER, AS WELL AS STATE DEPARTMENT CONTROLS UNDER THE U.S. 
MUNITIONS LIST. THIS MATERIAL MAY NOT BE USED, RELEASED, TRANSFERRED, IMPORTED,
EXPORTED AND/OR RE-EXPORTED IN ANY MANNER PROHIBITED UNDER ANY APPLICABLE LAWS, 
INCLUDING U.S. EXPORT CONTROL LAWS REGARDING SPECIFICALLY DESIGNATED PERSONS, 
COUNTRIES AND NATIONALS OF COUNTRIES SUBJECT TO NATIONAL SECURITY CONTROLS. 
MOREOVER, THE FOREGOING SHALL SURVIVE ANY EXPIRATION OR TERMINATION OF ANY 
LICENSE OR AGREEMENT OR ACCESS OR USE RELATED TO THIS MATERIAL.

NOTICE REGARDING THE U.S. GOVERNMENT AND DOD AGENCIES: This material is 
provided with "RESTRICTED RIGHTS" and/or "LIMITED RIGHTS" as applicable to 
computer software and technical data, respectively. Use, duplication, 
distribution or disclosure by the U.S. Government and/or DOD agencies is 
subject to the full extent of restrictions in all applicable regulations, 
including those found at FAR52.227 and DFARS252.227 et seq. and any successor 
regulations thereof. Use of this material by the U.S. Government and/or DOD 
agencies is acknowledgment of the proprietary rights of any copyright holders 
and contributors, including those of Advanced Micro Devices, Inc., as well as 
the provisions of FAR52.227-14 through 23 regarding privately developed and/or 
commercial computer software.

This license forms the entire agreement regarding the subject matter hereof and 
supersedes all proposals and prior discussions and writings between the parties 
with respect thereto. This license does not affect any ownership, rights, title,
or interest in, or relating to, this material. No terms of this license can be 
modified or waived, and no breach of this license can be excused, unless done 
so in a writing signed by all affected parties. Each term of this license is 
separately enforceable. If any term of this license is determined to be or 
becomes unenforceable or illegal, such term shall be reformed to the minimum 
extent necessary in order for this license to remain in effect in accordance 
with its terms as modified by such reformation. This license shall be governed 
by and construed in accordance with the laws of the State of Texas without 
regard to rules on conflicts of law of any state or jurisdiction or the United 
Nations Convention on the International Sale of Goods. All disputes arising out 
of this license shall be subject to the jurisdiction of the federal and state 
courts in Austin, Texas, and all defenses are hereby waived concerning personal 
jurisdiction and venue of these courts.

============================================================ */


#include "VolumeRendering.hpp"
#include <cmath>

#ifndef _WIN32
#include <GL/glx.h>
#endif //!_WIN32

#ifdef _WIN32
static HWND               gHwnd;
HDC                       gHdc;
HGLRC					  gGlCtx;
BOOL quit = FALSE;
MSG msg;
#else 
GLXContext gGlCtx;
#endif

#ifdef _WIN32 
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
        
    case WM_CREATE:
        return 0;
        
    case WM_CLOSE:
        PostQuitMessage( 0 );
        return 0;
        
    case WM_DESTROY:

        return 0;
        

    case WM_LBUTTONUP:
        buttonState = 0;
        return 0;
    case WM_LBUTTONDOWN:
        ox = LOWORD(lParam);
        oy = HIWORD(lParam);
        buttonState = 1;
        return 0;
    
    case WM_MOUSEMOVE:
        int x,y;
        x = LOWORD(lParam);
        y = HIWORD(lParam);
        int dx, dy;
        dx = x - ox;
        dy = y - oy;
        if (buttonState) 
        {
            // left = rotate
            rotation[0] += (float)(dy / 5.0);
            rotation[1] += (float)(dx / 5.0);
        }
        ox = x; 
        oy = y;
        return 0;

    case WM_KEYDOWN:
        switch ( wParam )
        {
            
        case VK_ESCAPE:
            PostQuitMessage(0);
            return 0;
        case VK_OEM_4: // '['
            steps += 10;
            break;
        case VK_OEM_6:// ']'
            steps -= 10;
            break;
        case 0x5A://'Z'
            step_size += 0.0001f;
            steps = (int)((1.414 + fabs(dis)) / step_size);
            break;
        case 0x58://'X'
            step_size -= 0.0001f;
            steps = (int)((1.414 + fabs(dis)) / step_size);
            break;
        case 0x41://'A'
            linear_ramp_slope -= 0.002f;
            break;
        case 0x53://'S'
            linear_ramp_slope -= 0.002f;
            break;
        case 0x43://'C'
            linear_ramp_constant += 0.003f;
            break;
        case 0x56://'V'
            linear_ramp_constant -= 0.003f;
            break;
        case 0x42: //'B'
            threshold += 0.001f;
            break;
        case 0x4E://'N'
            threshold -= 0.001f;
            break;
        case 0x45://'E'
            dis += (float)0.01;
            steps = (int)((1.414 + fabs(dis)) / step_size);
            break;
        case 0x52://'R'
            dis -= (float)0.01;
            steps = (int)((1.414 + fabs(dis)) / step_size);
            break;
        case 0x50://'P'
            printf("Steps : %d\nstep_size : %f\nlinear_ramp_slope : %f\nlinear_ramp_constant : %f\n"
               "threshold : %f\ndistance : %f\n", steps, step_size, linear_ramp_slope, linear_ramp_constant,
                threshold, dis);
            break;

        default: 
            break;
        }
        return 0;
    
    default:
        return DefWindowProc( hWnd, message, wParam, lParam );
            
    }
}
#endif

int 
VolumeRendering::loadRAWData()
{
    FILE *fp = NULL;

    std::string filePath = sampleCommon->getPath() + std::string("aneurism.raw"); 
#if defined (_WIN32) && !defined(__MINGW32__)
    errno_t error;
    if((error = fopen_s(&fp, filePath.c_str(), "rb")) != 0)
#else
    if((fp = fopen(filePath.c_str(), "rb")) == NULL) 
#endif
    {
        sampleCommon->error("Failed to load volume data!");
        return SDK_FAILURE;
    }

    for(cl_uint n = 0; n < width * height * slices; n++)
    {
        //Read a byte from file
        DATATYPE temp;
        size_t read = fread(&temp, sizeof(DATATYPE), 1, fp);

        //Write a byte to inputVolumeData
        inputVolumeData[n] = temp;
    }
                            

    if(ferror(fp))
    {
        std::cout << "Error in reading file!\n";
        return SDK_FAILURE;
    }

    //imdebug("lum b=16 w=%d h=%d %p", width, height, inputVolumeData + pos);

    fclose(fp);
    return SDK_SUCCESS;
}

int
VolumeRendering::loadVolumeData()
{
    // Voxel count
    size_t count = width * height * slices;

    inputVolumeData = (DATATYPE*)malloc(count * sizeof(DATATYPE));
    /* error check */
    if(inputVolumeData == NULL)
    {
        sampleCommon->error("Failed to allocate memory! (inputVolumeData)");
        return SDK_FAILURE;
    }
    memset(inputVolumeData, 0, count * sizeof(DATATYPE));

    loadRAWData();

    return SDK_SUCCESS;

}

#ifdef _WIN32
int
VolumeRendering::enableGLAndGetGLContext(HWND hWnd, HDC &hDC, HGLRC &hRC, cl_platform_id platform, cl_context &context, cl_device_id &interopDevice)
{
    cl_int status;
    BOOL ret = FALSE;
    DISPLAY_DEVICE dispDevice;
    DWORD deviceNum;
    int  pfmt;
    PIXELFORMATDESCRIPTOR  pfd; 
    pfd.nSize           = sizeof(PIXELFORMATDESCRIPTOR); 
    pfd.nVersion        = 1; 
    pfd.dwFlags         = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL  | PFD_DOUBLEBUFFER ;
    pfd.iPixelType      = PFD_TYPE_RGBA; 
    pfd.cColorBits      = 24; 
    pfd.cRedBits        = 8; 
    pfd.cRedShift       = 0; 
    pfd.cGreenBits      = 8; 
    pfd.cGreenShift     = 0; 
    pfd.cBlueBits       = 8; 
    pfd.cBlueShift      = 0; 
    pfd.cAlphaBits      = 8;
    pfd.cAlphaShift     = 0; 
    pfd.cAccumBits      = 0; 
    pfd.cAccumRedBits   = 0; 
    pfd.cAccumGreenBits = 0; 
    pfd.cAccumBlueBits  = 0; 
    pfd.cAccumAlphaBits = 0; 
    pfd.cDepthBits      = 24; 
    pfd.cStencilBits    = 8; 
    pfd.cAuxBuffers     = 0; 
    pfd.iLayerType      = PFD_MAIN_PLANE;
    pfd.bReserved       = 0; 
    pfd.dwLayerMask     = 0;
    pfd.dwVisibleMask   = 0; 
    pfd.dwDamageMask    = 0;

    ZeroMemory(&pfd, sizeof(PIXELFORMATDESCRIPTOR));

    dispDevice.cb = sizeof(DISPLAY_DEVICE);

    DWORD displayDevices = 0;
    DWORD connectedDisplays = 0;
    int xCoordinate = 0;
    int yCoordinate = 0;
    int xCoordinate1 = 0;

    for (deviceNum = 0; EnumDisplayDevices(NULL, deviceNum, &dispDevice, 0); deviceNum++) 
    {
        if (dispDevice.StateFlags & DISPLAY_DEVICE_MIRRORING_DRIVER) 
        {
                continue;
        }

        DEVMODE deviceMode;
        
        EnumDisplaySettings(dispDevice.DeviceName, ENUM_CURRENT_SETTINGS, &deviceMode);

        xCoordinate = deviceMode.dmPosition.x;
        yCoordinate = deviceMode.dmPosition.y;
        WNDCLASS windowclass;

        windowclass.style = CS_OWNDC;
        windowclass.lpfnWndProc = WndProc;
        windowclass.cbClsExtra = 0;
        windowclass.cbWndExtra = 0;
        windowclass.hInstance = NULL;
        windowclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
        windowclass.hCursor = LoadCursor(NULL, IDC_ARROW);
        windowclass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
        windowclass.lpszMenuName = NULL;
        windowclass.lpszClassName = reinterpret_cast<LPCSTR>("VolumeRendering");
        RegisterClass(&windowclass);

        gHwnd = CreateWindow(reinterpret_cast<LPCSTR>("VolumeRendering"), 
                              reinterpret_cast<LPCSTR>("VolumeRendering"), 
                              WS_CAPTION | WS_POPUPWINDOW, 
                              isDeviceIdEnabled() ? xCoordinate1 : xCoordinate, 
                              yCoordinate, 
                              WINDOW_WIDTH, 
                              WINDOW_HEIGHT, 
                              NULL, 
                              NULL, 
                              windowclass.hInstance, 
                              NULL);
        hDC = GetDC(gHwnd);

        pfmt = ChoosePixelFormat(hDC, 
                    &pfd);
        if(pfmt == 0) 
        {
            std::cerr<<"Failed choosing the requested PixelFormat.\n";
            return SDK_FAILURE;
        }

        ret = SetPixelFormat(hDC, pfmt, &pfd);
        
        if(ret == FALSE) 
        {
            std::cerr<<"Failed to set the requested PixelFormat.\n";
            return SDK_FAILURE;
        }
        
        hRC = wglCreateContext(hDC);
        if(hRC == NULL) 
        {
            std::cerr<<"Failed to create a GL context"<<std::endl;
            return SDK_FAILURE;
        }

        ret = wglMakeCurrent(hDC, hRC);
        if(ret == FALSE) 
        {
            std::cerr<<"Failed to bind GL rendering context";
            return SDK_FAILURE;
        }	
        displayDevices++;

        cl_context_properties properties[] = 
        {
                CL_CONTEXT_PLATFORM, (cl_context_properties) platform,
                CL_GL_CONTEXT_KHR,   (cl_context_properties) hRC,
                CL_WGL_HDC_KHR,      (cl_context_properties) hDC,
                0
        };
        
        if (!clGetGLContextInfoKHR) 
        {
               clGetGLContextInfoKHR = (clGetGLContextInfoKHR_fn) clGetExtensionFunctionAddress("clGetGLContextInfoKHR");
               if (!clGetGLContextInfoKHR) 
               {
                    std::cerr<<"Failed to query proc address for clGetGLContextInfoKHR";
                    return SDK_FAILURE;
               }
        }
        
        size_t deviceSize = 0;
        status = clGetGLContextInfoKHR(properties, 
                                      CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR,
                                      0, 
                                      NULL, 
                                      &deviceSize);
        if(status != CL_SUCCESS)
        {
            std::cerr<<"clGetGLContextInfoKHR failed!!"<<std::endl;
            return SDK_FAILURE;
        }

        if (deviceSize == 0) 
        {
            // no interopable CL device found, cleanup
            wglMakeCurrent(NULL, NULL);
            wglDeleteContext(hRC);
            DeleteDC(hDC);
            hDC = NULL;
            hRC = NULL;
            DestroyWindow(gHwnd);
            // try the next display
            continue;
        }
        else 
        {
            if (deviceId == 0)
            {
                ShowWindow(gHwnd, SW_SHOW);
                //Found a winner 
                break;
            }
            else if (deviceId != connectedDisplays)
            {
                connectedDisplays++;
                wglMakeCurrent(NULL, NULL);
                wglDeleteContext(hRC);
                DeleteDC(hDC);
                hDC = NULL;
                hRC = NULL;
                DestroyWindow(gHwnd);
                if (xCoordinate >= 0)
                {
                    xCoordinate1 += deviceMode.dmPelsWidth;
                    // try the next display
                }
                else 
                {
                    xCoordinate1 -= deviceMode.dmPelsWidth;
                }

                continue;
            } 
            else 
            {
                ShowWindow(gHwnd, SW_SHOW);
                //Found a winner 
                break;
            }
        }

    }

     if (!hRC || !hDC) 
     {
        std::cerr<<"No GL context bound";
        return SDK_FAILURE;
     }

     cl_context_properties properties[] = 
    {
        CL_CONTEXT_PLATFORM, (cl_context_properties) platform,
        CL_GL_CONTEXT_KHR,   (cl_context_properties) hRC,
        CL_WGL_HDC_KHR,      (cl_context_properties) hDC,
        0
    };


    if (deviceType.compare("gpu") == 0)
    {		 
        status = clGetGLContextInfoKHR( properties, 
                                        CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR,
                                        sizeof(cl_device_id), 
                                        &interopDevice, 
                                        NULL);


        if(status != CL_SUCCESS)
        {
            std::cerr<<"clGetGLContextInfoKHR failed!!"<<std::endl;
            return SDK_FAILURE;
        }
        // Create OpenCL context from device's id
        context = clCreateContext(properties,
                                         1,
                                         &interopDevice,
                                         0,
                                         0,
                                         &status);
        if(status != CL_SUCCESS)
        {
            std::cerr<<"clCreateContext failed!!"<<std::endl;
            return SDK_FAILURE;
        }
    }
    else 
    {
        context = clCreateContextFromType(
                    properties,
                    CL_DEVICE_TYPE_CPU,
                    NULL,
                    NULL,
                    &status);

        if(status != CL_SUCCESS)
        {
            std::cerr<<"clCreateContextFromType failed!!"<<std::endl;
            return SDK_FAILURE;
        }
    }

    // GL init
    glewInit();
    if (! glewIsSupported("GL_VERSION_2_0 " "GL_ARB_pixel_buffer_object"))
    {
          std::cerr
              << "Support for necessary OpenGL extensions missing."
              << std::endl;
          return SDK_FAILURE;
    }
    return SDK_SUCCESS;
}
#endif 

int 
VolumeRendering::genBinaryImage()
{
    cl_int status = CL_SUCCESS;

    /*
     * Have a look at the available platforms and pick either
     * the AMD one if available or a reasonable default.
     */
    cl_uint numPlatforms;
    cl_platform_id platform = NULL;
    status = clGetPlatformIDs(0, NULL, &numPlatforms);
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clGetPlatformIDs failed."))
    {
        return SDK_FAILURE;
    }
    if (0 < numPlatforms) 
    {
        cl_platform_id* platforms = new cl_platform_id[numPlatforms];
        status = clGetPlatformIDs(numPlatforms, platforms, NULL);
        if(!sampleCommon->checkVal(status,
                                   CL_SUCCESS,
                                   "clGetPlatformIDs failed."))
        {
            return SDK_FAILURE;
        }

        char platformName[100];
        for (unsigned i = 0; i < numPlatforms; ++i) 
        {
            status = clGetPlatformInfo(platforms[i],
                                       CL_PLATFORM_VENDOR,
                                       sizeof(platformName),
                                       platformName,
                                       NULL);

            if(!sampleCommon->checkVal(status,
                                       CL_SUCCESS,
                                       "clGetPlatformInfo failed."))
            {
                return SDK_FAILURE;
            }

            platform = platforms[i];
            if (!strcmp(platformName, "Advanced Micro Devices, Inc.")) 
            {
                break;
            }
        }
        std::cout << "Platform found : " << platformName << "\n";
        delete[] platforms;
    }

    if(NULL == platform)
    {
        sampleCommon->error("NULL platform found so Exiting Application.");
        return SDK_FAILURE;
    }

    /*
     * If we could find our platform, use it. Otherwise use just available platform.
     */
    cl_context_properties cps[5] = 
    {
        CL_CONTEXT_PLATFORM, 
        (cl_context_properties)platform, 
        CL_CONTEXT_OFFLINE_DEVICES_AMD,
        (cl_context_properties)1,
        0
    };

    context = clCreateContextFromType(cps,
                                      CL_DEVICE_TYPE_ALL,
                                      NULL,
                                      NULL,
                                      &status);

    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clCreateContextFromType failed."))
    {
        return SDK_FAILURE;
    }

    /* create a CL program using the kernel source */
    streamsdk::SDKFile kernelFile;
    std::string kernelPath = sampleCommon->getPath();
    kernelPath.append("VolumeRendering_Kernels.cl");
    if(!kernelFile.open(kernelPath.c_str()))
    {
        std::cout << "Failed to load kernel file : " << kernelPath << std::endl;
        return SDK_FAILURE;
    }
    const char * source = kernelFile.source().c_str();
    size_t sourceSize[] = {strlen(source)};
    program = clCreateProgramWithSource(context,
                                        1,
                                        &source,
                                        sourceSize,
                                        &status);
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clCreateProgramWithSource failed."))
    {
        return SDK_FAILURE;
    }

    std::string flagsStr = std::string("");

    // Get additional options
    if(isComplierFlagsSpecified())
    {
        streamsdk::SDKFile flagsFile;
        std::string flagsPath = sampleCommon->getPath();
        flagsPath.append(flags.c_str());
        if(!flagsFile.open(flagsPath.c_str()))
        {
            std::cout << "Failed to load flags file: " << flagsPath << std::endl;
            return SDK_FAILURE;
        }
        flagsFile.replaceNewlineWithSpaces();
        const char * flags = flagsFile.source().c_str();
        flagsStr.append(flags);
    }

    if(flagsStr.size() != 0)
        std::cout << "Build Options are : " << flagsStr.c_str() << std::endl;

    /* create a cl program executable for all the devices specified */
    status = clBuildProgram(program,
                            0,
                            NULL,
                            (const char*)flagsStr.c_str(),
                            NULL,
                            NULL);
    
    sampleCommon->checkVal(status,
                           CL_SUCCESS,
                           "clBuildProgram");
    
    size_t numDevices;
    status = clGetProgramInfo(program, 
                           CL_PROGRAM_NUM_DEVICES,
                           sizeof(numDevices),
                           &numDevices,
                           NULL );
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clGetProgramInfo(CL_PROGRAM_NUM_DEVICES) failed."))
    {
        return SDK_FAILURE;
    }

    std::cout << "Number of devices found : " << numDevices << "\n\n";
    devices = (cl_device_id *)malloc( sizeof(cl_device_id) * numDevices );
    if(devices == NULL)
    {
        sampleCommon->error("Failed to allocate host memory.(devices)");
        return SDK_FAILURE;
    }
    /* grab the handles to all of the devices in the program. */
    status = clGetProgramInfo(program, 
                              CL_PROGRAM_DEVICES, 
                              sizeof(cl_device_id) * numDevices,
                              devices,
                              NULL );
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clGetProgramInfo(CL_PROGRAM_DEVICES) failed."))
    {
        return SDK_FAILURE;
    }


    /* figure out the sizes of each of the binaries. */
    size_t *binarySizes = (size_t*)malloc( sizeof(size_t) * numDevices );
    if(devices == NULL)
    {
        sampleCommon->error("Failed to allocate host memory.(binarySizes)");
        return SDK_FAILURE;
    }
    
    status = clGetProgramInfo(program, 
                              CL_PROGRAM_BINARY_SIZES,
                              sizeof(size_t) * numDevices, 
                              binarySizes, NULL);
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clGetProgramInfo(CL_PROGRAM_BINARY_SIZES) failed."))
    {
        return SDK_FAILURE;
    }

    size_t i = 0;
    /* copy over all of the generated binaries. */
    char **binaries = (char **)malloc( sizeof(char *) * numDevices );
    if(binaries == NULL)
    {
        sampleCommon->error("Failed to allocate host memory.(binaries)");
        return SDK_FAILURE;
    }

    for(i = 0; i < numDevices; i++)
    {
        if(binarySizes[i] != 0)
        {
            binaries[i] = (char *)malloc( sizeof(char) * binarySizes[i]);
            if(binaries[i] == NULL)
            {
                sampleCommon->error("Failed to allocate host memory.(binaries[i])");
                return SDK_FAILURE;
            }
        }
        else
        {
            binaries[i] = NULL;
        }
    }
    status = clGetProgramInfo(program, 
                              CL_PROGRAM_BINARIES,
                              sizeof(char *) * numDevices, 
                              binaries, 
                              NULL);
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clGetProgramInfo(CL_PROGRAM_BINARIES) failed."))
    {
        return SDK_FAILURE;
    }

    /* dump out each binary into its own separate file. */
    for(i = 0; i < numDevices; i++)
    {
        char fileName[100];
        sprintf(fileName, "%s.%d", dumpBinary.c_str(), i);
        if(binarySizes[i] != 0)
        {
            char deviceName[1024];
            status = clGetDeviceInfo(devices[i], 
                                     CL_DEVICE_NAME, 
                                     sizeof(deviceName),
                                     deviceName, 
                                     NULL);
            if(!sampleCommon->checkVal(status,
                                       CL_SUCCESS,
                                       "clGetDeviceInfo(CL_DEVICE_NAME) failed."))
            {
                return SDK_FAILURE;
            }

            printf( "%s binary kernel: %s\n", deviceName, fileName);
            streamsdk::SDKFile BinaryFile;
            if(!BinaryFile.writeBinaryToFile(fileName, 
                                             binaries[i], 
                                             binarySizes[i]))
            {
                std::cout << "Failed to load kernel file : " << fileName << std::endl;
                return SDK_FAILURE;
            }
        }
        else
        {
            printf("Skipping %s since there is no binary data to write!\n",
                    fileName);
        }
    }

    // Release all resouces and memory
    for(i = 0; i < numDevices; i++)
    {
        if(binaries[i] != NULL)
        {
            free(binaries[i]);
            binaries[i] = NULL;
        }
    }

    if(binaries != NULL)
    {
        free(binaries);
        binaries = NULL;
    }

    if(binarySizes != NULL)
    {
        free(binarySizes);
        binarySizes = NULL;
    }

    if(devices != NULL)
    {
        free(devices);
        devices = NULL;
    }

    status = clReleaseProgram(program);
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clReleaseProgram failed."))
    {
        return SDK_FAILURE;
    }

    status = clReleaseContext(context);
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clReleaseContext failed."))
    {
        return SDK_FAILURE;
    }

    return SDK_SUCCESS;
}


int 
VolumeRendering::setupCL()
{
    cl_int status = CL_SUCCESS;
    cl_device_type dType;

    if(deviceType.compare("cpu") == 0)
    {
        dType = CL_DEVICE_TYPE_CPU;
    }
    else //deviceType = "gpu" 
    {
        dType = CL_DEVICE_TYPE_GPU;
        if(isThereGPU() == false)
        {
            std::cout << "GPU not found. Falling back to CPU device" << std::endl;
            dType = CL_DEVICE_TYPE_CPU;
        }
    }

#ifndef _WIN32
    //Exit if deviceId option is used
    if(isDeviceIdEnabled())
    {
        sampleCommon->expectedError("-d(--deviceId) is not a supported");
        return SDK_EXPECTED_FAILURE;
    }
#endif

    size_t deviceListSize;

    /*
     * Have a look at the available platforms and pick either
     * the AMD one if available or a reasonable default.
     */

    cl_uint numPlatforms;
    cl_platform_id platform = NULL;
    status = clGetPlatformIDs(0, NULL, &numPlatforms);
    if(!sampleCommon->checkVal(status,
                               CL_SUCCESS,
                               "clGetPlatformIDs failed."))
    {
        return SDK_FAILURE;
    }
    if (0 < numPlatforms) 
    {
        cl_platform_id* platforms = new cl_platform_id[numPlatforms];
        status = clGetPlatformIDs(numPlatforms, platforms, NULL);
        if(!sampleCommon->checkVal(status,
                                   CL_SUCCESS,
                                   "clGetPlatformIDs failed."))
        {
            return SDK_FAILURE;
        }
        if(isPlatformEnabled())
        {
            platform = platforms[platformId];
        }
        else
        {
            for (unsigned i = 0; i < numPlatforms; ++i) 
            {
                char pbuf[100];
                status = clGetPlatformInfo(platforms[i],
                                           CL_PLATFORM_VENDOR,
                                           sizeof(pbuf),
                                           pbuf,
                                           NULL);

                if(!sampleCommon->checkVal(status,
                                           CL_SUCCESS,
                                           "clGetPlatformInfo failed."))
                {
                    return SDK_FAILURE;
                }

                platform = platforms[i];
                if (!strcmp(pbuf, "Advanced Micro Devices, Inc.")) 
                {
                    break;
                }
            }
        }
        delete[] platforms;
    }

    if(NULL == platform)
    {
        sampleCommon->error("NULL platform found so Exiting Application.");
        return SDK_FAILURE;
    }

    // Display available devices.
    if(!sampleCommon->displayDevices(platform, dType))
    {
        sampleCommon->error("sampleCommon::displayDevices() failed");
        return SDK_FAILURE;
    }

#ifdef _WIN32
    //Enablbing GL, Creating window, creating GL context, creating CL_GL context
    enableGLAndGetGLContext(gHwnd, gHdc, gGlCtx, platform, context, interopDeviceId);
#else 
    if (dType == CL_DEVICE_TYPE_GPU)
    {	 
        gGlCtx = glXGetCurrentContext();
        cl_context_properties cpsGL[] = { CL_CONTEXT_PLATFORM, (cl_context_properties)platform,
                                      CL_GLX_DISPLAY_KHR, (intptr_t) glXGetCurrentDisplay(),
                                      CL_GL_CONTEXT_KHR, (intptr_t) gGlCtx, 0};

    
        if (!clGetGLContextInfoKHR)
        {
            clGetGLContextInfoKHR = (clGetGLContextInfoKHR_fn) clGetExtensionFunctionAddress("clGetGLContextInfoKHR");
            if (!clGetGLContextInfoKHR)
                {
                    std::cerr<<"Failed to query proc address for clGetGLContextInfoKHR";
                }
        }

        size_t deviceSize = 0;
        status = clGetGLContextInfoKHR(cpsGL,
                                   CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR,
                                   0,
                                   NULL,
                                   &deviceSize);
        if(status != CL_SUCCESS)
        {
            std::cerr<<"clGetGLContextInfoKHR failed!!"<<std::endl;
        }

     
        status = clGetGLContextInfoKHR( cpsGL,
                                    CL_CURRENT_DEVICE_FOR_GL_CONTEXT_KHR,
                                    sizeof(cl_device_id),
                                    &interopDeviceId,
                                    NULL);


        if(status != CL_SUCCESS)
        {
            std::cerr<<"clGetGLContextInfoKHR failed!!"<<std::endl;
        }


        std::cout<<"Interop Device ID is "<<interopDeviceId<<std::endl; 
 
        // Create OpenCL context from device's id
        context = clCreateContext(cpsGL,
                                 1,
                                 &interopDeviceId,
                                 0,
                                 0,
                                 &status);
   
        if(!sampleCommon->checkVal(
            status,
            CL_SUCCESS,
            "clCreateContext failed."))
            return SDK_FAILURE;   
     
    }
    else 
    {
        gGlCtx = glXGetCurrentContext();
        cl_context_properties cpsGL[] = { CL_CONTEXT_PLATFORM, (cl_context_properties)platform,
                                      CL_GLX_DISPLAY_KHR, (intptr_t) glXGetCurrentDisplay(),
                                      CL_GL_CONTEXT_KHR, (intptr_t) gGlCtx, 0};

        context = clCreateContextFromType(cpsGL,
                    CL_DEVICE_TYPE_CPU,
                    NULL,
                    NULL,
                    &status);
        
        if(!sampleCommon->checkVal(
                    status,
                    CL_SUCCESS,
                    "clCreateContextFromType failed."))
                    return SDK_FAILURE;		
    }
#endif

    /* First, get the size of device list data */
    status = clGetContextInfo(
        context, 
        CL_CONTEXT_DEVICES, 
        0, 
        NULL, 
        &deviceListSize);
    if(!sampleCommon->checkVal(
        status, 
        CL_SUCCESS,
        "clGetContextInfo failed."))
        return SDK_FAILURE;

    /* Now allocate memory for device list based on the size we got earlier */
    devices = (cl_device_id*)malloc(deviceListSize);
    if(devices==NULL) {
        sampleCommon->error("Failed to allocate memory (devices).");
        return SDK_FAILURE;
    }

    /* Now, get the device list data */
    status = clGetContextInfo(
        context, 
        CL_CONTEXT_DEVICES, 
        deviceListSize, 
        devices, 
        NULL);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clGetContextInfo failed."))
        return SDK_FAILURE;

    int deviceCount = (int)(deviceListSize / sizeof(cl_device_id));

    /* Check for image support */
    status = clGetDeviceInfo((dType == CL_DEVICE_TYPE_CPU) ? devices[deviceId] : interopDeviceId,
                             CL_DEVICE_IMAGE_SUPPORT,
                             sizeof(cl_bool),
                             &imageSupport,
                             0);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clGetDeviceInfo failed."))
        return SDK_FAILURE;

    if(!imageSupport)
    {
        std::cout << "Error : Images are not supported on this device!\n";
        return SDK_EXPECTED_FAILURE;
    }

#ifndef  _WIN32
    if (dType == CL_DEVICE_TYPE_CPU)	
        interopDeviceId = devices[deviceId];
#else 
    if (dType == CL_DEVICE_TYPE_CPU)
        interopDeviceId = devices[deviceId];
#endif 

    /* Create command queue */

    cl_command_queue_properties prop = 0;

    if(timing)
        prop |= CL_QUEUE_PROFILING_ENABLE;

    commandQueue = clCreateCommandQueue(context,
                                        interopDeviceId,
                                        prop,
                                        &status);

    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clCreateCommandQueue failed."))
    {
        return SDK_FAILURE;
    }

    /*
    * Create and initialize memory objects
    */
    cl_image_format volumeDataFormat;
    volumeDataFormat.image_channel_order = CL_LUMINANCE;
    volumeDataFormat.image_channel_data_type = CL_UNORM_INT8;

    /* Create 3D Image object for input volume data */
    inputVolumeBuffer = clCreateImage3D(context, 
                                        CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, 
                                        &volumeDataFormat, 
                                        width,
                                        height, 
                                        slices,
                                        0,
                                        0,
                                        inputVolumeData, 
                                        &status);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clCreateBuffer failed. (inputVolumeBuffer)"))
    {
        return SDK_FAILURE;
    }

    /* Create memory objects for output buffer */

    /* 
     * Create texture object 
     */
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);

    /* Set parameters */
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 
                 0, 
                 GL_RGBA, 
                 (GLsizei)WINDOW_WIDTH,
                 (GLsizei)WINDOW_HEIGHT, 
                 0, 
                 GL_LUMINANCE, 
                 GL_UNSIGNED_BYTE,
                 0);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Create output buffer to render using GL
    outputBuffer = clCreateFromGLTexture2D(context,
                                           CL_MEM_WRITE_ONLY,
                                           GL_TEXTURE_2D,
                                           0,
                                           tex,
                                           &status);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clCreateFromGLTexture2D failed. (outputBuffer)"))
        return SDK_FAILURE;


    // Inverse rotation matrix
    matrixBuffer = clCreateBuffer(context, 
                                  CL_MEM_READ_ONLY, 
                                  16 * sizeof(float), 
                                  0, 
                                  &status);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clCreateFromGLBuffer failed. (matrixBuffer)"))
        return SDK_FAILURE;


    /* create a CL program using the kernel source */
    streamsdk::SDKFile kernelFile;
    std::string kernelPath = sampleCommon->getPath();
    if(isLoadBinaryEnabled())
    {
        kernelPath.append(loadBinary.c_str());
        if(!kernelFile.readBinaryFromFile(kernelPath.c_str()))
        {
            std::cout << "Failed to load kernel file : " << kernelPath << std::endl;
            return SDK_FAILURE;
        }

        const char * binary = kernelFile.source().c_str();
        size_t binarySize = kernelFile.source().size();
        program = clCreateProgramWithBinary(context,
                                            1,
                                            &interopDeviceId, 
                                            (const size_t *)&binarySize,
                                            (const unsigned char**)&binary,
                                            NULL,
                                            &status);
        if(!sampleCommon->checkVal(status,
                                   CL_SUCCESS,
                                   "clCreateProgramWithBinary failed."))
        {
            return SDK_FAILURE;
        }

    }
    else
    {
        kernelPath.append("VolumeRendering_Kernels.cl");
        if(!kernelFile.open(kernelPath.c_str()))
        {
            std::cout << "Failed to load kernel file : " << kernelPath << std::endl;
            return SDK_FAILURE;
        }

        const char *source = kernelFile.source().c_str();
        size_t sourceSize[] = {strlen(source)};
        program = clCreateProgramWithSource(context,
            1,
            &source,
            sourceSize,
            &status);
        if(!sampleCommon->checkVal(
            status,
            CL_SUCCESS,
            "clCreateProgramWithSource failed."))
            return SDK_FAILURE;
    }

    std::string flagsStr = std::string("");

    // Get additional options
    if(isComplierFlagsSpecified())
    {
        streamsdk::SDKFile flagsFile;
        std::string flagsPath = sampleCommon->getPath();
        flagsPath.append(flags.c_str());
        if(!flagsFile.open(flagsPath.c_str()))
        {
            std::cout << "Failed to load flags file: " << flagsPath << std::endl;
            return SDK_FAILURE;
        }
        flagsFile.replaceNewlineWithSpaces();
        const char * flags = flagsFile.source().c_str();
        flagsStr.append(flags);
    }

    if(flagsStr.size() != 0)
        std::cout << "Build Options are : " << flagsStr.c_str() << std::endl;

    /* create a cl program executable for all the devices specified */
    status = clBuildProgram(program, 
                            1, 
                            &interopDeviceId, 
                            (const char*)flagsStr.c_str(), 
                            NULL, 
                            NULL);
    if(status != CL_SUCCESS)
    {
        if(status == CL_BUILD_PROGRAM_FAILURE)
        {
            cl_int logStatus;
            char *buildLog = NULL;
            size_t buildLogSize = 0;
            logStatus = clGetProgramBuildInfo (program, 
                interopDeviceId, 
                CL_PROGRAM_BUILD_LOG, 
                buildLogSize, 
                buildLog, 
                &buildLogSize);
            if(!sampleCommon->checkVal(
                logStatus,
                CL_SUCCESS,
                "clGetProgramBuildInfo failed."))
                return SDK_FAILURE;

            buildLog = (char*)malloc(buildLogSize);
            if(buildLog == NULL)
            {
                sampleCommon->error("Failed to allocate host memory. (buildLog)");
                return SDK_FAILURE;
            }
            memset(buildLog, 0, buildLogSize);

            logStatus = clGetProgramBuildInfo (program, 
                interopDeviceId, 
                CL_PROGRAM_BUILD_LOG, 
                buildLogSize, 
                buildLog, 
                NULL);
            if(!sampleCommon->checkVal(
                logStatus,
                CL_SUCCESS,
                "clGetProgramBuildInfo failed."))
            {
                free(buildLog);
                return SDK_FAILURE;
            }

            std::cout << " \n\t\t\tBUILD LOG\n";
            std::cout << " ************************************************\n";
            std::cout << buildLog << std::endl;
            std::cout << " ************************************************\n";
            free(buildLog);
        }

        if(!sampleCommon->checkVal(
            status,
            CL_SUCCESS,
            "clBuildProgram failed."))
            return SDK_FAILURE;
    }

    /* get a kernel object handle for a kernel with the given name */
    kernel = clCreateKernel(program, "rayCastVolume",&status);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clCreateKernel failed."))
    {
        return SDK_FAILURE;
    }

    /* Check group size against group size returned by kernel */
    status = clGetKernelWorkGroupInfo(kernel,
        interopDeviceId,
        CL_KERNEL_WORK_GROUP_SIZE,
        sizeof(size_t),
        &kernelWorkGroupSize,
        0);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clGetKernelWorkGroupInfo  failed."))
    {
        return SDK_FAILURE;
    }

    while((blockSizeX * blockSizeY) < kernelWorkGroupSize)
    {
        if(2 * blockSizeX * blockSizeY <= kernelWorkGroupSize)
        {
            blockSizeX <<= 1;
        }
        if(2 * blockSizeX * blockSizeY <= kernelWorkGroupSize)
        {
            blockSizeY <<= 1;
        }
    }

    return SDK_SUCCESS;
}

int 
VolumeRendering::runCLKernels()
{
    cl_int status;

    /* Acquire outputImageBuffer from GL */
    cl_event acquireGLEvt;
    status = clEnqueueAcquireGLObjects(commandQueue, 
                                       1, 
                                       &outputBuffer, 
                                       0, 
                                       0,
                                       &acquireGLEvt);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clEnqueueAcquireGLObjects failed."))
        return SDK_FAILURE;

    // Flush acquire outputBuffer before kernel launch
    status = clFlush(commandQueue);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clFlush failed."))
        return SDK_FAILURE;

    int retValue = waitForEvent(&acquireGLEvt);
    if(retValue != SDK_SUCCESS)
    {
        std::cout << "waitForEvent(acquireGLEvt) failed." << std::endl;
        return SDK_FAILURE;
    }
    

    /* Enqueue write current matrix to matrix buffer */
    cl_event writeEvt;
    status = clEnqueueWriteBuffer(commandQueue, 
                                  matrixBuffer, 
                                  CL_FALSE, 
                                  0, 
                                  16 * sizeof(float), 
                                  matrix, 
                                  0, 
                                  0, 
                                  &writeEvt);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clEnqueueWriteBuffer failed. (matrixBuffer)"))
        return SDK_FAILURE;

    status = clFlush(commandQueue);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clFlush failed."))
        return SDK_FAILURE;

    retValue = waitForEvent(&writeEvt);
    if(retValue != SDK_SUCCESS)
    {
        std::cout << "waitForEvent(writeEvt) failed." << std::endl;
        return SDK_FAILURE;
    }

    /* Set appropriate arguments to the kernel */

    /* input 3D volume data */
    status = clSetKernelArg(kernel, 0, sizeof(cl_mem), &inputVolumeBuffer);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (inputImageBuffer)"))
    {
        return SDK_FAILURE;
    }

    /* outBuffer image */
    status = clSetKernelArg(kernel, 1, sizeof(cl_mem),&outputBuffer);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (outputImageBuffer)"))
    {
        return SDK_FAILURE;
    }


    /* Inverse model view matrix */
    status = clSetKernelArg(kernel, 2, sizeof(cl_mem), &matrixBuffer);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (matrix)"))
    {
        return SDK_FAILURE;
    }

    /* Steps of ray traversal  */
    status = clSetKernelArg(kernel, 3, sizeof(int), &steps);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (steps)"))
    {
        return SDK_FAILURE;
    }

    /* Step size  */
    status = clSetKernelArg(kernel, 4, sizeof(float), &step_size);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (step_size)"))
    {
        return SDK_FAILURE;
    }

    /* Step size  */
    status = clSetKernelArg(kernel, 5, sizeof(float), &dis);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (dis)"))
    {
        return SDK_FAILURE;
    }

    /* linear_ramp_slope  */
    status = clSetKernelArg(kernel, 6, sizeof(float), &linear_ramp_slope);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (linear_ramp_slope)"))
    {
        return SDK_FAILURE;
    }

    /* linear_ramp_constant */
    status = clSetKernelArg(kernel, 7, sizeof(float), &linear_ramp_constant);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (linear_ramp_constant)"))
    {
        return SDK_FAILURE;
    }

    /* threshold */
    status = clSetKernelArg(kernel, 8, sizeof(float), &threshold);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clSetKernelArg failed. (threshold)"))
    {
        return SDK_FAILURE;
    }

    /* 
    * Enqueue a kernel run call.
    */
    size_t globalThreads[] = {WINDOW_WIDTH, WINDOW_HEIGHT};
    size_t localThreads[] = {blockSizeX, blockSizeY};

    cl_event ndrEvt;
    status = clEnqueueNDRangeKernel(commandQueue,
                                    kernel,
                                    2,
                                    NULL,
                                    globalThreads,
                                    localThreads,
                                    0,
                                    NULL,
                                    &ndrEvt);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clEnqueueNDRangeKernel failed."))
        return SDK_FAILURE;

    status = clFlush(commandQueue);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS, 
        "clFlush failed."))
        return SDK_FAILURE;

    retValue = waitForEvent(&ndrEvt);
    if(retValue != SDK_SUCCESS)
    {
        std::cout << "waitForEvent(ndrEvt) failed." << std::endl;
        return SDK_FAILURE;
    }

    if(verify)
    {
        size_t temp;
        status = clGetMemObjectInfo(outputBuffer, 
                                    CL_MEM_SIZE, 
                                    sizeof(size_t), 
                                    &temp, 
                                    0);
        if(!sampleCommon->checkVal(status,
            CL_SUCCESS,
            "clGetMemObjectInfo failed."))
            return SDK_FAILURE;

        /* allocate memory for output image data */
        outputBufferData = (DATATYPE*)malloc(temp);

        /* error check */
        if(outputBufferData == NULL)
        {
            sampleCommon->error("Failed to allocate memory! (outputBufferData)");
            return SDK_FAILURE;
        }

        /* Enqueue Read Image */
        size_t origin[] = {0, 0, 0};
        size_t region[] = {WINDOW_WIDTH, WINDOW_HEIGHT, 1};

        /* Read output of 2D copy */
        cl_event readEvt;
        status = clEnqueueReadImage(commandQueue,
                                    outputBuffer,
                                    CL_FALSE,
                                    origin,
                                    region,
                                    0,
                                    0,
                                    outputBufferData,
                                    0, 0, &readEvt);
        if(!sampleCommon->checkVal(
            status,
            CL_SUCCESS,
            "clEnqueueReadImage failed."))
            return SDK_FAILURE;

       status = clFlush(commandQueue);
        if(!sampleCommon->checkVal(
            status,
            CL_SUCCESS, 
            "clFlush failed."))
            return SDK_FAILURE;

        retValue = waitForEvent(&readEvt);
        if(retValue != SDK_SUCCESS)
        {
            std::cout << "waitForEvent(readEvt) failed." << std::endl;
            return SDK_FAILURE;
        }


        /* Now OpenGL gets control of outputImageBuffer */
        cl_event releaseGLEvt;
        status = clEnqueueReleaseGLObjects(commandQueue, 
                                           1, 
                                           &outputBuffer, 
                                           0, 
                                           0, 
                                           &releaseGLEvt);
        if(!sampleCommon->checkVal(
             status,
             CL_SUCCESS, 
             "clEnqueueReleaseGLObjects failed."))
             return SDK_FAILURE;

        status = clFlush(commandQueue);
        if(!sampleCommon->checkVal(
            status,
            CL_SUCCESS, 
            "clFlush failed."))
            return SDK_FAILURE;

        retValue = waitForEvent(&releaseGLEvt);
        if(retValue != SDK_SUCCESS)
        {
            std::cout << "waitForEvent(releaseGLEvt) failed." << std::endl;
            return SDK_FAILURE;
        }
    }
    return SDK_SUCCESS;
}



int 
VolumeRendering::initialize()
{
    // Call base class Initialize to get default configuration
    if(!this->SDKSample::initialize())
        return SDK_FAILURE;

    streamsdk::Option* iteration_option = new streamsdk::Option;
    if(!iteration_option)
    {
        sampleCommon->error("Memory Allocation error.\n");
        return SDK_FAILURE;
    }
    iteration_option->_sVersion = "i";
    iteration_option->_lVersion = "iterations";
    iteration_option->_description = "Number of iterations to execute kernel";
    iteration_option->_type = streamsdk::CA_ARG_INT;
    iteration_option->_value = &iterations;

    sampleArgs->AddOption(iteration_option);
    
    delete iteration_option;

    return SDK_SUCCESS;
}

int 
VolumeRendering::setup()
{
    /* create and initialize timers */
    int timer = sampleCommon->createTimer();
    sampleCommon->resetTimer(timer);
    sampleCommon->startTimer(timer);

    int status = setupCL();
    if(status != SDK_SUCCESS)
        return status;

    sampleCommon->stopTimer(timer);
    /* Compute setup time */
    setupTime = (double)(sampleCommon->readTimer(timer));

    return SDK_SUCCESS;
}

int 
VolumeRendering::run()
{
    if(verify)
    {
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        // Translate back to original position
        glTranslatef(0.5,0.5, 0.5);
        // Do the inverse rotation 
        glRotatef(rotation[0], 1.0, 0.0, 0.0);
        glRotatef(rotation[1], 0.0, 1.0, 0.0);
        // Translate the volume to origin
        glTranslatef(-0.5,-0.5, -0.5);
        glGetFloatv(GL_MODELVIEW_MATRIX, matrix);
        glPopMatrix();

        /* create and initialize timers */
        int timer = sampleCommon->createTimer();
        sampleCommon->resetTimer(timer);

        if(!quiet)
        {
            std::cout << "Executing kernel for " << iterations << 
                " iterations" <<std::endl;
            std::cout << "-------------------------------------------" << std::endl;
        }

        sampleCommon->startTimer(timer);

        for(int i = 0; i < iterations; i++)
        {
            /* Set kernel arguments and run kernel */
            if(runCLKernels() != SDK_SUCCESS)
                return SDK_FAILURE;
        }

        sampleCommon->stopTimer(timer);
        /* Compute kernel time */
        kernelTime = (double)(sampleCommon->readTimer(timer)) / iterations;
    }
    else
    {
#ifndef _WIN32
        glutMainLoop();
#else //Windows
        // program main loop
        while (!quit)
        {
            // check for messages
            if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
            {
                // handle or dispatch messages
                if (msg.message == WM_QUIT) 
                {
                    quit = TRUE;
                } 
                else 
                {
                    TranslateMessage(&msg);
                    DispatchMessage(&msg);
                }
                
            } 
            else 
            {
                // Use OpenGL to build inverse ModelView matrix
                //GLfloat modelViewMatrix[16];
                glMatrixMode(GL_MODELVIEW);
                glPushMatrix();
                glLoadIdentity();
                // Translate back to original position
                glTranslatef(0.5,0.5, 0.5);
                // Do the inverse rotation 
                glRotatef(rotation[0], 1.0, 0.0, 0.0);
                glRotatef(rotation[1], 0.0, 1.0, 0.0);
                // Translate the volume to origin
                glTranslatef(-0.5,-0.5, -0.5);
                glGetFloatv(GL_MODELVIEW_MATRIX, matrix);
                glPopMatrix();


                /* create and initialize timers */
                int timer = sampleCommon->createTimer();
                sampleCommon->resetTimer(timer);
                sampleCommon->startTimer(timer);
                frameCount++;

                /* Execute the kernel which renders 3D data to buffer */
                runCLKernels();

                /* Bind  texture */
                glBindTexture(GL_TEXTURE_2D, tex);

                /* Display image using texture*/
                glDisable(GL_DEPTH_TEST);
                glDisable(GL_LIGHTING);
                glEnable(GL_TEXTURE_2D);
                glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

                glMatrixMode(GL_PROJECTION);
                glPushMatrix();
                glLoadIdentity();
                glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);

                glMatrixMode( GL_MODELVIEW);
                glLoadIdentity();

                glViewport(0, 0, (GLsizei)WINDOW_WIDTH, (GLsizei)WINDOW_HEIGHT);

                glBegin(GL_QUADS);

                glTexCoord2f(0.0, 0.0);
                glVertex3f(-1.0, -1.0, 0.5);

                glTexCoord2f(1.0, 0.0);
                glVertex3f(1.0, -1.0, 0.5);

                glTexCoord2f(1.0, 1.0);
                glVertex3f(1.0, 1.0, 0.5);

                glTexCoord2f(0.0, 1.0);
                glVertex3f(-1.0, 1.0, 0.5);

                glEnd();

                glMatrixMode(GL_PROJECTION);
                glPopMatrix();

                glDisable(GL_TEXTURE_2D);
                glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
                glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);

                SwapBuffers(gHdc);

                sampleCommon->stopTimer(timer);
                totalElapsedTime += sampleCommon->readTimer(timer);
                if(frameCount)
                {
                    // set GLUT Window Title
                    char title[256];
                    double framesPerSec = frameCount / totalElapsedTime ;
#if defined (_WIN32) && !defined(__MINGW32__)
                    sprintf_s(title, 256, "VolumeRendering | %f fps ", framesPerSec);
#else 
                    sprintf(title, "VolumeRendering | %d fps ", framesPerSec);
#endif
                    SetWindowText(gHwnd, title);
                    frameCount = 0;
                    totalElapsedTime = 0.0;
                }
            }
        }
#endif
    }
    return SDK_SUCCESS;
}

int 
VolumeRendering::cleanup()
{
    /* Releases OpenCL resources (Context, Memory etc.) */
    cl_int status;

    status = clReleaseKernel(kernel);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clReleaseKernel failed."))
        return SDK_FAILURE;

    status = clReleaseProgram(program);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clReleaseProgram failed."))
        return SDK_FAILURE;

    status = clReleaseMemObject(inputVolumeBuffer);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clReleaseMemObject failed."))
        return SDK_FAILURE;

    status = clReleaseMemObject(outputBuffer);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clReleaseMemObject failed."))
        return SDK_FAILURE;

    status = clReleaseCommandQueue(commandQueue);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clReleaseCommandQueue failed."))
        return SDK_FAILURE;

    status = clReleaseContext(context);
    if(!sampleCommon->checkVal(
        status,
        CL_SUCCESS,
        "clReleaseContext failed."))
        return SDK_FAILURE;

    /* release program resources (input memory etc.) */
    if(inputVolumeData) 
        free(inputVolumeData);

    if(outputBufferData)
        free(outputBufferData);

    if(verificationOutput) 
        free(verificationOutput);

    if(devices)
        free(devices);

    return SDK_SUCCESS;
}


int 
VolumeRendering::verifyResults()
{
    if(verify)
    {
        size_t temp;
        int  status = clGetMemObjectInfo(outputBuffer, 
                                         CL_MEM_SIZE, 
                                         sizeof(size_t), 
                                         &temp, 
                                         0);
        if(!sampleCommon->checkVal(status,
            CL_SUCCESS,
            "clGetMemObjectInfo failed."))
            return SDK_FAILURE;

        /* allocate memory for verification output */
        verificationOutput = (DATATYPE*)malloc(temp);

        /* error check */
        if(verificationOutput == NULL)
        {
            sampleCommon->error("verificationOutput heap allocation failed!");
            return SDK_FAILURE;
        }

        // Read data from verification file
        FILE *fp = NULL;

        std::string filePath = sampleCommon->getPath() + std::string("verify.raw");
#if defined (_WIN32) && !defined(__MINGW32__)
        errno_t error;
        if((error = fopen_s(&fp, filePath.c_str(), "rb")) != 0)
#else
        if((fp = fopen(filePath.c_str(), "rb")) == NULL) 
#endif
        {
            sampleCommon->error("Failed to load volume data!");
            return SDK_FAILURE;
        }

        fread(verificationOutput, temp, 1, fp);

        bool different = false;

        // Deal with the different precision on x86 CPU devices.
        // We don't get an exact match.
        // This is because the GPU divide is accurate to about
        // 2 ULPs (units of least precision).
        // The kernel code iterates across a whole bunch of
        // results produced -- each with a litte bit of error.
        // And so it makes a nice picture, but it's a little off.
        // 
        // Also, the RGB numbers are better than the A numbers.
        // So the check is very sloppy for the A's.
        int errors = 0;
        for (unsigned int i = 0; i < temp; i += 4) {
            if ((outputBufferData[i  ]     > verificationOutput[i  ] + 3) ||
                (outputBufferData[i  ] + 3 < verificationOutput[i  ]    ) ||
                (outputBufferData[i+1]     > verificationOutput[i+1] + 3) ||
                (outputBufferData[i+1] + 3 < verificationOutput[i+1]    ) ||
                (outputBufferData[i+2]     > verificationOutput[i+2] + 3) ||
                (outputBufferData[i+2] + 3 < verificationOutput[i+2]    ) ||
                (outputBufferData[i+3]     > verificationOutput[i+3] +15) ||
                (outputBufferData[i+3] + 15< verificationOutput[i+3]    )) {

                different = true;
                break;
            }
        }

        if(! different)
        {
            std::cout << "Passed!\n" << std::endl;
            return SDK_SUCCESS;
        }
        else
        {
            std::cout << "Failed!\n" << std::endl;
            return SDK_FAILURE;
        }
    }
    return SDK_SUCCESS;
}

void 
VolumeRendering::printStats()
{
    std::string strArray[5] = 
    {
        "Width", 
        "Height",
        "Slices",
        "Time(sec)", 
        "kernelTime(sec)"
    };
    std::string stats[5];

    totalTime = setupTime + kernelTime;

    stats[0] = sampleCommon->toString(width, std::dec);
    stats[1] = sampleCommon->toString(height, std::dec);
    stats[2] = sampleCommon->toString(slices, std::dec);
    stats[3] = sampleCommon->toString(totalTime, std::dec);
    stats[4] = sampleCommon->toString(kernelTime, std::dec);

    this->SDKSample::printStats(strArray, stats, 5);
}


void
VolumeRendering::displayFunc()
{
#ifndef _WIN32
    // Use OpenGL to build inverse ModelView matrix
    //GLfloat modelViewMatrix[16];
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // Translate back to original position
    glTranslatef(0.5,0.5, 0.5);
    // Do the inverse rotation 
    glRotatef(rotation[0], 1.0, 0.0, 0.0);
    glRotatef(rotation[1], 0.0, 1.0, 0.0);
    // Translate the volume to origin
    glTranslatef(-0.5,-0.5, -0.5);
    glGetFloatv(GL_MODELVIEW_MATRIX, matrix);
    glPopMatrix();


    /* create and initialize timers */
    int timer = sampleCommon->createTimer();
    sampleCommon->resetTimer(timer);
    sampleCommon->startTimer(timer);
    frameCount++;

    /* Execute the kernel which renders 3D data to buffer */
    runCLKernels();

    /* Bind  texture */
    glBindTexture(GL_TEXTURE_2D, tex);

    /* Display image using texture*/
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);

    glMatrixMode( GL_MODELVIEW);
    glLoadIdentity();

    glViewport(0, 0, (GLsizei)WINDOW_WIDTH, (GLsizei)WINDOW_HEIGHT);

    glBegin(GL_QUADS);

    glTexCoord2f(0.0, 0.0);
    glVertex3f(-1.0, -1.0, 0.5);

    glTexCoord2f(1.0, 0.0);
    glVertex3f(1.0, -1.0, 0.5);

    glTexCoord2f(1.0, 1.0);
    glVertex3f(1.0, 1.0, 0.5);

    glTexCoord2f(0.0, 1.0);
    glVertex3f(-1.0, 1.0, 0.5);

    glEnd();

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glDisable(GL_TEXTURE_2D);
    glBindBuffer(GL_PIXEL_PACK_BUFFER, 0);
    glBindBuffer(GL_PIXEL_UNPACK_BUFFER, 0);

    glutSwapBuffers();
    glutPostRedisplay();

    sampleCommon->stopTimer(timer);
    totalElapsedTime += sampleCommon->readTimer(timer);
    if(frameCount)
    {
        // set GLUT Window Title
        char title[256];
        double framesPerSec = frameCount / totalElapsedTime ;
#if defined (_WIN32) && !defined(__MINGW32__)
        sprintf_s(title, 256, "VolumeRendering | %f fps ", framesPerSec);
#else 
        sprintf(title, "VolumeRendering | %d fps ", framesPerSec);
#endif
        glutSetWindowTitle(title);
        frameCount = 0;
        totalElapsedTime = 0.0;
    }
#endif
}

void
VolumeRendering::idle()
{
#ifndef _WIN32
    glutPostRedisplay();
#endif
}

void 
VolumeRendering::keyboardFunc(unsigned char key, int /*x*/, int /*y*/)
{
#ifndef _WIN32
    switch(key)
    {
        /* If the user hits escape or Q, then exit */
        /* ESCAPE_KEY = 27 */
    case 'q':
    case 27:
        {
            if(cleanup() != SDK_SUCCESS)
                exit(1);
            else
                exit(0);
        }
   case '[':
        steps += 10;
        break;
    case ']':
        steps -= 10;
        break;
    case 'z':
        step_size += 0.0001f;
        steps = (int)((1.414 + fabs(dis)) / step_size);
        break;
    case 'x':
        step_size -= 0.0001f;
        steps = (int)((1.414 + fabs(dis)) / step_size);
        break;
    case 'a':
        linear_ramp_slope += 0.002f;
        break;
    case 's':
        linear_ramp_slope -= 0.002f;
        break;
    case 'c':
        linear_ramp_constant += 0.003f;
        break;
    case 'v':
        linear_ramp_constant -= 0.003f;
        break;
    case 'b':
        threshold += 0.001f;
        break;
    case 'n':
        threshold -= 0.001f;
        break;
    case 'e':
        dis += 0.01;
        steps = (int)((1.414 + fabs(dis)) / step_size);
        break;
    case 'r':
        dis -= 0.01;
        steps = (int)((1.414 + fabs(dis)) / step_size);
        break;

    case 'p':
        printf("Steps : %d\nstep_size : %f\nlinear_ramp_slope : %f\nlinear_ramp_constant : %f\n"
               "threshold : %f\ndistance : %f\n", steps, step_size, linear_ramp_slope, linear_ramp_constant,
                threshold, dis);
    default:
        break;
    }
#endif
}

void
VolumeRendering::mouseFunc(int button, int state, int x, int y)
{
#ifndef _WIN32
    if (state == GLUT_DOWN)
    {
        if(button != GLUT_RIGHT_BUTTON)
            buttonState = GLUT_LEFT_BUTTON;
    }
    else if (state == GLUT_UP)
        buttonState = 0;

    ox = x; 
    oy = y;
    glutPostRedisplay();
#endif
}

void 
VolumeRendering::motionFunc(int x, int y)
{
#ifndef _WIN32
    float dx, dy;
    dx = x - ox;
    dy = y - oy;


    if (buttonState == GLUT_LEFT_BUTTON) 
    {
        // left = rotate
        rotation[0] += dy / 5.0;
        rotation[1] += dx / 5.0;
    }

    ox = x; 
    oy = y;
    glutPostRedisplay();
#endif
}

void
VolumeRendering::displayFuncWrapper()
{
    /* Call non-static function */
    vR->displayFunc();
}

void
VolumeRendering::keyboardFuncWrapper(unsigned char key, int x, int y)
{
    /* Call non-static function */
    vR->keyboardFunc(key , x, y);
}

void
VolumeRendering::mouseFuncWrapper(int button, int state, int x, int y)
{
    /* Call non-static function */
    vR->mouseFunc(button, state, x, y);
}

void
VolumeRendering::motionFuncWrapper(int x, int y)
{
    /* Call non-static function */
    vR->motionFunc(x, y);
}

void
VolumeRendering::idleFuncWrapper()
{
    /* Call non-static function */
    vR->idle();
}

/* Initialize the value to NULL */
VolumeRendering *VolumeRendering::vR = NULL;


int 
VolumeRendering::initializeGL(int argc, char * argv[])
{
    /* Allocate host memory and read input image */
    if(loadVolumeData() != SDK_SUCCESS)
        return SDK_FAILURE;
#ifndef _WIN32
    // Create GL context
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE);
    glutInitWindowSize((GLsizei)WINDOW_WIDTH, (GLsizei)WINDOW_HEIGHT);
    glutInitWindowPosition(100, 0);
    glutCreateWindow("VolumeRender GL");

    // GL init
    glewInit();
    if (! glewIsSupported("GL_VERSION_2_0 " "GL_ARB_pixel_buffer_object"))
    {
          std::cerr
              << "Support for necessary OpenGL extensions missing."
              << std::endl;
          return SDK_FAILURE;
    }

    glutDisplayFunc(displayFuncWrapper);
    glutKeyboardFunc(keyboardFuncWrapper);
    glutMouseFunc(mouseFuncWrapper);
    glutMotionFunc(motionFuncWrapper);
    glutIdleFunc(idleFuncWrapper);
#endif
    return SDK_SUCCESS;
}

int 
main(int argc, char * argv[])
{
    VolumeRendering clVolumeRender("OpenCL Volume Render GL");
    VolumeRendering::vR = &clVolumeRender;

    if(clVolumeRender.initializeGL(argc, argv) != SDK_SUCCESS)
        return SDK_FAILURE;

    if(clVolumeRender.initialize() !=  SDK_SUCCESS)
        return SDK_FAILURE;

    if(!clVolumeRender.parseCommandLine(argc, argv))
        return SDK_FAILURE;

    if(clVolumeRender.isDumpBinaryEnabled())
    {
        return clVolumeRender.genBinaryImage();
    }
    else
    {
        int status = clVolumeRender.setup();
        if(status !=  SDK_SUCCESS)
        {
            if(status == SDK_FAILURE)
                return SDK_FAILURE;
            else
                return SDK_SUCCESS;
        }

        if(clVolumeRender.run() !=  SDK_SUCCESS)
            return SDK_FAILURE;

        if(clVolumeRender.verifyResults() !=  SDK_SUCCESS)
            return SDK_FAILURE;
        if(clVolumeRender.cleanup() !=  SDK_SUCCESS)
            return SDK_FAILURE;

        clVolumeRender.printStats();
    }

    return SDK_SUCCESS;
}



