TFWorkerPool
============

Simple Example of a pool of dispatch threads for concurrent processing.

See http://www.wannabegeek.com/?p=551 for more.
