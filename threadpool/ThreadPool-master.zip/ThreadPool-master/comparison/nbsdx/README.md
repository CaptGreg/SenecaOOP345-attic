# Compile command
	g++ -std=c++14 -O3 test.cpp ../src/nbsdx.cpp -lpthread
# Warning
Do not use this.<br>
It gets stuck when runing out_100 sometimes.