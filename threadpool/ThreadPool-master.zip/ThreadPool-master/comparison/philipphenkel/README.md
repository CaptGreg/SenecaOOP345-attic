# Compile command
	g++ -std=c++14 -O3 test.cpp ../src/philipphenkel.cpp -lpthread -lboost_thread -lboost_system
# Warning
Do not use this.<br>
It gets stuck when runing out_100000.