# Compile command
	g++ -std=c++17 -O3 -fconcepts test.cpp ../src/Tyler-Hardin.cpp \
		../../../../Tyler-Hardin/thread_pool/thread_pool.cpp \
		-lpthread