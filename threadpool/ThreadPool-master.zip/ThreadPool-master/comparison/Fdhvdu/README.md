# Compile command
	g++ -std=c++14 -O3 test.cpp ../src/Fdhvdu.cpp \
		../../src/* ../../../lib/src/CScopeGuard.cpp \
		-lpthread