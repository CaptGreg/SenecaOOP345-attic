<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Form</name>
    <message>
        <location filename="../qt_data/fractal_aexion.ui" line="14"/>
        <location filename="../qt_data/fractal_basic.ui" line="14"/>
        <location filename="../qt_data/fractal_benesi.ui" line="14"/>
        <location filename="../qt_data/fractal_boxfold_bulbpow2.ui" line="14"/>
        <location filename="../qt_data/fractal_bristorbrot.ui" line="14"/>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="14"/>
        <location filename="../qt_data/fractal_hypercomplex.ui" line="14"/>
        <location filename="../qt_data/fractal_ifs.ui" line="14"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="14"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="14"/>
        <location filename="../qt_data/fractal_mandelbulb2.ui" line="14"/>
        <location filename="../qt_data/fractal_mandelbulb3.ui" line="14"/>
        <location filename="../qt_data/fractal_mandelbulb4.ui" line="14"/>
        <location filename="../qt_data/fractal_mandelbulb_power_2.ui" line="14"/>
        <location filename="../qt_data/fractal_mandelbulb.ui" line="14"/>
        <location filename="../qt_data/fractal_menger_sponge.ui" line="14"/>
        <location filename="../qt_data/fractal_quaternion.ui" line="14"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="14"/>
        <location filename="../qt_data/fractal_xenodreambuie.ui" line="14"/>
        <location filename="../qt_data/primitive_box.ui" line="14"/>
        <location filename="../qt_data/primitive_circle.ui" line="14"/>
        <location filename="../qt_data/primitive_cone.ui" line="14"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="14"/>
        <location filename="../qt_data/primitive_plane.ui" line="14"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="14"/>
        <location filename="../qt_data/primitive_sphere.ui" line="14"/>
        <location filename="../qt_data/primitive_torus.ui" line="14"/>
        <location filename="../qt_data/primitive_water.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_aexion.ui" line="78"/>
        <source>c add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_benesi.ui" line="20"/>
        <location filename="../qt_data/fractal_bristorbrot.ui" line="20"/>
        <location filename="../qt_data/fractal_hypercomplex.ui" line="20"/>
        <location filename="../qt_data/fractal_mandelbulb2.ui" line="20"/>
        <location filename="../qt_data/fractal_mandelbulb3.ui" line="20"/>
        <location filename="../qt_data/fractal_mandelbulb_power_2.ui" line="20"/>
        <location filename="../qt_data/fractal_menger_sponge.ui" line="20"/>
        <location filename="../qt_data/fractal_quaternion.ui" line="20"/>
        <source>No parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_boxfold_bulbpow2.ui" line="59"/>
        <source>Z scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_boxfold_bulbpow2.ui" line="123"/>
        <source>Box fold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="35"/>
        <source>Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="612"/>
        <location filename="../qt_data/fractal_ifs.ui" line="73"/>
        <source>Dodecahedron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="617"/>
        <source>Octahedron / Cube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="622"/>
        <location filename="../qt_data/fractal_ifs.ui" line="80"/>
        <source>Icosahedron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="607"/>
        <location filename="../qt_data/fractal_ifs.ui" line="87"/>
        <source>Octahedron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="94"/>
        <source>Menger Sponge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="101"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="20"/>
        <location filename="../qt_data/fractal_ifs.ui" line="113"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="35"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="35"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="35"/>
        <source>Main parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="139"/>
        <source>abs (x)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="146"/>
        <source>abs (z)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="175"/>
        <source>vector offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="188"/>
        <location filename="../qt_data/fractal_ifs.ui" line="736"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="292"/>
        <location filename="../qt_data/primitive_box.ui" line="240"/>
        <location filename="../qt_data/primitive_box.ui" line="402"/>
        <location filename="../qt_data/primitive_circle.ui" line="85"/>
        <location filename="../qt_data/primitive_cone.ui" line="50"/>
        <location filename="../qt_data/primitive_cone.ui" line="361"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="40"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="395"/>
        <location filename="../qt_data/primitive_plane.ui" line="119"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="85"/>
        <location filename="../qt_data/primitive_sphere.ui" line="69"/>
        <location filename="../qt_data/primitive_sphere.ui" line="187"/>
        <location filename="../qt_data/primitive_torus.ui" line="92"/>
        <location filename="../qt_data/primitive_torus.ui" line="381"/>
        <location filename="../qt_data/primitive_water.ui" line="56"/>
        <source>z:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="204"/>
        <location filename="../qt_data/fractal_ifs.ui" line="720"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="104"/>
        <location filename="../qt_data/primitive_box.ui" line="131"/>
        <location filename="../qt_data/primitive_box.ui" line="392"/>
        <location filename="../qt_data/primitive_circle.ui" line="198"/>
        <location filename="../qt_data/primitive_cone.ui" line="351"/>
        <location filename="../qt_data/primitive_cone.ui" line="371"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="137"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="161"/>
        <location filename="../qt_data/primitive_plane.ui" line="239"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="188"/>
        <location filename="../qt_data/primitive_sphere.ui" line="144"/>
        <location filename="../qt_data/primitive_sphere.ui" line="174"/>
        <location filename="../qt_data/primitive_torus.ui" line="40"/>
        <location filename="../qt_data/primitive_torus.ui" line="201"/>
        <location filename="../qt_data/primitive_water.ui" line="328"/>
        <source>y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="220"/>
        <location filename="../qt_data/fractal_ifs.ui" line="628"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="120"/>
        <location filename="../qt_data/primitive_box.ui" line="253"/>
        <location filename="../qt_data/primitive_box.ui" line="375"/>
        <location filename="../qt_data/primitive_circle.ui" line="208"/>
        <location filename="../qt_data/primitive_cone.ui" line="387"/>
        <location filename="../qt_data/primitive_cone.ui" line="404"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="57"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="280"/>
        <location filename="../qt_data/primitive_plane.ui" line="226"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="198"/>
        <location filename="../qt_data/primitive_sphere.ui" line="79"/>
        <location filename="../qt_data/primitive_sphere.ui" line="89"/>
        <location filename="../qt_data/primitive_torus.ui" line="124"/>
        <location filename="../qt_data/primitive_torus.ui" line="391"/>
        <location filename="../qt_data/primitive_water.ui" line="370"/>
        <source>x:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="132"/>
        <location filename="../qt_data/fractal_ifs.ui" line="274"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="181"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="162"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="163"/>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="297"/>
        <source>abs (y)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="374"/>
        <source>Menger Sponge mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="386"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="457"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="332"/>
        <source>Main rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="441"/>
        <location filename="../qt_data/fractal_ifs.ui" line="2895"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="512"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="796"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="829"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1140"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1296"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1455"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1589"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="387"/>
        <source>beta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="473"/>
        <location filename="../qt_data/fractal_ifs.ui" line="3484"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="544"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="786"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="906"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1032"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1286"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1376"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1579"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="419"/>
        <source>alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="496"/>
        <location filename="../qt_data/fractal_ifs.ui" line="2246"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="567"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="806"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="942"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1068"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1098"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1344"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1412"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="442"/>
        <source>gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="555"/>
        <source>Box folding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="746"/>
        <source>edge:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="758"/>
        <source>Vectors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="972"/>
        <source>#2:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="988"/>
        <source>y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="1211"/>
        <source>#8:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="1291"/>
        <source>#6:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="1364"/>
        <source>intens.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="1434"/>
        <source>dist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="1539"/>
        <source>#1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="1610"/>
        <source>#9:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="2138"/>
        <source>#4:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="2486"/>
        <source>enable:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="2820"/>
        <source>z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="2836"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="2846"/>
        <source>#5:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="3284"/>
        <source>#7:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="3316"/>
        <source>direction:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="3618"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_ifs.ui" line="3732"/>
        <source>#3:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="61"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="61"/>
        <source>Box folding value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="90"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="68"/>
        <source>Spherical folding
fixed radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="130"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="156"/>
        <source>Box folding limit:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="270"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="252"/>
        <source>Spherical folding
min radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="278"/>
        <source>Spherical folding
offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="626"/>
        <source>Rotation of separate planes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="650"/>
        <source>X Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="952"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1078"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1422"/>
        <source>Positive plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="962"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1088"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1432"/>
        <source>Negative plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="984"/>
        <source>Y Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1318"/>
        <source>Z Axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="306"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1655"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="336"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="501"/>
        <source>Coloring parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="314"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1681"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="362"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="527"/>
        <source>Min radius component:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="321"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1688"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="369"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="534"/>
        <source>Y plane component:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="404"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1771"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="452"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="617"/>
        <source>X plane component:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="411"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1778"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="459"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="624"/>
        <source>Z plane component:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="472"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1839"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="520"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="685"/>
        <source>Absolute value of z:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="501"/>
        <location filename="../qt_data/fractal_mandelbox.ui" line="1868"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="549"/>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="714"/>
        <source>Fixed radius component:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="589"/>
        <source>Generalized FoldBox Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="597"/>
        <source>Tetrahedron</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="602"/>
        <source>Cube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="627"/>
        <source>Box 6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="632"/>
        <source>Box 5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="31"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="61"/>
        <source>Spherical fold size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="38"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="68"/>
        <source>R power:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="125"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="155"/>
        <source>Box fold size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="205"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="235"/>
        <source>Vary scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_generalized_fold_box.ui" line="256"/>
        <location filename="../qt_data/fractal_mandelbox_vary_scale_4d.ui" line="286"/>
        <source>w-axis constant:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbulb4.ui" line="100"/>
        <location filename="../qt_data/fractal_mandelbulb.ui" line="62"/>
        <location filename="../qt_data/fractal_xenodreambuie.ui" line="100"/>
        <source>Alpha angle offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbulb4.ui" line="164"/>
        <location filename="../qt_data/fractal_mandelbulb.ui" line="126"/>
        <location filename="../qt_data/fractal_xenodreambuie.ui" line="164"/>
        <source>Power:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbulb4.ui" line="171"/>
        <location filename="../qt_data/fractal_mandelbulb.ui" line="133"/>
        <location filename="../qt_data/fractal_xenodreambuie.ui" line="171"/>
        <source>Beta angle offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_mandelbulb4.ui" line="178"/>
        <source>Gamma angle offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_smooth_mandelbox.ui" line="282"/>
        <source>Sharpness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="40"/>
        <location filename="../qt_data/primitive_circle.ui" line="146"/>
        <location filename="../qt_data/primitive_cone.ui" line="129"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="96"/>
        <location filename="../qt_data/primitive_plane.ui" line="132"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="146"/>
        <location filename="../qt_data/primitive_torus.ui" line="164"/>
        <location filename="../qt_data/primitive_water.ui" line="73"/>
        <source>Y-axis rotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="72"/>
        <location filename="../qt_data/primitive_circle.ui" line="270"/>
        <location filename="../qt_data/primitive_cone.ui" line="70"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="130"/>
        <location filename="../qt_data/primitive_plane.ui" line="92"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="225"/>
        <location filename="../qt_data/primitive_torus.ui" line="358"/>
        <location filename="../qt_data/primitive_water.ui" line="380"/>
        <source>X-axis rotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="111"/>
        <location filename="../qt_data/primitive_circle.ui" line="277"/>
        <location filename="../qt_data/primitive_cone.ui" line="60"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="375"/>
        <location filename="../qt_data/primitive_plane.ui" line="99"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="232"/>
        <location filename="../qt_data/primitive_sphere.ui" line="233"/>
        <location filename="../qt_data/primitive_torus.ui" line="141"/>
        <location filename="../qt_data/primitive_water.ui" line="202"/>
        <source>Position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="223"/>
        <location filename="../qt_data/primitive_circle.ui" line="218"/>
        <location filename="../qt_data/primitive_cone.ui" line="322"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="154"/>
        <location filename="../qt_data/primitive_plane.ui" line="219"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="208"/>
        <location filename="../qt_data/primitive_sphere.ui" line="157"/>
        <location filename="../qt_data/primitive_torus.ui" line="278"/>
        <location filename="../qt_data/primitive_water.ui" line="338"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="230"/>
        <location filename="../qt_data/primitive_circle.ui" line="139"/>
        <location filename="../qt_data/primitive_cone.ui" line="106"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="368"/>
        <location filename="../qt_data/primitive_plane.ui" line="85"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="139"/>
        <location filename="../qt_data/primitive_sphere.ui" line="226"/>
        <location filename="../qt_data/primitive_torus.ui" line="57"/>
        <location filename="../qt_data/primitive_water.ui" line="66"/>
        <source>Color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="263"/>
        <source>rounding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="298"/>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="305"/>
        <source>depth (y):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="315"/>
        <location filename="../qt_data/primitive_cone.ui" line="235"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="270"/>
        <source>height (z):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="338"/>
        <location filename="../qt_data/primitive_circle.ui" line="228"/>
        <location filename="../qt_data/primitive_cone.ui" line="161"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="123"/>
        <location filename="../qt_data/primitive_plane.ui" line="65"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="218"/>
        <location filename="../qt_data/primitive_torus.ui" line="50"/>
        <location filename="../qt_data/primitive_water.ui" line="387"/>
        <source>Z-axis rotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="345"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="281"/>
        <source>width (x):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="355"/>
        <location filename="../qt_data/primitive_cone.ui" line="397"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="89"/>
        <location filename="../qt_data/primitive_plane.ui" line="271"/>
        <location filename="../qt_data/primitive_sphere.ui" line="219"/>
        <location filename="../qt_data/primitive_torus.ui" line="181"/>
        <location filename="../qt_data/primitive_water.ui" line="430"/>
        <source>Empty inside</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="362"/>
        <location filename="../qt_data/primitive_circle.ui" line="309"/>
        <location filename="../qt_data/primitive_cone.ui" line="245"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="50"/>
        <location filename="../qt_data/primitive_plane.ui" line="155"/>
        <location filename="../qt_data/primitive_rectangle.ui" line="264"/>
        <location filename="../qt_data/primitive_sphere.ui" line="167"/>
        <location filename="../qt_data/primitive_torus.ui" line="246"/>
        <location filename="../qt_data/primitive_water.ui" line="304"/>
        <source>Reflection:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_box.ui" line="385"/>
        <location filename="../qt_data/primitive_cone.ui" line="99"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="222"/>
        <location filename="../qt_data/primitive_sphere.ui" line="134"/>
        <location filename="../qt_data/primitive_torus.ui" line="351"/>
        <source>Repeat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_circle.ui" line="153"/>
        <location filename="../qt_data/primitive_cone.ui" line="252"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="254"/>
        <source>radius (x-y plane):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_cone.ui" line="414"/>
        <location filename="../qt_data/primitive_cylinder.ui" line="147"/>
        <source>Caps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_rectangle.ui" line="291"/>
        <source>height (y):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_sphere.ui" line="59"/>
        <source>Radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_torus.ui" line="134"/>
        <source>Torus radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_torus.ui" line="401"/>
        <source>Tube radius:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_water.ui" line="118"/>
        <source>Wave speed (anim.):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_water.ui" line="195"/>
        <source>Wave amplitude:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_water.ui" line="394"/>
        <source>Wave length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/primitive_water.ui" line="401"/>
        <source>Iterations:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="34"/>
        <source>Scale X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="41"/>
        <source>Invert Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="54"/>
        <source>Invert X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="85"/>
        <source>Invert Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="95"/>
        <source>Scale Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="102"/>
        <source>Scale Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="109"/>
        <source>Offset X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="116"/>
        <source>Offset Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="123"/>
        <source>Offset Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="130"/>
        <source>Angle Mult X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="137"/>
        <source>Angle Mult Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qt_data/fractal_basic.ui" line="144"/>
        <source>Angle Mult Z</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
