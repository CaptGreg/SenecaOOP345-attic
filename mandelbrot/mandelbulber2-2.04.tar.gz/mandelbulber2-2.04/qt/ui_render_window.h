/********************************************************************************
** Form generated from reading UI file 'render_window.ui'
**
** Created by: Qt User Interface Compiler version 5.4.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RENDER_WINDOW_H
#define UI_RENDER_WINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDial>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "color_palette_widget.h"
#include "my_table_widget_anim.hpp"
#include "mycheckbox.h"
#include "mycolorbutton.h"
#include "mydoublespinbox.h"
#include "mygroupbox.h"
#include "myhistogramlabel.h"
#include "mylineedit.h"
#include "mylogwidget.h"
#include "myscrolledarea.h"
#include "myspinbox.h"

QT_BEGIN_NAMESPACE

class Ui_RenderWindow
{
public:
    QAction *actionSave_as_JPG;
    QAction *actionSave_as_PNG;
    QAction *actionSave_as_PNG_16_bit;
    QAction *actionSave_as_PNG_16_bit_with_alpha_channel;
    QAction *actionLoad_settings;
    QAction *actionSave_settings;
    QAction *actionSave_settings_as;
    QAction *actionProgramSettings;
    QAction *actionQuit;
    QAction *actionSave_docks_positions;
    QAction *actionDefault_docks_positions;
    QAction *actionAbout_Qt;
    QAction *actionAbout_Mandelbulber;
    QAction *actionUndo;
    QAction *actionRedo;
    QAction *actionImport_settings_from_old_Mandelbulber;
    QAction *actionLoad_example;
    QAction *actionShow_animation_dock;
    QAction *actionShow_info_dock;
    QAction *actionShow_toolbar;
    QAction *actionStack_all_docks;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_78;
    QVBoxLayout *verticalLayout_center;
    MyScrolledArea *scrollAreaForImage;
    QWidget *scrollAreaWidgetContents;
    QVBoxLayout *scrollAreaLayoutRenderedImage;
    QHBoxLayout *hl_zoom;
    QLabel *label;
    QComboBox *comboBox_image_preview_scale;
    QFrame *line;
    MyCheckBox *checkBox_show_cursor;
    QFrame *line_2;
    QSpacerItem *horizontalSpacer;
    QMenuBar *menubar;
    QMenu *menuImage;
    QMenu *menuFile;
    QMenu *menuView;
    QMenu *menuAbout;
    QMenu *menuEdit;
    QStatusBar *statusbar;
    QDockWidget *dockWidget_image_adjustments;
    QWidget *dockWidgetLeftContents;
    QVBoxLayout *verticalLayout_23;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_2;
    QVBoxLayout *verticalLayout_19;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout_40;
    QGridLayout *gridLayout_18;
    MySpinBox *spinboxInt_image_height;
    QSlider *sliderInt_image_height;
    QLabel *label_100;
    QLabel *label_101;
    QSlider *sliderInt_image_width;
    MySpinBox *spinboxInt_image_width;
    QLabel *label_102;
    QComboBox *comboBox_image_proportion;
    QGroupBox *groupBox_6;
    QVBoxLayout *verticalLayout_71;
    QGridLayout *gridLayout_32;
    QPushButton *pushButton_resolution_preset_2160;
    QPushButton *pushButton_resolution_preset_720;
    QPushButton *pushButton_resolution_preset_1080;
    QPushButton *pushButton_resolution_preset_4320;
    QPushButton *pushButton_resolution_preset_480;
    QPushButton *pushButton_resolution_preset_1440;
    QPushButton *pushButton_resolution_preset_240;
    QPushButton *pushButton_resolution_preset_600;
    QPushButton *pushButton_resolution_preset_1200;
    QGroupBox *groupBox_ImageAdjustments;
    QVBoxLayout *verticalLayout_20;
    QGridLayout *gridLayout;
    MyDoubleSpinBox *spinbox_contrast;
    MyDoubleSpinBox *spinbox_gamma;
    QLabel *label_4;
    MyDoubleSpinBox *spinbox_brightness;
    QLabel *label_3;
    QSlider *slider_contrast;
    QSlider *slider_brightness;
    QLabel *label_45;
    QSlider *slider_gamma;
    MyCheckBox *checkBox_hdr;
    QPushButton *pushButton_apply_image_changes;
    QGroupBox *groupBox_5;
    QVBoxLayout *verticalLayout_58;
    QGridLayout *gridLayout_25;
    QLabel *label_54;
    MyDoubleSpinBox *spinbox_fov;
    QSlider *slider_fov;
    QComboBox *comboBox_perspective_type;
    QLabel *label_126;
    MyCheckBox *checkBox_legacy_coordinate_system;
    QSpacerItem *verticalSpacer_3;
    QDockWidget *dockWidget_navigation;
    QWidget *dockWidgetRightContents;
    QVBoxLayout *verticalLayout_24;
    QGridLayout *gridLayout_26;
    QPushButton *pushButton_render;
    QPushButton *pushButton_stop;
    QScrollArea *scrollArea_4;
    QWidget *scrollAreaWidgetContents_5;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *vl_side_functions;
    QGroupBox *groupBox_coordinates;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox_cameraPosition;
    QVBoxLayout *verticalLayout_5;
    QFrame *vect3_camera;
    QVBoxLayout *verticalLayout_14;
    QFormLayout *formLayout_coordinates_4;
    QLabel *label_18;
    MyLineEdit *vect3_camera_x;
    QLabel *label_19;
    MyLineEdit *vect3_camera_y;
    QLabel *label_20;
    MyLineEdit *vect3_camera_z;
    QGroupBox *groupBox_targetPosition;
    QVBoxLayout *verticalLayout_54;
    QFrame *vect3_target;
    QVBoxLayout *verticalLayout_55;
    QFormLayout *formLayout_coordinates_9;
    QLabel *label_121;
    MyLineEdit *vect3_target_x;
    QLabel *label_122;
    MyLineEdit *vect3_target_y;
    QLabel *label_123;
    MyLineEdit *vect3_target_z;
    QPushButton *pushButton_reset_view;
    QComboBox *comboBox_camera_movement_mode;
    QGridLayout *gridLayout_24;
    QLabel *label_124;
    MyLineEdit *logedit_camera_distance_to_target;
    QSlider *logslider_camera_distance_to_target;
    QGridLayout *gridLayout_arrows;
    QPushButton *bu_move_right;
    QPushButton *bu_move_left;
    QPushButton *bu_move_up;
    QPushButton *bu_move_forward;
    QPushButton *bu_move_backward;
    QPushButton *bu_move_down;
    QFrame *single_camera_movenent_step_de;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout;
    QLabel *label_9;
    MyLineEdit *logedit_camera_movement_step;
    QSlider *logslider_camera_movement_step;
    QComboBox *comboBox_camera_absolute_distance_mode;
    QGroupBox *groupBox_rotation;
    QVBoxLayout *verticalLayout_3;
    QGridLayout *gridLayout_2;
    QPushButton *bu_rotate_left;
    QPushButton *bu_rotate_up;
    QPushButton *bu_rotate_right;
    QPushButton *bu_rotate_roll_right;
    QPushButton *bu_rotate_roll_left;
    QPushButton *bu_rotate_down;
    QFrame *single_camera_movenent_step_de_3;
    QVBoxLayout *verticalLayout_57;
    QHBoxLayout *horizontalLayout_11;
    QLabel *label_125;
    MyDoubleSpinBox *spinbox_camera_rotation_step;
    QComboBox *comboBox_camera_rotation_mode;
    QComboBox *comboBox_camera_straight_rotation;
    QFrame *vect3_view_angle;
    QVBoxLayout *verticalLayout_13;
    QFormLayout *formLayout_coordinates;
    QLabel *label_15;
    MyLineEdit *vect3_camera_rotation_x;
    QLabel *label_16;
    MyLineEdit *vect3_camera_rotation_y;
    QLabel *label_17;
    MyLineEdit *vect3_camera_rotation_z;
    QLabel *label_mouse_click_functions;
    QComboBox *comboBox_mouse_click_function;
    QSpacerItem *verticalSpacer;
    QToolBar *toolBar;
    QDockWidget *dockWidget_effects;
    QWidget *dockWidgetContents_3;
    QVBoxLayout *verticalLayout_6;
    QScrollArea *scrollArea_2;
    QWidget *scrollAreaWidgetContents_3;
    QVBoxLayout *verticalLayout_26;
    QTabWidget *tabWidget_2;
    QWidget *tab;
    QVBoxLayout *verticalLayout_63;
    QScrollArea *scrollArea_6;
    QWidget *scrollAreaWidgetContents_7;
    QVBoxLayout *verticalLayout_29;
    QGridLayout *gridLayout_7;
    QLabel *label_172;
    MyColorButton *colorButton_transparency_interior_color;
    QSlider *slider_specular;
    MyDoubleSpinBox *spinbox_ambient_occlusion;
    MyDoubleSpinBox *spinbox_reflect;
    QSlider *slider_shading;
    QLabel *label_55;
    QLabel *label_56;
    QSlider *slider_reflect;
    MyDoubleSpinBox *spinbox_shading;
    MyDoubleSpinBox *spinbox_specular;
    QLabel *label_52;
    QSlider *slider_ambient_occlusion;
    QLabel *label_53;
    QSlider *slider_transparency_of_surface;
    QLabel *label_171;
    QLabel *label_170;
    MyDoubleSpinBox *spinbox_transparency_of_surface;
    QLabel *label_173;
    QSlider *slider_transparency_index_of_refraction;
    MyLineEdit *logedit_transparency_of_interior;
    MyDoubleSpinBox *spinbox_transparency_index_of_refraction;
    QSlider *logslider_transparency_of_interior;
    MyCheckBox *checkBox_fresnel_reflectance;
    MyGroupBox *groupCheck_ambient_occlusion_enabled;
    QVBoxLayout *verticalLayout_31;
    QGridLayout *gridLayout_11;
    QSlider *slider_ambient_occlusion_fast_tune;
    QLabel *label_68;
    QSlider *sliderInt_ambient_occlusion_quality;
    QLabel *label_69;
    QLabel *label_70;
    MySpinBox *spinboxInt_ambient_occlusion_quality;
    QComboBox *comboBox_ambient_occlusion_mode;
    MyDoubleSpinBox *spinbox_ambient_occlusion_fast_tune;
    QFrame *frame_lightmap_texture;
    QVBoxLayout *verticalLayout_69;
    QGridLayout *gridLayout_34;
    QPushButton *button_selectLightMapTexture;
    MyLineEdit *text_file_lightmap;
    QLabel *label_133;
    QLabel *label_lightmapTextureView;
    MyGroupBox *groupCheck_fractal_color;
    QVBoxLayout *verticalLayout_32;
    QGridLayout *gridLayout_12;
    QLabel *label_75;
    MySpinBox *spinboxInt_coloring_random_seed;
    QLabel *label_74;
    QLabel *label_73;
    MyDoubleSpinBox *spinbox_coloring_saturation;
    ColorPaletteWidget *colorpalette_surface_color_palette;
    MyDoubleSpinBox *spinbox_coloring_speed;
    QPushButton *pushButton_getPaletteFromImage;
    QSlider *slider_coloring_speed;
    QSlider *slider_coloring_saturation;
    QLabel *label_127;
    QLabel *label_71;
    QSlider *sliderInt_coloring_palette_size;
    MySpinBox *spinboxInt_coloring_palette_size;
    QLabel *label_72;
    QSlider *slider_coloring_palette_offset;
    MyDoubleSpinBox *spinbox_coloring_palette_offset;
    QPushButton *pushButton_randomPalette;
    QPushButton *pushButton_randomize;
    MyGroupBox *groupCheck_env_mapping_enable;
    QVBoxLayout *verticalLayout_70;
    QGridLayout *gridLayout_33;
    QPushButton *button_selectEnvMapTexture;
    MyLineEdit *text_file_envmap;
    QLabel *label_132;
    QLabel *label_envmapTextureView;
    QWidget *tab_2;
    QVBoxLayout *verticalLayout_64;
    QScrollArea *scrollArea_7;
    QWidget *scrollAreaWidgetContents_8;
    QVBoxLayout *verticalLayout_34;
    MyGroupBox *groupCheck_raytraced_reflections;
    QVBoxLayout *verticalLayout_72;
    QGridLayout *gridLayout_9;
    MySpinBox *spinboxInt_reflections_max;
    QLabel *label_62;
    QSlider *sliderInt_reflections_max;
    MyGroupBox *groupCheck_DOF_enabled;
    QVBoxLayout *verticalLayout_73;
    QGridLayout *gridLayout_35;
    QLabel *label_131;
    QLabel *label_136;
    QSlider *logslider_DOF_focus;
    MyLineEdit *logedit_DOF_focus;
    QSlider *slider_DOF_radius;
    MyDoubleSpinBox *spinbox_DOF_radius;
    QPushButton *pushButton_DOF_update;
    QPushButton *pushButton_DOF_set_focus;
    QSpacerItem *verticalSpacer_2;
    QWidget *tab_3;
    QVBoxLayout *verticalLayout_65;
    QScrollArea *scrollArea_8;
    QWidget *scrollAreaWidgetContents_9;
    QVBoxLayout *verticalLayout_35;
    MyGroupBox *groupCheck_basic_fog_enabled;
    QVBoxLayout *verticalLayout_30;
    QGridLayout *gridLayout_10;
    QSlider *logslider_basic_fog_visibility;
    MyLineEdit *logedit_basic_fog_visibility;
    QLabel *label_64;
    MyColorButton *colorButton_basic_fog_color;
    QLabel *label_63;
    QPushButton *pushButton_set_fog_by_mouse;
    MyGroupBox *groupCheck_glow_enabled;
    QVBoxLayout *verticalLayout_28;
    QGridLayout *gridLayout_14;
    QLabel *label_88;
    QLabel *label_89;
    MyColorButton *colorButton_glow_color_2;
    QSlider *logslider_glow_intensity;
    MyColorButton *colorButton_glow_color_1;
    QLabel *label_87;
    MyLineEdit *logedit_glow_intensity;
    MyGroupBox *groupCheck_volumetric_fog_enabled;
    QVBoxLayout *verticalLayout_33;
    QGridLayout *gridLayout_13;
    MyLineEdit *logedit_volumetric_fog_density;
    QLabel *label_77;
    QLabel *label_76;
    QLabel *label_67;
    QSlider *logslider_volumetric_fog_colour_2_distance;
    MyLineEdit *logedit_volumetric_fog_colour_2_distance;
    MyColorButton *colorButton_fog_color_1;
    QSlider *logslider_volumetric_fog_distance_factor;
    MyLineEdit *logedit_volumetric_fog_colour_1_distance;
    QSlider *logslider_volumetric_fog_colour_1_distance;
    QLabel *label_65;
    QLabel *label_78;
    MyColorButton *colorButton_fog_color_2;
    QLabel *label_79;
    MyColorButton *colorButton_fog_color_3;
    MyLineEdit *logedit_volumetric_fog_distance_factor;
    QSlider *logslider_volumetric_fog_density;
    QPushButton *button_calculateFog;
    QLabel *label_66;
    MyGroupBox *groupCheck_iteration_fog_enable;
    QVBoxLayout *verticalLayout_27;
    QGridLayout *gridLayout_8;
    MyColorButton *colorButton_iteration_fog_color_1;
    MyDoubleSpinBox *spinbox_iteration_fog_opacity_trim;
    QLabel *label_85;
    MyDoubleSpinBox *spinbox_iteration_fog_color_1_maxiter;
    MyLineEdit *logedit_iteration_fog_opacity;
    MyColorButton *colorButton_iteration_fog_color_3;
    QSlider *slider_iteration_fog_color_2_maxiter;
    QSlider *slider_iteration_fog_opacity_trim;
    QSlider *slider_iteration_fog_color_1_maxiter;
    MyColorButton *colorButton_iteration_fog_color_2;
    QLabel *label_84;
    QSlider *logslider_iteration_fog_opacity;
    MyDoubleSpinBox *spinbox_iteration_fog_color_2_maxiter;
    QLabel *label_80;
    QLabel *label_86;
    QLabel *label_81;
    QLabel *label_83;
    QLabel *label_82;
    QSpacerItem *verticalSpacer_4;
    QWidget *tab_4;
    QVBoxLayout *verticalLayout_66;
    QScrollArea *scrollArea_9;
    QWidget *scrollAreaWidgetContents_10;
    QVBoxLayout *verticalLayout_36;
    QGroupBox *groupBox_14;
    QVBoxLayout *verticalLayout_37;
    QGridLayout *gridLayout_15;
    MyColorButton *colorButton_background_color_2;
    QLabel *label_58;
    QLabel *label_57;
    MyColorButton *colorButton_background_color_1;
    QLabel *label_59;
    MyColorButton *colorButton_background_color_3;
    MyGroupBox *groupCheck_textured_background;
    QVBoxLayout *verticalLayout_38;
    QGridLayout *gridLayout_16;
    QPushButton *button_selectBackgroundTexture;
    MyLineEdit *text_file_background;
    QLabel *label_61;
    QLabel *label_90;
    QComboBox *comboBox_textured_background_map_type;
    QLabel *label_backgroundTextureView;
    QSpacerItem *verticalSpacer_5;
    QWidget *tab_5;
    QVBoxLayout *verticalLayout_67;
    QScrollArea *scrollArea_10;
    QWidget *scrollAreaWidgetContents_11;
    QVBoxLayout *verticalLayout_41;
    QGroupBox *groupBox_7;
    QVBoxLayout *verticalLayout_12;
    MyCheckBox *checkBox_shadows_enabled;
    MyCheckBox *checkBox_penetrating_lights;
    MyGroupBox *groupCheck_main_light_enable;
    QVBoxLayout *verticalLayout_8;
    QGridLayout *gridLayoutMainLightSource;
    QSlider *slider_shadows_cone_angle;
    QLabel *label_8;
    QLabel *label_2;
    MyDoubleSpinBox *spinboxd_main_light_alpha;
    MyDoubleSpinBox *spinbox_main_light_visibility_size;
    MyDoubleSpinBox *spinbox_main_light_intensity;
    MyDoubleSpinBox *spinbox_main_light_visibility;
    QLabel *label_5;
    MyDoubleSpinBox *spinbox_shadows_cone_angle;
    QLabel *label_10;
    QSlider *slider_main_light_visibility_size;
    MyDoubleSpinBox *spinboxd_main_light_beta;
    QLabel *label_30;
    QSlider *slider_main_light_visibility;
    QLabel *label_6;
    QLabel *label_7;
    QSlider *slider_main_light_intensity;
    MyColorButton *colorButton_main_light_colour;
    QDial *dial_main_light_alpha;
    QDial *dial_main_light_beta;
    MyCheckBox *checkBox_main_light_position_relative;
    QGroupBox *groupBox_Lights;
    QVBoxLayout *verticalLayout_9;
    QGridLayout *gridLayout_4;
    MyGroupBox *groupCheck_aux_light_enabled_1;
    QVBoxLayout *verticalLayout_10;
    QFormLayout *formLayout_coordinates_5;
    QLabel *label_21;
    MyLineEdit *vect3_aux_light_position_1_x;
    QLabel *label_22;
    MyLineEdit *vect3_aux_light_position_1_y;
    QLabel *label_23;
    MyLineEdit *vect3_aux_light_position_1_z;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_11;
    MyLineEdit *logedit_aux_light_intensity_1;
    QSlider *logslider_aux_light_intensity_1;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_12;
    MyColorButton *colorButton_aux_light_colour_1;
    QPushButton *pushButton_place_light_by_mouse_1;
    MyGroupBox *groupCheck_aux_light_enabled_2;
    QVBoxLayout *verticalLayout_11;
    QFormLayout *formLayout_coordinates_6;
    QLabel *label_24;
    MyLineEdit *vect3_aux_light_position_2_x;
    QLabel *label_25;
    MyLineEdit *vect3_aux_light_position_2_y;
    QLabel *label_26;
    MyLineEdit *vect3_aux_light_position_2_z;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_13;
    MyLineEdit *logedit_aux_light_intensity_2;
    QSlider *logslider_aux_light_intensity_2;
    QHBoxLayout *horizontalLayout_6;
    QLabel *label_14;
    MyColorButton *colorButton_aux_light_colour_2;
    QPushButton *pushButton_place_light_by_mouse_2;
    MyGroupBox *groupCheck_aux_light_enabled_3;
    QVBoxLayout *verticalLayout_15;
    QFormLayout *formLayout_coordinates_7;
    QLabel *label_27;
    MyLineEdit *vect3_aux_light_position_3_x;
    QLabel *label_28;
    MyLineEdit *vect3_aux_light_position_3_y;
    QLabel *label_29;
    MyLineEdit *vect3_aux_light_position_3_z;
    QHBoxLayout *horizontalLayout_7;
    QLabel *label_31;
    MyLineEdit *logedit_aux_light_intensity_3;
    QSlider *logslider_aux_light_intensity_3;
    QHBoxLayout *horizontalLayout_8;
    QLabel *label_32;
    MyColorButton *colorButton_aux_light_colour_3;
    QPushButton *pushButton_place_light_by_mouse_3;
    MyGroupBox *groupCheck_aux_light_enabled_4;
    QVBoxLayout *verticalLayout_16;
    QFormLayout *formLayout_coordinates_8;
    QLabel *label_33;
    MyLineEdit *vect3_aux_light_position_4_x;
    QLabel *label_34;
    MyLineEdit *vect3_aux_light_position_4_y;
    QLabel *label_35;
    MyLineEdit *vect3_aux_light_position_4_z;
    QHBoxLayout *horizontalLayout_9;
    QLabel *label_36;
    MyLineEdit *logedit_aux_light_intensity_4;
    QSlider *logslider_aux_light_intensity_4;
    QHBoxLayout *horizontalLayout_10;
    QLabel *label_37;
    MyColorButton *colorButton_aux_light_colour_4;
    QPushButton *pushButton_place_light_by_mouse_4;
    QGroupBox *groupBox_8;
    QVBoxLayout *verticalLayout_17;
    QGridLayout *gridLayout_5;
    QLabel *label_38;
    QSlider *logslider_aux_light_visibility_size;
    QSlider *logslider_aux_light_visibility;
    MyLineEdit *logedit_aux_light_visibility;
    MyLineEdit *logedit_aux_light_visibility_size;
    QLabel *label_39;
    QLabel *label_134;
    QSlider *logslider_aux_light_manual_placement_dist;
    MyLineEdit *logedit_aux_light_manual_placement_dist;
    QGroupBox *groupBox_9;
    QVBoxLayout *verticalLayout_18;
    QGridLayout *gridLayout_6;
    QSlider *logslider_aux_light_volumetric_intensity_1;
    QLabel *label_40;
    QLabel *label_41;
    QLabel *label_42;
    MyLineEdit *logedit_aux_light_volumetric_intensity_3;
    MyLineEdit *logedit_aux_light_volumetric_intensity_2;
    QSlider *logslider_main_light_volumetric_intensity;
    MyLineEdit *logedit_main_light_volumetric_intensity;
    MyLineEdit *logedit_aux_light_volumetric_intensity_1;
    QLabel *label_43;
    QSlider *logslider_aux_light_volumetric_intensity_3;
    QLabel *label_44;
    QSlider *logslider_aux_light_volumetric_intensity_4;
    MyLineEdit *logedit_aux_light_volumetric_intensity_4;
    QSlider *logslider_aux_light_volumetric_intensity_2;
    MyCheckBox *checkBox_main_light_volumetric_enabled;
    QCheckBox *checkBox_aux_light_volumetric_enabled_1;
    QCheckBox *checkBox_aux_light_volumetric_enabled_2;
    QCheckBox *checkBox_aux_light_volumetric_enabled_3;
    QCheckBox *checkBox_aux_light_volumetric_enabled_4;
    MyGroupBox *groupCheck_fake_lights_enabled;
    QVBoxLayout *verticalLayout_39;
    QGridLayout *gridLayout_17;
    MySpinBox *spinboxInt_fake_lights_min_iter;
    QLabel *label_94;
    MySpinBox *spinboxInt_fake_lights_max_iter;
    MyLineEdit *logedit_fake_lights_intensity;
    QSlider *sliderInt_fake_lights_max_iter;
    QSlider *logslider_fake_lights_intensity;
    QLabel *label_60;
    QSlider *logslider_fake_lights_visibility;
    QLabel *label_92;
    MyDoubleSpinBox *spinbox_fake_lights_visibility_size;
    MyLineEdit *logedit_fake_lights_visibility;
    QLabel *label_97;
    QLabel *label_91;
    QSlider *slider_fake_lights_visibility_size;
    QLabel *label_93;
    QSlider *sliderInt_fake_lights_min_iter;
    QLabel *label_95;
    QLabel *label_96;
    QLabel *label_98;
    MyLineEdit *vect3_fake_lights_orbit_trap_x;
    MyLineEdit *vect3_fake_lights_orbit_trap_y;
    MyLineEdit *vect3_fake_lights_orbit_trap_z;
    QSpacerItem *verticalSpacer_6;
    QDockWidget *dockWidget_fractal;
    QWidget *dockWidgetContents_2;
    QVBoxLayout *verticalLayout_7;
    QScrollArea *scrollArea_5;
    QWidget *scrollAreaWidgetContents_6;
    QVBoxLayout *verticalLayout_59;
    QTabWidget *tabWidget_fractal;
    QWidget *tabWidget_fractal_formulas;
    QVBoxLayout *verticalLayout_21;
    QTabWidget *tabWidget_fractals;
    QWidget *tab_fractal_formula_1;
    QVBoxLayout *verticalLayout_49;
    QScrollArea *scrollArea_fractal_1;
    QWidget *scrollAreaWidgetContents_fractal_1;
    QVBoxLayout *verticalLayoutScroll_fractal_1;
    QFrame *frame_iterations_formula_1;
    QVBoxLayout *verticalLayout_56;
    QGridLayout *gridLayout_27;
    QLabel *label_formula_iterations_1;
    QSlider *sliderInt_formula_iterations_1;
    MySpinBox *spinboxInt_formula_iterations_1;
    QComboBox *comboBox_formula_1;
    QGroupBox *groupBox_formula_parameters_1;
    QVBoxLayout *verticalLayout_77;
    QVBoxLayout *verticalLayout_fractal_1;
    QGroupBox *groupBox_formula_transform_1;
    QVBoxLayout *verticalLayout_22;
    QGridLayout *gridLayout_41;
    QLabel *label_158;
    MyLineEdit *vect3_formula_position_1_z;
    QDial *dial3_formula_rotation_1_y;
    QLabel *label_163;
    QLabel *label_157;
    QLabel *label_159;
    MyLineEdit *vect3_formula_position_1_y;
    MyDoubleSpinBox *spinboxd3_formula_rotation_1_z;
    MyDoubleSpinBox *spinboxd3_formula_rotation_1_y;
    QLabel *label_167;
    MyDoubleSpinBox *spinboxd3_formula_rotation_1_x;
    MyLineEdit *vect3_formula_position_1_x;
    QDial *dial3_formula_rotation_1_x;
    MyLineEdit *vect3_formula_repeat_1_x;
    QDial *dial3_formula_rotation_1_z;
    QLabel *label_160;
    QLabel *label_162;
    QLabel *label_161;
    MyLineEdit *vect3_formula_repeat_1_y;
    QLabel *label_165;
    MyLineEdit *vect3_formula_repeat_1_z;
    QLabel *label_166;
    QLabel *label_164;
    QLabel *label_168;
    MyLineEdit *logedit_formula_scale_1;
    QSlider *logslider_formula_scale_1;
    QSpacerItem *verticalSpacer_12;
    QWidget *tab_fractal_formula_2;
    QVBoxLayout *verticalLayout_50;
    QScrollArea *scrollArea_fractal_2;
    QWidget *scrollAreaWidgetContents_fractal_2;
    QVBoxLayout *verticalLayoutScroll_fractal_3;
    QFrame *frame_iterations_formula_2;
    QVBoxLayout *verticalLayout_83;
    QGridLayout *gridLayout_44;
    QLabel *label_formula_iterations_2;
    QSlider *sliderInt_formula_iterations_2;
    MySpinBox *spinboxInt_formula_iterations_2;
    QComboBox *comboBox_formula_2;
    QGroupBox *groupBox_formula_parameters_2;
    QVBoxLayout *verticalLayout_84;
    QVBoxLayout *verticalLayout_fractal_2;
    QGroupBox *groupBox_formula_transform_2;
    QVBoxLayout *verticalLayout_85;
    QGridLayout *gridLayout_45;
    QLabel *label_179;
    MyLineEdit *vect3_formula_position_2_z;
    QDial *dial3_formula_rotation_2_y;
    QLabel *label_180;
    QLabel *label_181;
    QLabel *label_182;
    MyDoubleSpinBox *spinboxd3_formula_rotation_2_z;
    MyLineEdit *vect3_formula_position_2_y;
    MyDoubleSpinBox *spinboxd3_formula_rotation_2_y;
    QLabel *label_183;
    MyLineEdit *vect3_formula_position_2_x;
    MyDoubleSpinBox *spinboxd3_formula_rotation_2_x;
    QDial *dial3_formula_rotation_2_x;
    MyLineEdit *vect3_formula_repeat_2_x;
    QDial *dial3_formula_rotation_2_z;
    QLabel *label_184;
    QLabel *label_186;
    QLabel *label_185;
    MyLineEdit *vect3_formula_repeat_2_y;
    QLabel *label_187;
    MyLineEdit *vect3_formula_repeat_2_z;
    QLabel *label_188;
    QLabel *label_189;
    QSlider *logslider_formula_scale_2;
    MyLineEdit *logedit_formula_scale_2;
    QLabel *label_214;
    QSpacerItem *verticalSpacer_14;
    QWidget *tab_fractal_formula_3;
    QVBoxLayout *verticalLayout_51;
    QScrollArea *scrollArea_fractal_3;
    QWidget *scrollAreaWidgetContents_fractal_3;
    QVBoxLayout *verticalLayoutScroll_fractal_4;
    QFrame *frame_iterations_formula_3;
    QVBoxLayout *verticalLayout_86;
    QGridLayout *gridLayout_46;
    QLabel *label_formula_iterations_3;
    QSlider *sliderInt_formula_iterations_3;
    MySpinBox *spinboxInt_formula_iterations_3;
    QComboBox *comboBox_formula_3;
    QGroupBox *groupBox_formula_parameters_3;
    QVBoxLayout *verticalLayout_87;
    QVBoxLayout *verticalLayout_fractal_3;
    QGroupBox *groupBox_formula_transform_3;
    QVBoxLayout *verticalLayout_88;
    QGridLayout *gridLayout_47;
    MyDoubleSpinBox *spinboxd3_formula_rotation_3_y;
    QLabel *label_190;
    MyLineEdit *vect3_formula_position_3_z;
    QDial *dial3_formula_rotation_3_y;
    QLabel *label_191;
    QLabel *label_192;
    QLabel *label_193;
    MyLineEdit *vect3_formula_position_3_y;
    MyDoubleSpinBox *spinboxd3_formula_rotation_3_z;
    QLabel *label_194;
    MyDoubleSpinBox *spinboxd3_formula_rotation_3_x;
    MyLineEdit *vect3_formula_position_3_x;
    QDial *dial3_formula_rotation_3_x;
    MyLineEdit *vect3_formula_repeat_3_x;
    QDial *dial3_formula_rotation_3_z;
    QLabel *label_195;
    QLabel *label_197;
    QLabel *label_196;
    MyLineEdit *vect3_formula_repeat_3_y;
    QLabel *label_198;
    MyLineEdit *vect3_formula_repeat_3_z;
    QLabel *label_199;
    QLabel *label_200;
    QSlider *logslider_formula_scale_3;
    MyLineEdit *logedit_formula_scale_3;
    QLabel *label_215;
    QSpacerItem *verticalSpacer_15;
    QWidget *tab_fractal_formula_4;
    QVBoxLayout *verticalLayout_52;
    QScrollArea *scrollArea_fractal_4;
    QWidget *scrollAreaWidgetContents_fractal_4;
    QVBoxLayout *verticalLayoutScroll_fractal_5;
    QFrame *frame_iterations_formula_4;
    QVBoxLayout *verticalLayout_89;
    QGridLayout *gridLayout_48;
    QLabel *label_formula_iterations_4;
    QSlider *sliderInt_formula_iterations_4;
    MySpinBox *spinboxInt_formula_iterations_4;
    QComboBox *comboBox_formula_4;
    QGroupBox *groupBox_formula_parameters_4;
    QVBoxLayout *verticalLayout_90;
    QVBoxLayout *verticalLayout_fractal_4;
    QGroupBox *groupBox_formula_transform_4;
    QVBoxLayout *verticalLayout_91;
    QGridLayout *gridLayout_49;
    QLabel *label_201;
    MyLineEdit *vect3_formula_position_4_z;
    QDial *dial3_formula_rotation_4_y;
    QLabel *label_202;
    QLabel *label_203;
    QLabel *label_204;
    MyDoubleSpinBox *spinboxd3_formula_rotation_4_z;
    MyLineEdit *vect3_formula_position_4_y;
    MyDoubleSpinBox *spinboxd3_formula_rotation_4_y;
    QLabel *label_205;
    MyLineEdit *vect3_formula_position_4_x;
    MyDoubleSpinBox *spinboxd3_formula_rotation_4_x;
    QDial *dial3_formula_rotation_4_x;
    MyLineEdit *vect3_formula_repeat_4_x;
    QDial *dial3_formula_rotation_4_z;
    QLabel *label_206;
    QLabel *label_208;
    QLabel *label_207;
    MyLineEdit *vect3_formula_repeat_4_y;
    QLabel *label_209;
    MyLineEdit *vect3_formula_repeat_4_z;
    QLabel *label_210;
    QLabel *label_211;
    QSlider *logslider_formula_scale_4;
    MyLineEdit *logedit_formula_scale_4;
    QSpacerItem *verticalSpacer_16;
    QWidget *tabWidget_fractal_common;
    QVBoxLayout *verticalLayout_47;
    QScrollArea *scrollArea_11;
    QWidget *scrollAreaWidgetContents_12;
    QVBoxLayout *verticalLayout_68;
    MyGroupBox *groupCheck_julia_mode;
    QVBoxLayout *verticalLayout_48;
    QGridLayout *gridLayout_22;
    QLabel *label_116;
    QLabel *label_113;
    MyLineEdit *vect3_julia_c_y;
    MyLineEdit *vect3_julia_c_x;
    QLabel *label_120;
    QLabel *label_115;
    MyLineEdit *vect3_julia_c_z;
    QPushButton *pushButton_get_julia_constant;
    QGridLayout *gridLayout_3;
    QLabel *label_135;
    QSlider *slider_fractal_constant_factor;
    MyDoubleSpinBox *spinbox_fractal_constant_factor;
    QGridLayout *gridLayout_36;
    MyLineEdit *vect3_fractal_position_z;
    QLabel *label_139;
    QLabel *label_140;
    MyLineEdit *vect3_fractal_position_y;
    QLabel *label_46;
    MyLineEdit *vect3_fractal_position_x;
    QLabel *label_138;
    QLabel *label_137;
    QDial *dial3_fractal_rotation_y;
    QDial *dial3_fractal_rotation_x;
    MyDoubleSpinBox *spinboxd3_fractal_rotation_x;
    MyDoubleSpinBox *spinboxd3_fractal_rotation_y;
    QDial *dial3_fractal_rotation_z;
    MyDoubleSpinBox *spinboxd3_fractal_rotation_z;
    QLabel *label_48;
    QLabel *label_47;
    MyLineEdit *vect3_repeat_x;
    MyLineEdit *vect3_repeat_y;
    MyLineEdit *vect3_repeat_z;
    QLabel *label_repeat_x_2;
    QLabel *label_repeat_y_2;
    QLabel *label_repeat_z_2;
    QLabel *label_145;
    QSpacerItem *verticalSpacer_7;
    QWidget *tabWidget_fractal_hybrid;
    QVBoxLayout *verticalLayout_53;
    QGridLayout *gridLayout_28;
    MyCheckBox *checkBox_hybrid_fractal_enable;
    MyCheckBox *checkBox_linear_DE_mode;
    MyGroupBox *groupCheck_boolean_operators;
    QVBoxLayout *verticalLayout_76;
    QGridLayout *gridLayout_40;
    QComboBox *comboBox_boolean_operator_1;
    QLabel *label_154;
    QComboBox *comboBox_boolean_operator_2;
    QComboBox *comboBox_boolean_operator_3;
    QLabel *label_155;
    QLabel *label_156;
    MyGroupBox *groupCheck_box_folding;
    QVBoxLayout *verticalLayout_80;
    QGridLayout *gridLayout_42;
    QLabel *label_128;
    QSlider *slider_box_folding_limit;
    MyDoubleSpinBox *spinbox_box_folding_limit;
    QLabel *label_129;
    QSlider *slider_box_folding_value;
    MyDoubleSpinBox *spinbox_box_folding_value;
    MyGroupBox *groupCheck_spherical_folding;
    QVBoxLayout *verticalLayout_81;
    QGridLayout *gridLayout_43;
    QLabel *label_130;
    QSlider *slider_spherical_folding_outher;
    MyDoubleSpinBox *spinbox_spherical_folding_outher;
    QLabel *label_169;
    QSlider *slider_spherical_folding_inner;
    MyDoubleSpinBox *spinbox_spherical_folding_inner;
    QSpacerItem *verticalSpacer_10;
    QWidget *tab_primitives;
    QVBoxLayout *verticalLayout_25;
    QScrollArea *scrollArea_primitives;
    QWidget *scrollAreaWidgetContents_primitives;
    QVBoxLayout *verticalLayout_74;
    QGridLayout *gridLayout_23;
    QPushButton *pushButton_add_primitive_cylinder;
    QPushButton *pushButton_add_primitive_cone;
    QPushButton *pushButton_add_primitive_rectangle;
    QPushButton *pushButton_add_primitive_circle;
    QPushButton *pushButton_add_primitive_box;
    QPushButton *pushButton_add_primitive_water;
    QPushButton *pushButton_add_primitive_plane;
    QPushButton *pushButton_add_primitive_torus;
    QPushButton *pushButton_add_primitive_sphere;
    QGridLayout *gridLayout_37;
    MyLineEdit *vect3_all_primitives_position_z;
    MyDoubleSpinBox *spinboxd3_all_primitives_rotation_x;
    QLabel *label_50;
    QDial *dial3_all_primitives_rotation_z;
    QLabel *label_141;
    QLabel *label_142;
    MyLineEdit *vect3_all_primitives_position_x;
    MyLineEdit *vect3_all_primitives_position_y;
    QLabel *label_49;
    QLabel *label_144;
    QDial *dial3_all_primitives_rotation_y;
    QDial *dial3_all_primitives_rotation_x;
    MyDoubleSpinBox *spinboxd3_all_primitives_rotation_y;
    MyDoubleSpinBox *spinboxd3_all_primitives_rotation_z;
    QLabel *label_51;
    QLabel *label_143;
    QVBoxLayout *verticalLayout_primitives;
    QSpacerItem *verticalSpacer_9;
    QDockWidget *dockWidget_rendering_engine;
    QWidget *dockWidgetContents;
    QVBoxLayout *verticalLayout_42;
    QScrollArea *scrollArea_3;
    QWidget *scrollAreaWidgetContents_4;
    QVBoxLayout *verticalLayout_46;
    QGroupBox *groupBox_4;
    QVBoxLayout *verticalLayout_43;
    QGridLayout *gridLayout_19;
    QLabel *label_103;
    QSlider *sliderInt_N;
    MyLineEdit *logedit_view_distance_min;
    MyCheckBox *checkBox_iteration_threshold_mode;
    MyCheckBox *checkBox_interior_mode;
    MyLineEdit *logedit_DE_factor;
    QLabel *label_105;
    QLabel *label_104;
    QSlider *logslider_smoothness;
    QLabel *label_108;
    QLabel *label_107;
    QLabel *label_106;
    MyCheckBox *checkBox_slow_shading;
    MySpinBox *spinboxInt_N;
    MyLineEdit *logedit_smoothness;
    QSlider *logslider_view_distance_max;
    MyLineEdit *logedit_detail_level;
    MyLineEdit *logedit_view_distance_max;
    QSlider *logslider_view_distance_min;
    QSlider *logslider_DE_factor;
    QGroupBox *groupCheck_constant_DE_threshold;
    QVBoxLayout *verticalLayout_44;
    QGridLayout *gridLayout_20;
    QLabel *label_99;
    QSlider *logslider_DE_thresh;
    MyLineEdit *logedit_DE_thresh;
    QSlider *logslider_detail_level;
    MyGroupBox *groupCheck_limits_enabled;
    QVBoxLayout *verticalLayout_45;
    QGridLayout *gridLayout_21;
    QLabel *label_110;
    MyLineEdit *vect3_limit_max_x;
    MyLineEdit *vect3_limit_min_z;
    QLabel *label_109;
    MyLineEdit *vect3_limit_min_y;
    QLabel *label_111;
    QLabel *label_112;
    MyLineEdit *vect3_limit_min_x;
    MyLineEdit *vect3_limit_max_y;
    MyLineEdit *vect3_limit_max_z;
    QLabel *label_114;
    QLabel *label_117;
    QLabel *label_118;
    QLabel *label_119;
    QGroupBox *group_netrender;
    QVBoxLayout *verticalLayout_60;
    QGridLayout *gridLayout_29;
    QLabel *label_176;
    QComboBox *combo_netrender_mode;
    QGroupBox *groupBox_netrender_client_config;
    QVBoxLayout *verticalLayout_62;
    QGridLayout *gridLayout_31;
    MyLineEdit *text_netrender_client_remote_address;
    QLabel *label_178;
    QLabel *label_212;
    MySpinBox *spinboxInt_netrender_client_remote_port;
    QGridLayout *gridLayout_50;
    QPushButton *bu_netrender_connect;
    QPushButton *bu_netrender_disconnect;
    QGridLayout *gridLayout_501;
    QLabel *label_;
    QLabel *label_netrender_client_status;
    QGroupBox *groupBox_netrender_server_config;
    QVBoxLayout *verticalLayout_82;
    QGridLayout *gridLayout_502;
    MySpinBox *spinboxInt_netrender_server_local_port;
    QLabel *label_216;
    QGridLayout *gridLayout_503;
    QPushButton *bu_netrender_start_server;
    QPushButton *bu_netrender_stop_server;
    QGridLayout *gridLayout_504;
    QLabel *label_1;
    QLabel *label_netrender_server_status;
    QLabel *label_175;
    QTableWidget *tableWidget_netrender_connected_clients;
    QSpacerItem *verticalSpacer_8;
    QDockWidget *dockWidget_info;
    QWidget *dockWidgetContents_info;
    QHBoxLayout *horizontalLayout_13;
    MyLogWidget *log_text;
    QVBoxLayout *verticalLayout_histogram_de;
    QLabel *label_174;
    MyHistogramLabel *label_histogram_de;
    QVBoxLayout *verticalLayout_histogram_iter;
    QLabel *label_1741;
    MyHistogramLabel *label_histogram_iter;
    QDockWidget *dockWidget_animation;
    QWidget *dockWidgetContents_animation;
    QHBoxLayout *horizontalLayout_14;
    QVBoxLayout *verticalLayoutAnimation;
    QTabWidget *tabWidgetFlightKeyframe;
    QWidget *tab_flight_animation;
    QHBoxLayout *horizontalLayout_12;
    QVBoxLayout *verticalLayout_flight_animtion;
    QGridLayout *gridLayout_39;
    QPushButton *pushButton_render_flight;
    QPushButton *pushButton_record_flight;
    QPushButton *pushButton_delete_all_images;
    QPushButton *pushButton_show_animation;
    QPushButton *pushButton_continue_recording;
    QPushButton *pushButton_flight_refresh_table;
    QScrollArea *scrollArea_flyght_animation_parameters;
    QWidget *scrollAreaWidgetContents_flightAnimationParameters;
    QVBoxLayout *verticalLayout_79;
    QGridLayout *gridLayout_38;
    QLabel *label_150;
    QLabel *label_147;
    QLabel *label_146;
    QLabel *label_148;
    QComboBox *comboBox_flight_speed_control;
    MyLineEdit *text_anim_flight_dir;
    QPushButton *button_selectAnimFlightImageDir;
    MyLineEdit *logedit_flight_speed;
    QSlider *logslider_flight_speed;
    QSlider *slider_flight_inertia;
    MyDoubleSpinBox *spinbox_flight_inertia;
    QLabel *label_151;
    QSlider *slider_flight_sec_per_frame;
    MyDoubleSpinBox *spinbox_flight_sec_per_frame;
    QSlider *slider_flight_roll_speed;
    MyDoubleSpinBox *spinbox_flight_rotation_speed;
    QSlider *slider_flight_rotation_speed;
    QLabel *label_153;
    MyDoubleSpinBox *spinbox_flight_roll_speed;
    MyCheckBox *checkBox_flight_show_thumbnails;
    QLabel *label_152;
    MyCheckBox *checkBox_flight_add_speeds;
    QSpacerItem *verticalSpacer_11;
    QVBoxLayout *verticalLayout_table;
    MyTableWidgetAnim *tableWidget_flightAnimation;
    QWidget *tab_7;
    QLabel *label_149;
    QVBoxLayout *verticalLayout_75;

    void setupUi(QMainWindow *RenderWindow)
    {
        if (RenderWindow->objectName().isEmpty())
            RenderWindow->setObjectName(QStringLiteral("RenderWindow"));
        RenderWindow->resize(1700, 1238);
        QFont font;
        font.setPointSize(8);
        font.setStyleStrategy(QFont::PreferAntialias);
        RenderWindow->setFont(font);
        QIcon icon;
        icon.addFile(QStringLiteral(":/system/icons/mandelbulber.png"), QSize(), QIcon::Normal, QIcon::Off);
        RenderWindow->setWindowIcon(icon);
        RenderWindow->setDockOptions(QMainWindow::AllowNestedDocks|QMainWindow::AllowTabbedDocks|QMainWindow::AnimatedDocks);
        RenderWindow->setUnifiedTitleAndToolBarOnMac(true);
        actionSave_as_JPG = new QAction(RenderWindow);
        actionSave_as_JPG->setObjectName(QStringLiteral("actionSave_as_JPG"));
        QIcon icon1;
        QString iconThemeName = QStringLiteral("document-save-as");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon1 = QIcon::fromTheme(iconThemeName);
        } else {
            icon1.addFile(QStringLiteral(":/system/icons/document-save-as.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionSave_as_JPG->setIcon(icon1);
        actionSave_as_PNG = new QAction(RenderWindow);
        actionSave_as_PNG->setObjectName(QStringLiteral("actionSave_as_PNG"));
        actionSave_as_PNG->setIcon(icon1);
        actionSave_as_PNG_16_bit = new QAction(RenderWindow);
        actionSave_as_PNG_16_bit->setObjectName(QStringLiteral("actionSave_as_PNG_16_bit"));
        actionSave_as_PNG_16_bit->setIcon(icon1);
        actionSave_as_PNG_16_bit_with_alpha_channel = new QAction(RenderWindow);
        actionSave_as_PNG_16_bit_with_alpha_channel->setObjectName(QStringLiteral("actionSave_as_PNG_16_bit_with_alpha_channel"));
        actionSave_as_PNG_16_bit_with_alpha_channel->setIcon(icon1);
        actionLoad_settings = new QAction(RenderWindow);
        actionLoad_settings->setObjectName(QStringLiteral("actionLoad_settings"));
        QIcon icon2;
        iconThemeName = QStringLiteral("document-open");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon2 = QIcon::fromTheme(iconThemeName);
        } else {
            icon2.addFile(QStringLiteral(":/system/icons/document-open.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionLoad_settings->setIcon(icon2);
        actionSave_settings = new QAction(RenderWindow);
        actionSave_settings->setObjectName(QStringLiteral("actionSave_settings"));
        QIcon icon3;
        iconThemeName = QStringLiteral("document-save");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon3 = QIcon::fromTheme(iconThemeName);
        } else {
            icon3.addFile(QStringLiteral(":/system/icons/document-save.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionSave_settings->setIcon(icon3);
        actionSave_settings_as = new QAction(RenderWindow);
        actionSave_settings_as->setObjectName(QStringLiteral("actionSave_settings_as"));
        actionSave_settings_as->setIcon(icon3);
        actionProgramSettings = new QAction(RenderWindow);
        actionProgramSettings->setObjectName(QStringLiteral("actionProgramSettings"));
        QIcon icon4;
        iconThemeName = QStringLiteral("preferences-system");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon4 = QIcon::fromTheme(iconThemeName);
        } else {
            icon4.addFile(QStringLiteral(":/system/icons/preferences-system.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionProgramSettings->setIcon(icon4);
        actionQuit = new QAction(RenderWindow);
        actionQuit->setObjectName(QStringLiteral("actionQuit"));
        QIcon icon5;
        iconThemeName = QStringLiteral("application-exit");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon5 = QIcon::fromTheme(iconThemeName);
        } else {
            icon5.addFile(QStringLiteral(":/system/icons/system-shutdown.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionQuit->setIcon(icon5);
        actionSave_docks_positions = new QAction(RenderWindow);
        actionSave_docks_positions->setObjectName(QStringLiteral("actionSave_docks_positions"));
        actionDefault_docks_positions = new QAction(RenderWindow);
        actionDefault_docks_positions->setObjectName(QStringLiteral("actionDefault_docks_positions"));
        actionAbout_Qt = new QAction(RenderWindow);
        actionAbout_Qt->setObjectName(QStringLiteral("actionAbout_Qt"));
        actionAbout_Mandelbulber = new QAction(RenderWindow);
        actionAbout_Mandelbulber->setObjectName(QStringLiteral("actionAbout_Mandelbulber"));
        actionAbout_Mandelbulber->setIcon(icon);
        actionUndo = new QAction(RenderWindow);
        actionUndo->setObjectName(QStringLiteral("actionUndo"));
        QIcon icon6;
        iconThemeName = QStringLiteral("edit-undo");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon6 = QIcon::fromTheme(iconThemeName);
        } else {
            icon6.addFile(QStringLiteral(":/system/icons/edit-undo.png"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionUndo->setIcon(icon6);
        actionRedo = new QAction(RenderWindow);
        actionRedo->setObjectName(QStringLiteral("actionRedo"));
        QIcon icon7;
        iconThemeName = QStringLiteral("edit-redo");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon7 = QIcon::fromTheme(iconThemeName);
        } else {
            icon7.addFile(QStringLiteral(":/system/icons/edit-redo.png"), QSize(), QIcon::Normal, QIcon::Off);
        }
        actionRedo->setIcon(icon7);
        actionImport_settings_from_old_Mandelbulber = new QAction(RenderWindow);
        actionImport_settings_from_old_Mandelbulber->setObjectName(QStringLiteral("actionImport_settings_from_old_Mandelbulber"));
        actionImport_settings_from_old_Mandelbulber->setIcon(icon2);
        actionLoad_example = new QAction(RenderWindow);
        actionLoad_example->setObjectName(QStringLiteral("actionLoad_example"));
        actionLoad_example->setIcon(icon2);
        actionShow_animation_dock = new QAction(RenderWindow);
        actionShow_animation_dock->setObjectName(QStringLiteral("actionShow_animation_dock"));
        actionShow_animation_dock->setCheckable(true);
        actionShow_animation_dock->setVisible(true);
        actionShow_info_dock = new QAction(RenderWindow);
        actionShow_info_dock->setObjectName(QStringLiteral("actionShow_info_dock"));
        actionShow_info_dock->setCheckable(true);
        actionShow_info_dock->setVisible(true);
        actionShow_toolbar = new QAction(RenderWindow);
        actionShow_toolbar->setObjectName(QStringLiteral("actionShow_toolbar"));
        actionShow_toolbar->setCheckable(true);
        actionShow_toolbar->setVisible(true);
        actionStack_all_docks = new QAction(RenderWindow);
        actionStack_all_docks->setObjectName(QStringLiteral("actionStack_all_docks"));
        centralwidget = new QWidget(RenderWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        verticalLayout_78 = new QVBoxLayout(centralwidget);
        verticalLayout_78->setSpacing(2);
        verticalLayout_78->setContentsMargins(2, 2, 2, 2);
        verticalLayout_78->setObjectName(QStringLiteral("verticalLayout_78"));
        verticalLayout_78->setContentsMargins(2, 2, 2, 2);
        verticalLayout_center = new QVBoxLayout();
        verticalLayout_center->setSpacing(2);
        verticalLayout_center->setObjectName(QStringLiteral("verticalLayout_center"));
        scrollAreaForImage = new MyScrolledArea(centralwidget);
        scrollAreaForImage->setObjectName(QStringLiteral("scrollAreaForImage"));
        scrollAreaForImage->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        scrollAreaForImage->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
        scrollAreaForImage->setWidgetResizable(true);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QStringLiteral("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1121, 680));
        scrollAreaLayoutRenderedImage = new QVBoxLayout(scrollAreaWidgetContents);
        scrollAreaLayoutRenderedImage->setSpacing(0);
        scrollAreaLayoutRenderedImage->setContentsMargins(2, 2, 2, 2);
        scrollAreaLayoutRenderedImage->setObjectName(QStringLiteral("scrollAreaLayoutRenderedImage"));
        scrollAreaLayoutRenderedImage->setContentsMargins(0, 0, 0, 0);
        scrollAreaForImage->setWidget(scrollAreaWidgetContents);

        verticalLayout_center->addWidget(scrollAreaForImage);

        hl_zoom = new QHBoxLayout();
        hl_zoom->setSpacing(2);
        hl_zoom->setObjectName(QStringLiteral("hl_zoom"));
        label = new QLabel(centralwidget);
        label->setObjectName(QStringLiteral("label"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(0, 0));

        hl_zoom->addWidget(label);

        comboBox_image_preview_scale = new QComboBox(centralwidget);
        comboBox_image_preview_scale->setObjectName(QStringLiteral("comboBox_image_preview_scale"));
        comboBox_image_preview_scale->setEditable(true);

        hl_zoom->addWidget(comboBox_image_preview_scale);

        line = new QFrame(centralwidget);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::VLine);
        line->setFrameShadow(QFrame::Sunken);

        hl_zoom->addWidget(line);

        checkBox_show_cursor = new MyCheckBox(centralwidget);
        checkBox_show_cursor->setObjectName(QStringLiteral("checkBox_show_cursor"));

        hl_zoom->addWidget(checkBox_show_cursor);

        line_2 = new QFrame(centralwidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::VLine);
        line_2->setFrameShadow(QFrame::Sunken);

        hl_zoom->addWidget(line_2);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hl_zoom->addItem(horizontalSpacer);


        verticalLayout_center->addLayout(hl_zoom);


        verticalLayout_78->addLayout(verticalLayout_center);

        RenderWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(RenderWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1700, 17));
        menuImage = new QMenu(menubar);
        menuImage->setObjectName(QStringLiteral("menuImage"));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuView = new QMenu(menubar);
        menuView->setObjectName(QStringLiteral("menuView"));
        menuAbout = new QMenu(menubar);
        menuAbout->setObjectName(QStringLiteral("menuAbout"));
        menuEdit = new QMenu(menubar);
        menuEdit->setObjectName(QStringLiteral("menuEdit"));
        RenderWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(RenderWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        QFont font1;
        font1.setPointSize(12);
        statusbar->setFont(font1);
        statusbar->setLayoutDirection(Qt::LeftToRight);
        RenderWindow->setStatusBar(statusbar);
        dockWidget_image_adjustments = new QDockWidget(RenderWindow);
        dockWidget_image_adjustments->setObjectName(QStringLiteral("dockWidget_image_adjustments"));
        QFont font2;
        font2.setPointSize(8);
        dockWidget_image_adjustments->setFont(font2);
        dockWidget_image_adjustments->setFloating(false);
        dockWidget_image_adjustments->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        dockWidgetLeftContents = new QWidget();
        dockWidgetLeftContents->setObjectName(QStringLiteral("dockWidgetLeftContents"));
        verticalLayout_23 = new QVBoxLayout(dockWidgetLeftContents);
        verticalLayout_23->setSpacing(2);
        verticalLayout_23->setContentsMargins(2, 2, 2, 2);
        verticalLayout_23->setObjectName(QStringLiteral("verticalLayout_23"));
        verticalLayout_23->setContentsMargins(2, 2, 2, 2);
        scrollArea = new QScrollArea(dockWidgetLeftContents);
        scrollArea->setObjectName(QStringLiteral("scrollArea"));
        scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_2 = new QWidget();
        scrollAreaWidgetContents_2->setObjectName(QStringLiteral("scrollAreaWidgetContents_2"));
        scrollAreaWidgetContents_2->setGeometry(QRect(0, 0, 339, 454));
        verticalLayout_19 = new QVBoxLayout(scrollAreaWidgetContents_2);
        verticalLayout_19->setSpacing(2);
        verticalLayout_19->setContentsMargins(2, 2, 2, 2);
        verticalLayout_19->setObjectName(QStringLiteral("verticalLayout_19"));
        verticalLayout_19->setContentsMargins(2, 2, 2, 2);
        groupBox_3 = new QGroupBox(scrollAreaWidgetContents_2);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        verticalLayout_40 = new QVBoxLayout(groupBox_3);
        verticalLayout_40->setSpacing(2);
        verticalLayout_40->setContentsMargins(2, 2, 2, 2);
        verticalLayout_40->setObjectName(QStringLiteral("verticalLayout_40"));
        verticalLayout_40->setContentsMargins(2, 2, 2, 2);
        gridLayout_18 = new QGridLayout();
        gridLayout_18->setSpacing(2);
        gridLayout_18->setObjectName(QStringLiteral("gridLayout_18"));
        spinboxInt_image_height = new MySpinBox(groupBox_3);
        spinboxInt_image_height->setObjectName(QStringLiteral("spinboxInt_image_height"));
        spinboxInt_image_height->setMinimum(32);
        spinboxInt_image_height->setMaximum(65536);
        spinboxInt_image_height->setSingleStep(8);

        gridLayout_18->addWidget(spinboxInt_image_height, 1, 2, 1, 1);

        sliderInt_image_height = new QSlider(groupBox_3);
        sliderInt_image_height->setObjectName(QStringLiteral("sliderInt_image_height"));
        sliderInt_image_height->setMinimum(32);
        sliderInt_image_height->setMaximum(16000);
        sliderInt_image_height->setSingleStep(8);
        sliderInt_image_height->setPageStep(64);
        sliderInt_image_height->setOrientation(Qt::Horizontal);

        gridLayout_18->addWidget(sliderInt_image_height, 1, 1, 1, 1);

        label_100 = new QLabel(groupBox_3);
        label_100->setObjectName(QStringLiteral("label_100"));

        gridLayout_18->addWidget(label_100, 0, 0, 1, 1);

        label_101 = new QLabel(groupBox_3);
        label_101->setObjectName(QStringLiteral("label_101"));

        gridLayout_18->addWidget(label_101, 1, 0, 1, 1);

        sliderInt_image_width = new QSlider(groupBox_3);
        sliderInt_image_width->setObjectName(QStringLiteral("sliderInt_image_width"));
        sliderInt_image_width->setMinimum(32);
        sliderInt_image_width->setMaximum(16000);
        sliderInt_image_width->setSingleStep(8);
        sliderInt_image_width->setPageStep(64);
        sliderInt_image_width->setOrientation(Qt::Horizontal);

        gridLayout_18->addWidget(sliderInt_image_width, 0, 1, 1, 1);

        spinboxInt_image_width = new MySpinBox(groupBox_3);
        spinboxInt_image_width->setObjectName(QStringLiteral("spinboxInt_image_width"));
        spinboxInt_image_width->setMinimum(32);
        spinboxInt_image_width->setMaximum(65536);
        spinboxInt_image_width->setSingleStep(8);

        gridLayout_18->addWidget(spinboxInt_image_width, 0, 2, 1, 1);

        label_102 = new QLabel(groupBox_3);
        label_102->setObjectName(QStringLiteral("label_102"));

        gridLayout_18->addWidget(label_102, 2, 0, 1, 1);

        comboBox_image_proportion = new QComboBox(groupBox_3);
        comboBox_image_proportion->setObjectName(QStringLiteral("comboBox_image_proportion"));

        gridLayout_18->addWidget(comboBox_image_proportion, 2, 1, 1, 1);


        verticalLayout_40->addLayout(gridLayout_18);

        groupBox_6 = new QGroupBox(groupBox_3);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        verticalLayout_71 = new QVBoxLayout(groupBox_6);
        verticalLayout_71->setSpacing(2);
        verticalLayout_71->setContentsMargins(2, 2, 2, 2);
        verticalLayout_71->setObjectName(QStringLiteral("verticalLayout_71"));
        verticalLayout_71->setContentsMargins(2, 2, 2, 2);
        gridLayout_32 = new QGridLayout();
        gridLayout_32->setSpacing(2);
        gridLayout_32->setObjectName(QStringLiteral("gridLayout_32"));
        gridLayout_32->setContentsMargins(-1, 0, -1, -1);
        pushButton_resolution_preset_2160 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_2160->setObjectName(QStringLiteral("pushButton_resolution_preset_2160"));

        gridLayout_32->addWidget(pushButton_resolution_preset_2160, 1, 1, 1, 1);

        pushButton_resolution_preset_720 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_720->setObjectName(QStringLiteral("pushButton_resolution_preset_720"));

        gridLayout_32->addWidget(pushButton_resolution_preset_720, 0, 1, 1, 1);

        pushButton_resolution_preset_1080 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_1080->setObjectName(QStringLiteral("pushButton_resolution_preset_1080"));

        gridLayout_32->addWidget(pushButton_resolution_preset_1080, 0, 2, 1, 1);

        pushButton_resolution_preset_4320 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_4320->setObjectName(QStringLiteral("pushButton_resolution_preset_4320"));

        gridLayout_32->addWidget(pushButton_resolution_preset_4320, 1, 2, 1, 1);

        pushButton_resolution_preset_480 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_480->setObjectName(QStringLiteral("pushButton_resolution_preset_480"));

        gridLayout_32->addWidget(pushButton_resolution_preset_480, 0, 0, 1, 1);

        pushButton_resolution_preset_1440 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_1440->setObjectName(QStringLiteral("pushButton_resolution_preset_1440"));

        gridLayout_32->addWidget(pushButton_resolution_preset_1440, 1, 0, 1, 1);

        pushButton_resolution_preset_240 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_240->setObjectName(QStringLiteral("pushButton_resolution_preset_240"));

        gridLayout_32->addWidget(pushButton_resolution_preset_240, 2, 0, 1, 1);

        pushButton_resolution_preset_600 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_600->setObjectName(QStringLiteral("pushButton_resolution_preset_600"));

        gridLayout_32->addWidget(pushButton_resolution_preset_600, 2, 1, 1, 1);

        pushButton_resolution_preset_1200 = new QPushButton(groupBox_6);
        pushButton_resolution_preset_1200->setObjectName(QStringLiteral("pushButton_resolution_preset_1200"));

        gridLayout_32->addWidget(pushButton_resolution_preset_1200, 2, 2, 1, 1);


        verticalLayout_71->addLayout(gridLayout_32);


        verticalLayout_40->addWidget(groupBox_6);


        verticalLayout_19->addWidget(groupBox_3);

        groupBox_ImageAdjustments = new QGroupBox(scrollAreaWidgetContents_2);
        groupBox_ImageAdjustments->setObjectName(QStringLiteral("groupBox_ImageAdjustments"));
        verticalLayout_20 = new QVBoxLayout(groupBox_ImageAdjustments);
        verticalLayout_20->setSpacing(2);
        verticalLayout_20->setContentsMargins(2, 2, 2, 2);
        verticalLayout_20->setObjectName(QStringLiteral("verticalLayout_20"));
        verticalLayout_20->setContentsMargins(2, 2, 2, 2);
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(2);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        spinbox_contrast = new MyDoubleSpinBox(groupBox_ImageAdjustments);
        spinbox_contrast->setObjectName(QStringLiteral("spinbox_contrast"));
        spinbox_contrast->setDecimals(2);
        spinbox_contrast->setMaximum(1000);
        spinbox_contrast->setSingleStep(0.1);

        gridLayout->addWidget(spinbox_contrast, 1, 2, 1, 1);

        spinbox_gamma = new MyDoubleSpinBox(groupBox_ImageAdjustments);
        spinbox_gamma->setObjectName(QStringLiteral("spinbox_gamma"));
        spinbox_gamma->setDecimals(2);
        spinbox_gamma->setMaximum(1000);
        spinbox_gamma->setSingleStep(0.1);

        gridLayout->addWidget(spinbox_gamma, 2, 2, 1, 1);

        label_4 = new QLabel(groupBox_ImageAdjustments);
        label_4->setObjectName(QStringLiteral("label_4"));

        gridLayout->addWidget(label_4, 2, 0, 1, 1);

        spinbox_brightness = new MyDoubleSpinBox(groupBox_ImageAdjustments);
        spinbox_brightness->setObjectName(QStringLiteral("spinbox_brightness"));
        spinbox_brightness->setDecimals(2);
        spinbox_brightness->setMaximum(1000);
        spinbox_brightness->setSingleStep(0.1);

        gridLayout->addWidget(spinbox_brightness, 0, 2, 1, 1);

        label_3 = new QLabel(groupBox_ImageAdjustments);
        label_3->setObjectName(QStringLiteral("label_3"));

        gridLayout->addWidget(label_3, 0, 0, 1, 1);

        slider_contrast = new QSlider(groupBox_ImageAdjustments);
        slider_contrast->setObjectName(QStringLiteral("slider_contrast"));
        slider_contrast->setMaximum(200);
        slider_contrast->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(slider_contrast, 1, 1, 1, 1);

        slider_brightness = new QSlider(groupBox_ImageAdjustments);
        slider_brightness->setObjectName(QStringLiteral("slider_brightness"));
        slider_brightness->setMaximum(200);
        slider_brightness->setSingleStep(1);
        slider_brightness->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(slider_brightness, 0, 1, 1, 1);

        label_45 = new QLabel(groupBox_ImageAdjustments);
        label_45->setObjectName(QStringLiteral("label_45"));

        gridLayout->addWidget(label_45, 1, 0, 1, 1);

        slider_gamma = new QSlider(groupBox_ImageAdjustments);
        slider_gamma->setObjectName(QStringLiteral("slider_gamma"));
        slider_gamma->setMaximum(200);
        slider_gamma->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(slider_gamma, 2, 1, 1, 1);


        verticalLayout_20->addLayout(gridLayout);

        checkBox_hdr = new MyCheckBox(groupBox_ImageAdjustments);
        checkBox_hdr->setObjectName(QStringLiteral("checkBox_hdr"));

        verticalLayout_20->addWidget(checkBox_hdr);

        pushButton_apply_image_changes = new QPushButton(groupBox_ImageAdjustments);
        pushButton_apply_image_changes->setObjectName(QStringLiteral("pushButton_apply_image_changes"));
        QIcon icon8;
        iconThemeName = QStringLiteral("dialog-ok-apply");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon8 = QIcon::fromTheme(iconThemeName);
        } else {
            icon8.addFile(QStringLiteral("../../../.designer/backup"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_apply_image_changes->setIcon(icon8);

        verticalLayout_20->addWidget(pushButton_apply_image_changes);


        verticalLayout_19->addWidget(groupBox_ImageAdjustments);

        groupBox_5 = new QGroupBox(scrollAreaWidgetContents_2);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        verticalLayout_58 = new QVBoxLayout(groupBox_5);
        verticalLayout_58->setSpacing(2);
        verticalLayout_58->setContentsMargins(2, 2, 2, 2);
        verticalLayout_58->setObjectName(QStringLiteral("verticalLayout_58"));
        verticalLayout_58->setContentsMargins(2, 2, 2, 2);
        gridLayout_25 = new QGridLayout();
        gridLayout_25->setSpacing(2);
        gridLayout_25->setObjectName(QStringLiteral("gridLayout_25"));
        label_54 = new QLabel(groupBox_5);
        label_54->setObjectName(QStringLiteral("label_54"));

        gridLayout_25->addWidget(label_54, 0, 0, 1, 1);

        spinbox_fov = new MyDoubleSpinBox(groupBox_5);
        spinbox_fov->setObjectName(QStringLiteral("spinbox_fov"));
        spinbox_fov->setDecimals(2);
        spinbox_fov->setMinimum(0.01);
        spinbox_fov->setMaximum(5);
        spinbox_fov->setSingleStep(0.1);
        spinbox_fov->setValue(0.01);

        gridLayout_25->addWidget(spinbox_fov, 0, 2, 1, 1);

        slider_fov = new QSlider(groupBox_5);
        slider_fov->setObjectName(QStringLiteral("slider_fov"));
        slider_fov->setMinimum(10);
        slider_fov->setMaximum(200);
        slider_fov->setSingleStep(1);
        slider_fov->setOrientation(Qt::Horizontal);

        gridLayout_25->addWidget(slider_fov, 0, 1, 1, 1);

        comboBox_perspective_type = new QComboBox(groupBox_5);
        comboBox_perspective_type->setObjectName(QStringLiteral("comboBox_perspective_type"));

        gridLayout_25->addWidget(comboBox_perspective_type, 1, 1, 1, 2);

        label_126 = new QLabel(groupBox_5);
        label_126->setObjectName(QStringLiteral("label_126"));

        gridLayout_25->addWidget(label_126, 1, 0, 1, 1);


        verticalLayout_58->addLayout(gridLayout_25);

        checkBox_legacy_coordinate_system = new MyCheckBox(groupBox_5);
        checkBox_legacy_coordinate_system->setObjectName(QStringLiteral("checkBox_legacy_coordinate_system"));

        verticalLayout_58->addWidget(checkBox_legacy_coordinate_system);


        verticalLayout_19->addWidget(groupBox_5);

        verticalSpacer_3 = new QSpacerItem(8, 8, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_19->addItem(verticalSpacer_3);

        scrollArea->setWidget(scrollAreaWidgetContents_2);

        verticalLayout_23->addWidget(scrollArea);

        dockWidget_image_adjustments->setWidget(dockWidgetLeftContents);
        RenderWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidget_image_adjustments);
        dockWidget_navigation = new QDockWidget(RenderWindow);
        dockWidget_navigation->setObjectName(QStringLiteral("dockWidget_navigation"));
        dockWidget_navigation->setFont(font2);
        dockWidget_navigation->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        dockWidgetRightContents = new QWidget();
        dockWidgetRightContents->setObjectName(QStringLiteral("dockWidgetRightContents"));
        verticalLayout_24 = new QVBoxLayout(dockWidgetRightContents);
        verticalLayout_24->setSpacing(2);
        verticalLayout_24->setContentsMargins(2, 2, 2, 2);
        verticalLayout_24->setObjectName(QStringLiteral("verticalLayout_24"));
        verticalLayout_24->setContentsMargins(2, 2, 2, 2);
        gridLayout_26 = new QGridLayout();
        gridLayout_26->setSpacing(2);
        gridLayout_26->setObjectName(QStringLiteral("gridLayout_26"));
        gridLayout_26->setHorizontalSpacing(2);
        gridLayout_26->setContentsMargins(-1, 0, -1, -1);
        pushButton_render = new QPushButton(dockWidgetRightContents);
        pushButton_render->setObjectName(QStringLiteral("pushButton_render"));
        QIcon icon9;
        iconThemeName = QStringLiteral("applications-graphics");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon9 = QIcon::fromTheme(iconThemeName);
        } else {
            icon9.addFile(QStringLiteral(":/system/icons/applications-graphics.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_render->setIcon(icon9);

        gridLayout_26->addWidget(pushButton_render, 0, 0, 1, 1);

        pushButton_stop = new QPushButton(dockWidgetRightContents);
        pushButton_stop->setObjectName(QStringLiteral("pushButton_stop"));
        QIcon icon10;
        iconThemeName = QStringLiteral("process-stop");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon10 = QIcon::fromTheme(iconThemeName);
        } else {
            icon10.addFile(QStringLiteral(":/system/icons/process-stop.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_stop->setIcon(icon10);

        gridLayout_26->addWidget(pushButton_stop, 0, 1, 1, 1);


        verticalLayout_24->addLayout(gridLayout_26);

        scrollArea_4 = new QScrollArea(dockWidgetRightContents);
        scrollArea_4->setObjectName(QStringLiteral("scrollArea_4"));
        scrollArea_4->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        scrollArea_4->setWidgetResizable(true);
        scrollAreaWidgetContents_5 = new QWidget();
        scrollAreaWidgetContents_5->setObjectName(QStringLiteral("scrollAreaWidgetContents_5"));
        scrollAreaWidgetContents_5->setGeometry(QRect(0, 0, 177, 779));
        verticalLayout = new QVBoxLayout(scrollAreaWidgetContents_5);
        verticalLayout->setSpacing(2);
        verticalLayout->setContentsMargins(2, 2, 2, 2);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 2);
        vl_side_functions = new QVBoxLayout();
        vl_side_functions->setSpacing(1);
        vl_side_functions->setObjectName(QStringLiteral("vl_side_functions"));
        groupBox_coordinates = new QGroupBox(scrollAreaWidgetContents_5);
        groupBox_coordinates->setObjectName(QStringLiteral("groupBox_coordinates"));
        verticalLayout_2 = new QVBoxLayout(groupBox_coordinates);
        verticalLayout_2->setSpacing(1);
        verticalLayout_2->setContentsMargins(2, 2, 2, 2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(2, 2, 2, 2);
        groupBox_cameraPosition = new QGroupBox(groupBox_coordinates);
        groupBox_cameraPosition->setObjectName(QStringLiteral("groupBox_cameraPosition"));
        verticalLayout_5 = new QVBoxLayout(groupBox_cameraPosition);
        verticalLayout_5->setSpacing(2);
        verticalLayout_5->setContentsMargins(2, 2, 2, 2);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(2, 2, 2, 2);
        vect3_camera = new QFrame(groupBox_cameraPosition);
        vect3_camera->setObjectName(QStringLiteral("vect3_camera"));
        vect3_camera->setFrameShape(QFrame::StyledPanel);
        vect3_camera->setFrameShadow(QFrame::Raised);
        verticalLayout_14 = new QVBoxLayout(vect3_camera);
        verticalLayout_14->setSpacing(2);
        verticalLayout_14->setContentsMargins(2, 2, 2, 2);
        verticalLayout_14->setObjectName(QStringLiteral("verticalLayout_14"));
        verticalLayout_14->setContentsMargins(2, 2, 2, 2);
        formLayout_coordinates_4 = new QFormLayout();
        formLayout_coordinates_4->setSpacing(2);
        formLayout_coordinates_4->setObjectName(QStringLiteral("formLayout_coordinates_4"));
        formLayout_coordinates_4->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_coordinates_4->setHorizontalSpacing(2);
        formLayout_coordinates_4->setVerticalSpacing(1);
        label_18 = new QLabel(vect3_camera);
        label_18->setObjectName(QStringLiteral("label_18"));

        formLayout_coordinates_4->setWidget(0, QFormLayout::LabelRole, label_18);

        vect3_camera_x = new MyLineEdit(vect3_camera);
        vect3_camera_x->setObjectName(QStringLiteral("vect3_camera_x"));

        formLayout_coordinates_4->setWidget(0, QFormLayout::FieldRole, vect3_camera_x);

        label_19 = new QLabel(vect3_camera);
        label_19->setObjectName(QStringLiteral("label_19"));

        formLayout_coordinates_4->setWidget(1, QFormLayout::LabelRole, label_19);

        vect3_camera_y = new MyLineEdit(vect3_camera);
        vect3_camera_y->setObjectName(QStringLiteral("vect3_camera_y"));

        formLayout_coordinates_4->setWidget(1, QFormLayout::FieldRole, vect3_camera_y);

        label_20 = new QLabel(vect3_camera);
        label_20->setObjectName(QStringLiteral("label_20"));

        formLayout_coordinates_4->setWidget(2, QFormLayout::LabelRole, label_20);

        vect3_camera_z = new MyLineEdit(vect3_camera);
        vect3_camera_z->setObjectName(QStringLiteral("vect3_camera_z"));

        formLayout_coordinates_4->setWidget(2, QFormLayout::FieldRole, vect3_camera_z);


        verticalLayout_14->addLayout(formLayout_coordinates_4);


        verticalLayout_5->addWidget(vect3_camera);


        verticalLayout_2->addWidget(groupBox_cameraPosition);

        groupBox_targetPosition = new QGroupBox(groupBox_coordinates);
        groupBox_targetPosition->setObjectName(QStringLiteral("groupBox_targetPosition"));
        verticalLayout_54 = new QVBoxLayout(groupBox_targetPosition);
        verticalLayout_54->setSpacing(2);
        verticalLayout_54->setContentsMargins(2, 2, 2, 2);
        verticalLayout_54->setObjectName(QStringLiteral("verticalLayout_54"));
        verticalLayout_54->setContentsMargins(2, 2, 2, 2);
        vect3_target = new QFrame(groupBox_targetPosition);
        vect3_target->setObjectName(QStringLiteral("vect3_target"));
        vect3_target->setFrameShape(QFrame::StyledPanel);
        vect3_target->setFrameShadow(QFrame::Raised);
        verticalLayout_55 = new QVBoxLayout(vect3_target);
        verticalLayout_55->setSpacing(2);
        verticalLayout_55->setContentsMargins(2, 2, 2, 2);
        verticalLayout_55->setObjectName(QStringLiteral("verticalLayout_55"));
        verticalLayout_55->setContentsMargins(2, 2, 2, 2);
        formLayout_coordinates_9 = new QFormLayout();
        formLayout_coordinates_9->setSpacing(2);
        formLayout_coordinates_9->setObjectName(QStringLiteral("formLayout_coordinates_9"));
        formLayout_coordinates_9->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_coordinates_9->setHorizontalSpacing(2);
        formLayout_coordinates_9->setVerticalSpacing(1);
        label_121 = new QLabel(vect3_target);
        label_121->setObjectName(QStringLiteral("label_121"));

        formLayout_coordinates_9->setWidget(0, QFormLayout::LabelRole, label_121);

        vect3_target_x = new MyLineEdit(vect3_target);
        vect3_target_x->setObjectName(QStringLiteral("vect3_target_x"));

        formLayout_coordinates_9->setWidget(0, QFormLayout::FieldRole, vect3_target_x);

        label_122 = new QLabel(vect3_target);
        label_122->setObjectName(QStringLiteral("label_122"));

        formLayout_coordinates_9->setWidget(1, QFormLayout::LabelRole, label_122);

        vect3_target_y = new MyLineEdit(vect3_target);
        vect3_target_y->setObjectName(QStringLiteral("vect3_target_y"));

        formLayout_coordinates_9->setWidget(1, QFormLayout::FieldRole, vect3_target_y);

        label_123 = new QLabel(vect3_target);
        label_123->setObjectName(QStringLiteral("label_123"));

        formLayout_coordinates_9->setWidget(2, QFormLayout::LabelRole, label_123);

        vect3_target_z = new MyLineEdit(vect3_target);
        vect3_target_z->setObjectName(QStringLiteral("vect3_target_z"));

        formLayout_coordinates_9->setWidget(2, QFormLayout::FieldRole, vect3_target_z);


        verticalLayout_55->addLayout(formLayout_coordinates_9);


        verticalLayout_54->addWidget(vect3_target);


        verticalLayout_2->addWidget(groupBox_targetPosition);

        pushButton_reset_view = new QPushButton(groupBox_coordinates);
        pushButton_reset_view->setObjectName(QStringLiteral("pushButton_reset_view"));

        verticalLayout_2->addWidget(pushButton_reset_view);

        comboBox_camera_movement_mode = new QComboBox(groupBox_coordinates);
        comboBox_camera_movement_mode->setObjectName(QStringLiteral("comboBox_camera_movement_mode"));

        verticalLayout_2->addWidget(comboBox_camera_movement_mode);

        gridLayout_24 = new QGridLayout();
        gridLayout_24->setSpacing(2);
        gridLayout_24->setObjectName(QStringLiteral("gridLayout_24"));
        gridLayout_24->setContentsMargins(0, 0, -1, -1);
        label_124 = new QLabel(groupBox_coordinates);
        label_124->setObjectName(QStringLiteral("label_124"));

        gridLayout_24->addWidget(label_124, 0, 0, 1, 1);

        logedit_camera_distance_to_target = new MyLineEdit(groupBox_coordinates);
        logedit_camera_distance_to_target->setObjectName(QStringLiteral("logedit_camera_distance_to_target"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(logedit_camera_distance_to_target->sizePolicy().hasHeightForWidth());
        logedit_camera_distance_to_target->setSizePolicy(sizePolicy1);
        logedit_camera_distance_to_target->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_24->addWidget(logedit_camera_distance_to_target, 0, 1, 1, 1);

        logslider_camera_distance_to_target = new QSlider(groupBox_coordinates);
        logslider_camera_distance_to_target->setObjectName(QStringLiteral("logslider_camera_distance_to_target"));
        sizePolicy1.setHeightForWidth(logslider_camera_distance_to_target->sizePolicy().hasHeightForWidth());
        logslider_camera_distance_to_target->setSizePolicy(sizePolicy1);
        logslider_camera_distance_to_target->setSizeIncrement(QSize(0, 0));
        logslider_camera_distance_to_target->setMinimum(-1500);
        logslider_camera_distance_to_target->setMaximum(300);
        logslider_camera_distance_to_target->setOrientation(Qt::Horizontal);

        gridLayout_24->addWidget(logslider_camera_distance_to_target, 1, 0, 1, 2);


        verticalLayout_2->addLayout(gridLayout_24);

        gridLayout_arrows = new QGridLayout();
        gridLayout_arrows->setSpacing(1);
        gridLayout_arrows->setObjectName(QStringLiteral("gridLayout_arrows"));
        bu_move_right = new QPushButton(groupBox_coordinates);
        bu_move_right->setObjectName(QStringLiteral("bu_move_right"));
        bu_move_right->setMinimumSize(QSize(0, 0));
        bu_move_right->setMaximumSize(QSize(40, 40));
        QIcon icon11;
        icon11.addFile(QStringLiteral(":/navigation/icons/go-next.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_move_right->setIcon(icon11);
        bu_move_right->setIconSize(QSize(32, 32));

        gridLayout_arrows->addWidget(bu_move_right, 2, 3, 1, 1);

        bu_move_left = new QPushButton(groupBox_coordinates);
        bu_move_left->setObjectName(QStringLiteral("bu_move_left"));
        bu_move_left->setMinimumSize(QSize(0, 0));
        bu_move_left->setMaximumSize(QSize(40, 40));
        QIcon icon12;
        icon12.addFile(QStringLiteral(":/navigation/icons/go-previous.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_move_left->setIcon(icon12);
        bu_move_left->setIconSize(QSize(32, 32));

        gridLayout_arrows->addWidget(bu_move_left, 2, 1, 1, 1);

        bu_move_up = new QPushButton(groupBox_coordinates);
        bu_move_up->setObjectName(QStringLiteral("bu_move_up"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(bu_move_up->sizePolicy().hasHeightForWidth());
        bu_move_up->setSizePolicy(sizePolicy2);
        bu_move_up->setMinimumSize(QSize(0, 0));
        bu_move_up->setMaximumSize(QSize(40, 40));
        QIcon icon13;
        icon13.addFile(QStringLiteral(":/navigation/icons/go-up.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_move_up->setIcon(icon13);
        bu_move_up->setIconSize(QSize(32, 32));

        gridLayout_arrows->addWidget(bu_move_up, 1, 2, 1, 1);

        bu_move_forward = new QPushButton(groupBox_coordinates);
        bu_move_forward->setObjectName(QStringLiteral("bu_move_forward"));
        sizePolicy2.setHeightForWidth(bu_move_forward->sizePolicy().hasHeightForWidth());
        bu_move_forward->setSizePolicy(sizePolicy2);
        bu_move_forward->setMinimumSize(QSize(0, 0));
        bu_move_forward->setMaximumSize(QSize(40, 40));
        bu_move_forward->setBaseSize(QSize(32, 32));
        QIcon icon14;
        icon14.addFile(QStringLiteral(":/navigation/icons/arrow-up-double.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_move_forward->setIcon(icon14);
        bu_move_forward->setIconSize(QSize(32, 32));

        gridLayout_arrows->addWidget(bu_move_forward, 1, 0, 1, 1);

        bu_move_backward = new QPushButton(groupBox_coordinates);
        bu_move_backward->setObjectName(QStringLiteral("bu_move_backward"));
        bu_move_backward->setMaximumSize(QSize(40, 40));
        bu_move_backward->setBaseSize(QSize(32, 32));
        QIcon icon15;
        icon15.addFile(QStringLiteral(":/navigation/icons/arrow-down-double.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_move_backward->setIcon(icon15);
        bu_move_backward->setIconSize(QSize(32, 32));

        gridLayout_arrows->addWidget(bu_move_backward, 2, 0, 1, 1);

        bu_move_down = new QPushButton(groupBox_coordinates);
        bu_move_down->setObjectName(QStringLiteral("bu_move_down"));
        bu_move_down->setMinimumSize(QSize(0, 0));
        bu_move_down->setMaximumSize(QSize(40, 40));
        QIcon icon16;
        icon16.addFile(QStringLiteral(":/navigation/icons/go-down.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_move_down->setIcon(icon16);
        bu_move_down->setIconSize(QSize(32, 32));

        gridLayout_arrows->addWidget(bu_move_down, 2, 2, 1, 1);


        verticalLayout_2->addLayout(gridLayout_arrows);

        single_camera_movenent_step_de = new QFrame(groupBox_coordinates);
        single_camera_movenent_step_de->setObjectName(QStringLiteral("single_camera_movenent_step_de"));
        single_camera_movenent_step_de->setFrameShape(QFrame::StyledPanel);
        single_camera_movenent_step_de->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(single_camera_movenent_step_de);
        verticalLayout_4->setSpacing(2);
        verticalLayout_4->setContentsMargins(2, 2, 2, 2);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(2, 2, 2, 2);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(2);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        label_9 = new QLabel(single_camera_movenent_step_de);
        label_9->setObjectName(QStringLiteral("label_9"));

        horizontalLayout->addWidget(label_9);

        logedit_camera_movement_step = new MyLineEdit(single_camera_movenent_step_de);
        logedit_camera_movement_step->setObjectName(QStringLiteral("logedit_camera_movement_step"));

        horizontalLayout->addWidget(logedit_camera_movement_step);


        verticalLayout_4->addLayout(horizontalLayout);

        logslider_camera_movement_step = new QSlider(single_camera_movenent_step_de);
        logslider_camera_movement_step->setObjectName(QStringLiteral("logslider_camera_movement_step"));
        sizePolicy1.setHeightForWidth(logslider_camera_movement_step->sizePolicy().hasHeightForWidth());
        logslider_camera_movement_step->setSizePolicy(sizePolicy1);
        logslider_camera_movement_step->setSizeIncrement(QSize(0, 0));
        logslider_camera_movement_step->setMinimum(-200);
        logslider_camera_movement_step->setMaximum(100);
        logslider_camera_movement_step->setOrientation(Qt::Horizontal);

        verticalLayout_4->addWidget(logslider_camera_movement_step);


        verticalLayout_2->addWidget(single_camera_movenent_step_de);

        comboBox_camera_absolute_distance_mode = new QComboBox(groupBox_coordinates);
        comboBox_camera_absolute_distance_mode->setObjectName(QStringLiteral("comboBox_camera_absolute_distance_mode"));

        verticalLayout_2->addWidget(comboBox_camera_absolute_distance_mode);


        vl_side_functions->addWidget(groupBox_coordinates);

        groupBox_rotation = new QGroupBox(scrollAreaWidgetContents_5);
        groupBox_rotation->setObjectName(QStringLiteral("groupBox_rotation"));
        verticalLayout_3 = new QVBoxLayout(groupBox_rotation);
        verticalLayout_3->setSpacing(2);
        verticalLayout_3->setContentsMargins(2, 2, 2, 2);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(2, 2, 2, 2);
        gridLayout_2 = new QGridLayout();
        gridLayout_2->setSpacing(1);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        bu_rotate_left = new QPushButton(groupBox_rotation);
        bu_rotate_left->setObjectName(QStringLiteral("bu_rotate_left"));
        bu_rotate_left->setMinimumSize(QSize(0, 0));
        bu_rotate_left->setMaximumSize(QSize(40, 40));
        bu_rotate_left->setIcon(icon12);
        bu_rotate_left->setIconSize(QSize(32, 32));

        gridLayout_2->addWidget(bu_rotate_left, 3, 1, 1, 1);

        bu_rotate_up = new QPushButton(groupBox_rotation);
        bu_rotate_up->setObjectName(QStringLiteral("bu_rotate_up"));
        sizePolicy2.setHeightForWidth(bu_rotate_up->sizePolicy().hasHeightForWidth());
        bu_rotate_up->setSizePolicy(sizePolicy2);
        bu_rotate_up->setMinimumSize(QSize(0, 0));
        bu_rotate_up->setMaximumSize(QSize(40, 40));
        bu_rotate_up->setIcon(icon13);
        bu_rotate_up->setIconSize(QSize(32, 32));

        gridLayout_2->addWidget(bu_rotate_up, 2, 2, 1, 1);

        bu_rotate_right = new QPushButton(groupBox_rotation);
        bu_rotate_right->setObjectName(QStringLiteral("bu_rotate_right"));
        bu_rotate_right->setMinimumSize(QSize(0, 0));
        bu_rotate_right->setMaximumSize(QSize(40, 40));
        bu_rotate_right->setIcon(icon11);
        bu_rotate_right->setIconSize(QSize(32, 32));

        gridLayout_2->addWidget(bu_rotate_right, 3, 3, 1, 1);

        bu_rotate_roll_right = new QPushButton(groupBox_rotation);
        bu_rotate_roll_right->setObjectName(QStringLiteral("bu_rotate_roll_right"));
        bu_rotate_roll_right->setMinimumSize(QSize(0, 0));
        bu_rotate_roll_right->setMaximumSize(QSize(40, 40));
        QIcon icon17;
        icon17.addFile(QStringLiteral(":/navigation/icons/object-rotate-right.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_rotate_roll_right->setIcon(icon17);
        bu_rotate_roll_right->setIconSize(QSize(32, 32));

        gridLayout_2->addWidget(bu_rotate_roll_right, 2, 3, 1, 1);

        bu_rotate_roll_left = new QPushButton(groupBox_rotation);
        bu_rotate_roll_left->setObjectName(QStringLiteral("bu_rotate_roll_left"));
        bu_rotate_roll_left->setMinimumSize(QSize(0, 0));
        bu_rotate_roll_left->setMaximumSize(QSize(40, 40));
        QIcon icon18;
        icon18.addFile(QStringLiteral(":/navigation/icons/object-rotate-left.png"), QSize(), QIcon::Normal, QIcon::Off);
        bu_rotate_roll_left->setIcon(icon18);
        bu_rotate_roll_left->setIconSize(QSize(32, 32));

        gridLayout_2->addWidget(bu_rotate_roll_left, 2, 1, 1, 1);

        bu_rotate_down = new QPushButton(groupBox_rotation);
        bu_rotate_down->setObjectName(QStringLiteral("bu_rotate_down"));
        bu_rotate_down->setMinimumSize(QSize(0, 0));
        bu_rotate_down->setMaximumSize(QSize(40, 40));
        bu_rotate_down->setIcon(icon16);
        bu_rotate_down->setIconSize(QSize(32, 32));

        gridLayout_2->addWidget(bu_rotate_down, 3, 2, 1, 1);


        verticalLayout_3->addLayout(gridLayout_2);

        single_camera_movenent_step_de_3 = new QFrame(groupBox_rotation);
        single_camera_movenent_step_de_3->setObjectName(QStringLiteral("single_camera_movenent_step_de_3"));
        single_camera_movenent_step_de_3->setFrameShape(QFrame::StyledPanel);
        single_camera_movenent_step_de_3->setFrameShadow(QFrame::Raised);
        verticalLayout_57 = new QVBoxLayout(single_camera_movenent_step_de_3);
        verticalLayout_57->setSpacing(2);
        verticalLayout_57->setContentsMargins(2, 2, 2, 2);
        verticalLayout_57->setObjectName(QStringLiteral("verticalLayout_57"));
        verticalLayout_57->setContentsMargins(2, 2, 2, 2);
        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setSpacing(2);
        horizontalLayout_11->setObjectName(QStringLiteral("horizontalLayout_11"));
        label_125 = new QLabel(single_camera_movenent_step_de_3);
        label_125->setObjectName(QStringLiteral("label_125"));

        horizontalLayout_11->addWidget(label_125);

        spinbox_camera_rotation_step = new MyDoubleSpinBox(single_camera_movenent_step_de_3);
        spinbox_camera_rotation_step->setObjectName(QStringLiteral("spinbox_camera_rotation_step"));
        spinbox_camera_rotation_step->setDecimals(2);
        spinbox_camera_rotation_step->setMinimum(0.1);
        spinbox_camera_rotation_step->setMaximum(90);
        spinbox_camera_rotation_step->setSingleStep(5);
        spinbox_camera_rotation_step->setValue(15);

        horizontalLayout_11->addWidget(spinbox_camera_rotation_step);


        verticalLayout_57->addLayout(horizontalLayout_11);


        verticalLayout_3->addWidget(single_camera_movenent_step_de_3);

        comboBox_camera_rotation_mode = new QComboBox(groupBox_rotation);
        comboBox_camera_rotation_mode->setObjectName(QStringLiteral("comboBox_camera_rotation_mode"));

        verticalLayout_3->addWidget(comboBox_camera_rotation_mode);

        comboBox_camera_straight_rotation = new QComboBox(groupBox_rotation);
        comboBox_camera_straight_rotation->setObjectName(QStringLiteral("comboBox_camera_straight_rotation"));

        verticalLayout_3->addWidget(comboBox_camera_straight_rotation);

        vect3_view_angle = new QFrame(groupBox_rotation);
        vect3_view_angle->setObjectName(QStringLiteral("vect3_view_angle"));
        vect3_view_angle->setFrameShape(QFrame::StyledPanel);
        vect3_view_angle->setFrameShadow(QFrame::Raised);
        verticalLayout_13 = new QVBoxLayout(vect3_view_angle);
        verticalLayout_13->setSpacing(2);
        verticalLayout_13->setContentsMargins(2, 2, 2, 2);
        verticalLayout_13->setObjectName(QStringLiteral("verticalLayout_13"));
        verticalLayout_13->setContentsMargins(2, 2, 2, 2);
        formLayout_coordinates = new QFormLayout();
        formLayout_coordinates->setSpacing(2);
        formLayout_coordinates->setObjectName(QStringLiteral("formLayout_coordinates"));
        formLayout_coordinates->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_coordinates->setHorizontalSpacing(2);
        formLayout_coordinates->setVerticalSpacing(1);
        label_15 = new QLabel(vect3_view_angle);
        label_15->setObjectName(QStringLiteral("label_15"));

        formLayout_coordinates->setWidget(0, QFormLayout::LabelRole, label_15);

        vect3_camera_rotation_x = new MyLineEdit(vect3_view_angle);
        vect3_camera_rotation_x->setObjectName(QStringLiteral("vect3_camera_rotation_x"));

        formLayout_coordinates->setWidget(0, QFormLayout::FieldRole, vect3_camera_rotation_x);

        label_16 = new QLabel(vect3_view_angle);
        label_16->setObjectName(QStringLiteral("label_16"));

        formLayout_coordinates->setWidget(1, QFormLayout::LabelRole, label_16);

        vect3_camera_rotation_y = new MyLineEdit(vect3_view_angle);
        vect3_camera_rotation_y->setObjectName(QStringLiteral("vect3_camera_rotation_y"));

        formLayout_coordinates->setWidget(1, QFormLayout::FieldRole, vect3_camera_rotation_y);

        label_17 = new QLabel(vect3_view_angle);
        label_17->setObjectName(QStringLiteral("label_17"));

        formLayout_coordinates->setWidget(2, QFormLayout::LabelRole, label_17);

        vect3_camera_rotation_z = new MyLineEdit(vect3_view_angle);
        vect3_camera_rotation_z->setObjectName(QStringLiteral("vect3_camera_rotation_z"));

        formLayout_coordinates->setWidget(2, QFormLayout::FieldRole, vect3_camera_rotation_z);


        verticalLayout_13->addLayout(formLayout_coordinates);


        verticalLayout_3->addWidget(vect3_view_angle);


        vl_side_functions->addWidget(groupBox_rotation);

        label_mouse_click_functions = new QLabel(scrollAreaWidgetContents_5);
        label_mouse_click_functions->setObjectName(QStringLiteral("label_mouse_click_functions"));

        vl_side_functions->addWidget(label_mouse_click_functions);

        comboBox_mouse_click_function = new QComboBox(scrollAreaWidgetContents_5);
        comboBox_mouse_click_function->setObjectName(QStringLiteral("comboBox_mouse_click_function"));
        comboBox_mouse_click_function->setMinimumSize(QSize(150, 0));

        vl_side_functions->addWidget(comboBox_mouse_click_function);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        vl_side_functions->addItem(verticalSpacer);


        verticalLayout->addLayout(vl_side_functions);

        scrollArea_4->setWidget(scrollAreaWidgetContents_5);

        verticalLayout_24->addWidget(scrollArea_4);

        dockWidget_navigation->setWidget(dockWidgetRightContents);
        RenderWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(2), dockWidget_navigation);
        toolBar = new QToolBar(RenderWindow);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        RenderWindow->addToolBar(Qt::TopToolBarArea, toolBar);
        dockWidget_effects = new QDockWidget(RenderWindow);
        dockWidget_effects->setObjectName(QStringLiteral("dockWidget_effects"));
        dockWidget_effects->setFont(font2);
        dockWidget_effects->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        dockWidgetContents_3 = new QWidget();
        dockWidgetContents_3->setObjectName(QStringLiteral("dockWidgetContents_3"));
        verticalLayout_6 = new QVBoxLayout(dockWidgetContents_3);
        verticalLayout_6->setSpacing(2);
        verticalLayout_6->setContentsMargins(2, 2, 2, 2);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(2, 2, 2, 2);
        scrollArea_2 = new QScrollArea(dockWidgetContents_3);
        scrollArea_2->setObjectName(QStringLiteral("scrollArea_2"));
        scrollArea_2->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        scrollArea_2->setWidgetResizable(true);
        scrollAreaWidgetContents_3 = new QWidget();
        scrollAreaWidgetContents_3->setObjectName(QStringLiteral("scrollAreaWidgetContents_3"));
        scrollAreaWidgetContents_3->setGeometry(QRect(0, 0, 339, 129));
        verticalLayout_26 = new QVBoxLayout(scrollAreaWidgetContents_3);
        verticalLayout_26->setSpacing(2);
        verticalLayout_26->setContentsMargins(2, 2, 2, 2);
        verticalLayout_26->setObjectName(QStringLiteral("verticalLayout_26"));
        verticalLayout_26->setContentsMargins(2, 2, 2, 2);
        tabWidget_2 = new QTabWidget(scrollAreaWidgetContents_3);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setTabPosition(QTabWidget::West);
        tabWidget_2->setUsesScrollButtons(true);
        tabWidget_2->setMovable(true);
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayout_63 = new QVBoxLayout(tab);
        verticalLayout_63->setSpacing(2);
        verticalLayout_63->setContentsMargins(2, 2, 2, 2);
        verticalLayout_63->setObjectName(QStringLiteral("verticalLayout_63"));
        verticalLayout_63->setContentsMargins(2, 2, 2, 2);
        scrollArea_6 = new QScrollArea(tab);
        scrollArea_6->setObjectName(QStringLiteral("scrollArea_6"));
        scrollArea_6->setWidgetResizable(true);
        scrollAreaWidgetContents_7 = new QWidget();
        scrollAreaWidgetContents_7->setObjectName(QStringLiteral("scrollAreaWidgetContents_7"));
        scrollAreaWidgetContents_7->setGeometry(QRect(0, 0, 290, 734));
        verticalLayout_29 = new QVBoxLayout(scrollAreaWidgetContents_7);
        verticalLayout_29->setSpacing(2);
        verticalLayout_29->setContentsMargins(2, 2, 2, 2);
        verticalLayout_29->setObjectName(QStringLiteral("verticalLayout_29"));
        verticalLayout_29->setContentsMargins(2, 2, 2, 2);
        gridLayout_7 = new QGridLayout();
        gridLayout_7->setSpacing(2);
        gridLayout_7->setObjectName(QStringLiteral("gridLayout_7"));
        label_172 = new QLabel(scrollAreaWidgetContents_7);
        label_172->setObjectName(QStringLiteral("label_172"));

        gridLayout_7->addWidget(label_172, 7, 0, 1, 1);

        colorButton_transparency_interior_color = new MyColorButton(scrollAreaWidgetContents_7);
        colorButton_transparency_interior_color->setObjectName(QStringLiteral("colorButton_transparency_interior_color"));

        gridLayout_7->addWidget(colorButton_transparency_interior_color, 7, 1, 1, 1);

        slider_specular = new QSlider(scrollAreaWidgetContents_7);
        slider_specular->setObjectName(QStringLiteral("slider_specular"));
        slider_specular->setMaximum(200);
        slider_specular->setSingleStep(1);
        slider_specular->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(slider_specular, 1, 1, 1, 1);

        spinbox_ambient_occlusion = new MyDoubleSpinBox(scrollAreaWidgetContents_7);
        spinbox_ambient_occlusion->setObjectName(QStringLiteral("spinbox_ambient_occlusion"));
        spinbox_ambient_occlusion->setDecimals(2);
        spinbox_ambient_occlusion->setMaximum(1000);
        spinbox_ambient_occlusion->setSingleStep(0.1);

        gridLayout_7->addWidget(spinbox_ambient_occlusion, 2, 2, 1, 1);

        spinbox_reflect = new MyDoubleSpinBox(scrollAreaWidgetContents_7);
        spinbox_reflect->setObjectName(QStringLiteral("spinbox_reflect"));
        spinbox_reflect->setDecimals(2);
        spinbox_reflect->setMaximum(1000);
        spinbox_reflect->setSingleStep(0.1);

        gridLayout_7->addWidget(spinbox_reflect, 3, 2, 1, 1);

        slider_shading = new QSlider(scrollAreaWidgetContents_7);
        slider_shading->setObjectName(QStringLiteral("slider_shading"));
        slider_shading->setMaximum(200);
        slider_shading->setSingleStep(1);
        slider_shading->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(slider_shading, 0, 1, 1, 1);

        label_55 = new QLabel(scrollAreaWidgetContents_7);
        label_55->setObjectName(QStringLiteral("label_55"));

        gridLayout_7->addWidget(label_55, 2, 0, 1, 1);

        label_56 = new QLabel(scrollAreaWidgetContents_7);
        label_56->setObjectName(QStringLiteral("label_56"));

        gridLayout_7->addWidget(label_56, 3, 0, 1, 1);

        slider_reflect = new QSlider(scrollAreaWidgetContents_7);
        slider_reflect->setObjectName(QStringLiteral("slider_reflect"));
        slider_reflect->setMaximum(200);
        slider_reflect->setSingleStep(1);
        slider_reflect->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(slider_reflect, 3, 1, 1, 1);

        spinbox_shading = new MyDoubleSpinBox(scrollAreaWidgetContents_7);
        spinbox_shading->setObjectName(QStringLiteral("spinbox_shading"));
        spinbox_shading->setDecimals(2);
        spinbox_shading->setMaximum(1000);
        spinbox_shading->setSingleStep(0.1);

        gridLayout_7->addWidget(spinbox_shading, 0, 2, 1, 1);

        spinbox_specular = new MyDoubleSpinBox(scrollAreaWidgetContents_7);
        spinbox_specular->setObjectName(QStringLiteral("spinbox_specular"));
        spinbox_specular->setDecimals(2);
        spinbox_specular->setMaximum(1000);
        spinbox_specular->setSingleStep(0.1);

        gridLayout_7->addWidget(spinbox_specular, 1, 2, 1, 1);

        label_52 = new QLabel(scrollAreaWidgetContents_7);
        label_52->setObjectName(QStringLiteral("label_52"));

        gridLayout_7->addWidget(label_52, 0, 0, 1, 1);

        slider_ambient_occlusion = new QSlider(scrollAreaWidgetContents_7);
        slider_ambient_occlusion->setObjectName(QStringLiteral("slider_ambient_occlusion"));
        slider_ambient_occlusion->setMaximum(200);
        slider_ambient_occlusion->setSingleStep(1);
        slider_ambient_occlusion->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(slider_ambient_occlusion, 2, 1, 1, 1);

        label_53 = new QLabel(scrollAreaWidgetContents_7);
        label_53->setObjectName(QStringLiteral("label_53"));

        gridLayout_7->addWidget(label_53, 1, 0, 1, 1);

        slider_transparency_of_surface = new QSlider(scrollAreaWidgetContents_7);
        slider_transparency_of_surface->setObjectName(QStringLiteral("slider_transparency_of_surface"));
        slider_transparency_of_surface->setMaximum(100);
        slider_transparency_of_surface->setSingleStep(1);
        slider_transparency_of_surface->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(slider_transparency_of_surface, 4, 1, 1, 1);

        label_171 = new QLabel(scrollAreaWidgetContents_7);
        label_171->setObjectName(QStringLiteral("label_171"));

        gridLayout_7->addWidget(label_171, 5, 0, 1, 1);

        label_170 = new QLabel(scrollAreaWidgetContents_7);
        label_170->setObjectName(QStringLiteral("label_170"));

        gridLayout_7->addWidget(label_170, 4, 0, 1, 1);

        spinbox_transparency_of_surface = new MyDoubleSpinBox(scrollAreaWidgetContents_7);
        spinbox_transparency_of_surface->setObjectName(QStringLiteral("spinbox_transparency_of_surface"));
        spinbox_transparency_of_surface->setDecimals(2);
        spinbox_transparency_of_surface->setMaximum(1);
        spinbox_transparency_of_surface->setSingleStep(0.1);

        gridLayout_7->addWidget(spinbox_transparency_of_surface, 4, 2, 1, 1);

        label_173 = new QLabel(scrollAreaWidgetContents_7);
        label_173->setObjectName(QStringLiteral("label_173"));

        gridLayout_7->addWidget(label_173, 6, 0, 1, 1);

        slider_transparency_index_of_refraction = new QSlider(scrollAreaWidgetContents_7);
        slider_transparency_index_of_refraction->setObjectName(QStringLiteral("slider_transparency_index_of_refraction"));
        slider_transparency_index_of_refraction->setMaximum(300);
        slider_transparency_index_of_refraction->setSingleStep(1);
        slider_transparency_index_of_refraction->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(slider_transparency_index_of_refraction, 6, 1, 1, 1);

        logedit_transparency_of_interior = new MyLineEdit(scrollAreaWidgetContents_7);
        logedit_transparency_of_interior->setObjectName(QStringLiteral("logedit_transparency_of_interior"));
        sizePolicy1.setHeightForWidth(logedit_transparency_of_interior->sizePolicy().hasHeightForWidth());
        logedit_transparency_of_interior->setSizePolicy(sizePolicy1);

        gridLayout_7->addWidget(logedit_transparency_of_interior, 5, 2, 1, 1);

        spinbox_transparency_index_of_refraction = new MyDoubleSpinBox(scrollAreaWidgetContents_7);
        spinbox_transparency_index_of_refraction->setObjectName(QStringLiteral("spinbox_transparency_index_of_refraction"));
        spinbox_transparency_index_of_refraction->setDecimals(2);
        spinbox_transparency_index_of_refraction->setMaximum(10);
        spinbox_transparency_index_of_refraction->setSingleStep(0.1);

        gridLayout_7->addWidget(spinbox_transparency_index_of_refraction, 6, 2, 1, 1);

        logslider_transparency_of_interior = new QSlider(scrollAreaWidgetContents_7);
        logslider_transparency_of_interior->setObjectName(QStringLiteral("logslider_transparency_of_interior"));
        sizePolicy1.setHeightForWidth(logslider_transparency_of_interior->sizePolicy().hasHeightForWidth());
        logslider_transparency_of_interior->setSizePolicy(sizePolicy1);
        logslider_transparency_of_interior->setSizeIncrement(QSize(0, 0));
        logslider_transparency_of_interior->setMinimum(-1000);
        logslider_transparency_of_interior->setMaximum(0);
        logslider_transparency_of_interior->setOrientation(Qt::Horizontal);

        gridLayout_7->addWidget(logslider_transparency_of_interior, 5, 1, 1, 1);

        checkBox_fresnel_reflectance = new MyCheckBox(scrollAreaWidgetContents_7);
        checkBox_fresnel_reflectance->setObjectName(QStringLiteral("checkBox_fresnel_reflectance"));

        gridLayout_7->addWidget(checkBox_fresnel_reflectance, 8, 0, 1, 3);


        verticalLayout_29->addLayout(gridLayout_7);

        groupCheck_ambient_occlusion_enabled = new MyGroupBox(scrollAreaWidgetContents_7);
        groupCheck_ambient_occlusion_enabled->setObjectName(QStringLiteral("groupCheck_ambient_occlusion_enabled"));
        groupCheck_ambient_occlusion_enabled->setCheckable(true);
        verticalLayout_31 = new QVBoxLayout(groupCheck_ambient_occlusion_enabled);
        verticalLayout_31->setSpacing(2);
        verticalLayout_31->setContentsMargins(2, 2, 2, 2);
        verticalLayout_31->setObjectName(QStringLiteral("verticalLayout_31"));
        verticalLayout_31->setContentsMargins(2, 2, 2, 2);
        gridLayout_11 = new QGridLayout();
        gridLayout_11->setSpacing(2);
        gridLayout_11->setObjectName(QStringLiteral("gridLayout_11"));
        slider_ambient_occlusion_fast_tune = new QSlider(groupCheck_ambient_occlusion_enabled);
        slider_ambient_occlusion_fast_tune->setObjectName(QStringLiteral("slider_ambient_occlusion_fast_tune"));
        slider_ambient_occlusion_fast_tune->setMinimum(5);
        slider_ambient_occlusion_fast_tune->setMaximum(500);
        slider_ambient_occlusion_fast_tune->setSingleStep(1);
        slider_ambient_occlusion_fast_tune->setOrientation(Qt::Horizontal);

        gridLayout_11->addWidget(slider_ambient_occlusion_fast_tune, 1, 1, 1, 1);

        label_68 = new QLabel(groupCheck_ambient_occlusion_enabled);
        label_68->setObjectName(QStringLiteral("label_68"));

        gridLayout_11->addWidget(label_68, 1, 0, 1, 1);

        sliderInt_ambient_occlusion_quality = new QSlider(groupCheck_ambient_occlusion_enabled);
        sliderInt_ambient_occlusion_quality->setObjectName(QStringLiteral("sliderInt_ambient_occlusion_quality"));
        sliderInt_ambient_occlusion_quality->setMinimum(1);
        sliderInt_ambient_occlusion_quality->setMaximum(30);
        sliderInt_ambient_occlusion_quality->setSingleStep(1);
        sliderInt_ambient_occlusion_quality->setOrientation(Qt::Horizontal);

        gridLayout_11->addWidget(sliderInt_ambient_occlusion_quality, 0, 1, 1, 1);

        label_69 = new QLabel(groupCheck_ambient_occlusion_enabled);
        label_69->setObjectName(QStringLiteral("label_69"));

        gridLayout_11->addWidget(label_69, 0, 0, 1, 1);

        label_70 = new QLabel(groupCheck_ambient_occlusion_enabled);
        label_70->setObjectName(QStringLiteral("label_70"));

        gridLayout_11->addWidget(label_70, 2, 0, 1, 1);

        spinboxInt_ambient_occlusion_quality = new MySpinBox(groupCheck_ambient_occlusion_enabled);
        spinboxInt_ambient_occlusion_quality->setObjectName(QStringLiteral("spinboxInt_ambient_occlusion_quality"));
        spinboxInt_ambient_occlusion_quality->setMaximum(30);

        gridLayout_11->addWidget(spinboxInt_ambient_occlusion_quality, 0, 2, 1, 1);

        comboBox_ambient_occlusion_mode = new QComboBox(groupCheck_ambient_occlusion_enabled);
        comboBox_ambient_occlusion_mode->setObjectName(QStringLiteral("comboBox_ambient_occlusion_mode"));

        gridLayout_11->addWidget(comboBox_ambient_occlusion_mode, 2, 1, 1, 1);

        spinbox_ambient_occlusion_fast_tune = new MyDoubleSpinBox(groupCheck_ambient_occlusion_enabled);
        spinbox_ambient_occlusion_fast_tune->setObjectName(QStringLiteral("spinbox_ambient_occlusion_fast_tune"));
        spinbox_ambient_occlusion_fast_tune->setDecimals(2);
        spinbox_ambient_occlusion_fast_tune->setMinimum(0.01);
        spinbox_ambient_occlusion_fast_tune->setMaximum(10);
        spinbox_ambient_occlusion_fast_tune->setSingleStep(0.1);

        gridLayout_11->addWidget(spinbox_ambient_occlusion_fast_tune, 1, 2, 1, 1);


        verticalLayout_31->addLayout(gridLayout_11);

        frame_lightmap_texture = new QFrame(groupCheck_ambient_occlusion_enabled);
        frame_lightmap_texture->setObjectName(QStringLiteral("frame_lightmap_texture"));
        frame_lightmap_texture->setEnabled(false);
        frame_lightmap_texture->setFrameShape(QFrame::StyledPanel);
        frame_lightmap_texture->setFrameShadow(QFrame::Raised);
        verticalLayout_69 = new QVBoxLayout(frame_lightmap_texture);
        verticalLayout_69->setSpacing(2);
        verticalLayout_69->setContentsMargins(2, 2, 2, 2);
        verticalLayout_69->setObjectName(QStringLiteral("verticalLayout_69"));
        verticalLayout_69->setContentsMargins(2, 2, 2, 2);
        gridLayout_34 = new QGridLayout();
        gridLayout_34->setSpacing(2);
        gridLayout_34->setObjectName(QStringLiteral("gridLayout_34"));
        button_selectLightMapTexture = new QPushButton(frame_lightmap_texture);
        button_selectLightMapTexture->setObjectName(QStringLiteral("button_selectLightMapTexture"));

        gridLayout_34->addWidget(button_selectLightMapTexture, 0, 2, 1, 1);

        text_file_lightmap = new MyLineEdit(frame_lightmap_texture);
        text_file_lightmap->setObjectName(QStringLiteral("text_file_lightmap"));

        gridLayout_34->addWidget(text_file_lightmap, 0, 1, 1, 1);

        label_133 = new QLabel(frame_lightmap_texture);
        label_133->setObjectName(QStringLiteral("label_133"));

        gridLayout_34->addWidget(label_133, 0, 0, 1, 1);


        verticalLayout_69->addLayout(gridLayout_34);

        label_lightmapTextureView = new QLabel(frame_lightmap_texture);
        label_lightmapTextureView->setObjectName(QStringLiteral("label_lightmapTextureView"));
        label_lightmapTextureView->setMinimumSize(QSize(0, 50));

        verticalLayout_69->addWidget(label_lightmapTextureView);


        verticalLayout_31->addWidget(frame_lightmap_texture);


        verticalLayout_29->addWidget(groupCheck_ambient_occlusion_enabled);

        groupCheck_fractal_color = new MyGroupBox(scrollAreaWidgetContents_7);
        groupCheck_fractal_color->setObjectName(QStringLiteral("groupCheck_fractal_color"));
        groupCheck_fractal_color->setCheckable(true);
        verticalLayout_32 = new QVBoxLayout(groupCheck_fractal_color);
        verticalLayout_32->setSpacing(2);
        verticalLayout_32->setContentsMargins(2, 2, 2, 2);
        verticalLayout_32->setObjectName(QStringLiteral("verticalLayout_32"));
        verticalLayout_32->setContentsMargins(2, 2, 2, 2);
        gridLayout_12 = new QGridLayout();
        gridLayout_12->setSpacing(2);
        gridLayout_12->setObjectName(QStringLiteral("gridLayout_12"));
        label_75 = new QLabel(groupCheck_fractal_color);
        label_75->setObjectName(QStringLiteral("label_75"));

        gridLayout_12->addWidget(label_75, 4, 0, 1, 1);

        spinboxInt_coloring_random_seed = new MySpinBox(groupCheck_fractal_color);
        spinboxInt_coloring_random_seed->setObjectName(QStringLiteral("spinboxInt_coloring_random_seed"));
        spinboxInt_coloring_random_seed->setMaximum(999999);

        gridLayout_12->addWidget(spinboxInt_coloring_random_seed, 5, 2, 1, 1);

        label_74 = new QLabel(groupCheck_fractal_color);
        label_74->setObjectName(QStringLiteral("label_74"));

        gridLayout_12->addWidget(label_74, 5, 0, 1, 1);

        label_73 = new QLabel(groupCheck_fractal_color);
        label_73->setObjectName(QStringLiteral("label_73"));

        gridLayout_12->addWidget(label_73, 3, 0, 1, 1);

        spinbox_coloring_saturation = new MyDoubleSpinBox(groupCheck_fractal_color);
        spinbox_coloring_saturation->setObjectName(QStringLiteral("spinbox_coloring_saturation"));
        spinbox_coloring_saturation->setAccelerated(false);
        spinbox_coloring_saturation->setDecimals(2);
        spinbox_coloring_saturation->setMinimum(0);
        spinbox_coloring_saturation->setMaximum(1000);
        spinbox_coloring_saturation->setSingleStep(0.01);
        spinbox_coloring_saturation->setValue(0);

        gridLayout_12->addWidget(spinbox_coloring_saturation, 3, 2, 1, 1);

        colorpalette_surface_color_palette = new ColorPaletteWidget(groupCheck_fractal_color);
        colorpalette_surface_color_palette->setObjectName(QStringLiteral("colorpalette_surface_color_palette"));
        colorpalette_surface_color_palette->setMinimumSize(QSize(0, 30));

        gridLayout_12->addWidget(colorpalette_surface_color_palette, 0, 1, 1, 2);

        spinbox_coloring_speed = new MyDoubleSpinBox(groupCheck_fractal_color);
        spinbox_coloring_speed->setObjectName(QStringLiteral("spinbox_coloring_speed"));
        spinbox_coloring_speed->setAccelerated(false);
        spinbox_coloring_speed->setDecimals(2);
        spinbox_coloring_speed->setMinimum(0);
        spinbox_coloring_speed->setMaximum(1000);
        spinbox_coloring_speed->setSingleStep(0.01);
        spinbox_coloring_speed->setValue(0);

        gridLayout_12->addWidget(spinbox_coloring_speed, 4, 2, 1, 1);

        pushButton_getPaletteFromImage = new QPushButton(groupCheck_fractal_color);
        pushButton_getPaletteFromImage->setObjectName(QStringLiteral("pushButton_getPaletteFromImage"));

        gridLayout_12->addWidget(pushButton_getPaletteFromImage, 7, 0, 1, 3);

        slider_coloring_speed = new QSlider(groupCheck_fractal_color);
        slider_coloring_speed->setObjectName(QStringLiteral("slider_coloring_speed"));
        slider_coloring_speed->setMinimum(0);
        slider_coloring_speed->setMaximum(1000);
        slider_coloring_speed->setSingleStep(1);
        slider_coloring_speed->setOrientation(Qt::Horizontal);

        gridLayout_12->addWidget(slider_coloring_speed, 4, 1, 1, 1);

        slider_coloring_saturation = new QSlider(groupCheck_fractal_color);
        slider_coloring_saturation->setObjectName(QStringLiteral("slider_coloring_saturation"));
        slider_coloring_saturation->setMinimum(0);
        slider_coloring_saturation->setMaximum(1000);
        slider_coloring_saturation->setSingleStep(1);
        slider_coloring_saturation->setOrientation(Qt::Horizontal);

        gridLayout_12->addWidget(slider_coloring_saturation, 3, 1, 1, 1);

        label_127 = new QLabel(groupCheck_fractal_color);
        label_127->setObjectName(QStringLiteral("label_127"));

        gridLayout_12->addWidget(label_127, 2, 0, 1, 1);

        label_71 = new QLabel(groupCheck_fractal_color);
        label_71->setObjectName(QStringLiteral("label_71"));

        gridLayout_12->addWidget(label_71, 0, 0, 1, 1);

        sliderInt_coloring_palette_size = new QSlider(groupCheck_fractal_color);
        sliderInt_coloring_palette_size->setObjectName(QStringLiteral("sliderInt_coloring_palette_size"));
        sliderInt_coloring_palette_size->setMinimum(1);
        sliderInt_coloring_palette_size->setMaximum(255);
        sliderInt_coloring_palette_size->setSingleStep(8);
        sliderInt_coloring_palette_size->setPageStep(64);
        sliderInt_coloring_palette_size->setOrientation(Qt::Horizontal);

        gridLayout_12->addWidget(sliderInt_coloring_palette_size, 2, 1, 1, 1);

        spinboxInt_coloring_palette_size = new MySpinBox(groupCheck_fractal_color);
        spinboxInt_coloring_palette_size->setObjectName(QStringLiteral("spinboxInt_coloring_palette_size"));
        spinboxInt_coloring_palette_size->setMinimum(1);
        spinboxInt_coloring_palette_size->setMaximum(255);

        gridLayout_12->addWidget(spinboxInt_coloring_palette_size, 2, 2, 1, 1);

        label_72 = new QLabel(groupCheck_fractal_color);
        label_72->setObjectName(QStringLiteral("label_72"));

        gridLayout_12->addWidget(label_72, 1, 0, 1, 1);

        slider_coloring_palette_offset = new QSlider(groupCheck_fractal_color);
        slider_coloring_palette_offset->setObjectName(QStringLiteral("slider_coloring_palette_offset"));
        slider_coloring_palette_offset->setMinimum(0);
        slider_coloring_palette_offset->setMaximum(1000);
        slider_coloring_palette_offset->setSingleStep(1);
        slider_coloring_palette_offset->setOrientation(Qt::Horizontal);

        gridLayout_12->addWidget(slider_coloring_palette_offset, 1, 1, 1, 1);

        spinbox_coloring_palette_offset = new MyDoubleSpinBox(groupCheck_fractal_color);
        spinbox_coloring_palette_offset->setObjectName(QStringLiteral("spinbox_coloring_palette_offset"));
        spinbox_coloring_palette_offset->setAccelerated(false);
        spinbox_coloring_palette_offset->setDecimals(2);
        spinbox_coloring_palette_offset->setMinimum(0);
        spinbox_coloring_palette_offset->setMaximum(256);
        spinbox_coloring_palette_offset->setSingleStep(0.01);
        spinbox_coloring_palette_offset->setValue(0);

        gridLayout_12->addWidget(spinbox_coloring_palette_offset, 1, 2, 1, 1);

        pushButton_randomPalette = new QPushButton(groupCheck_fractal_color);
        pushButton_randomPalette->setObjectName(QStringLiteral("pushButton_randomPalette"));

        gridLayout_12->addWidget(pushButton_randomPalette, 6, 0, 1, 3);

        pushButton_randomize = new QPushButton(groupCheck_fractal_color);
        pushButton_randomize->setObjectName(QStringLiteral("pushButton_randomize"));

        gridLayout_12->addWidget(pushButton_randomize, 5, 1, 1, 1);


        verticalLayout_32->addLayout(gridLayout_12);


        verticalLayout_29->addWidget(groupCheck_fractal_color);

        groupCheck_env_mapping_enable = new MyGroupBox(scrollAreaWidgetContents_7);
        groupCheck_env_mapping_enable->setObjectName(QStringLiteral("groupCheck_env_mapping_enable"));
        groupCheck_env_mapping_enable->setCheckable(true);
        verticalLayout_70 = new QVBoxLayout(groupCheck_env_mapping_enable);
        verticalLayout_70->setSpacing(2);
        verticalLayout_70->setContentsMargins(2, 2, 2, 2);
        verticalLayout_70->setObjectName(QStringLiteral("verticalLayout_70"));
        verticalLayout_70->setContentsMargins(2, 2, 2, 2);
        gridLayout_33 = new QGridLayout();
        gridLayout_33->setSpacing(2);
        gridLayout_33->setObjectName(QStringLiteral("gridLayout_33"));
        button_selectEnvMapTexture = new QPushButton(groupCheck_env_mapping_enable);
        button_selectEnvMapTexture->setObjectName(QStringLiteral("button_selectEnvMapTexture"));

        gridLayout_33->addWidget(button_selectEnvMapTexture, 0, 2, 1, 1);

        text_file_envmap = new MyLineEdit(groupCheck_env_mapping_enable);
        text_file_envmap->setObjectName(QStringLiteral("text_file_envmap"));

        gridLayout_33->addWidget(text_file_envmap, 0, 1, 1, 1);

        label_132 = new QLabel(groupCheck_env_mapping_enable);
        label_132->setObjectName(QStringLiteral("label_132"));

        gridLayout_33->addWidget(label_132, 0, 0, 1, 1);


        verticalLayout_70->addLayout(gridLayout_33);

        label_envmapTextureView = new QLabel(groupCheck_env_mapping_enable);
        label_envmapTextureView->setObjectName(QStringLiteral("label_envmapTextureView"));
        label_envmapTextureView->setMinimumSize(QSize(0, 50));

        verticalLayout_70->addWidget(label_envmapTextureView);


        verticalLayout_29->addWidget(groupCheck_env_mapping_enable);

        scrollArea_6->setWidget(scrollAreaWidgetContents_7);

        verticalLayout_63->addWidget(scrollArea_6);

        tabWidget_2->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        verticalLayout_64 = new QVBoxLayout(tab_2);
        verticalLayout_64->setSpacing(2);
        verticalLayout_64->setContentsMargins(2, 2, 2, 2);
        verticalLayout_64->setObjectName(QStringLiteral("verticalLayout_64"));
        verticalLayout_64->setContentsMargins(2, 2, 2, 2);
        scrollArea_7 = new QScrollArea(tab_2);
        scrollArea_7->setObjectName(QStringLiteral("scrollArea_7"));
        scrollArea_7->setWidgetResizable(true);
        scrollAreaWidgetContents_8 = new QWidget();
        scrollAreaWidgetContents_8->setObjectName(QStringLiteral("scrollAreaWidgetContents_8"));
        scrollAreaWidgetContents_8->setGeometry(QRect(0, 0, 289, 180));
        verticalLayout_34 = new QVBoxLayout(scrollAreaWidgetContents_8);
        verticalLayout_34->setSpacing(2);
        verticalLayout_34->setContentsMargins(2, 2, 2, 2);
        verticalLayout_34->setObjectName(QStringLiteral("verticalLayout_34"));
        verticalLayout_34->setContentsMargins(2, 2, 2, 2);
        groupCheck_raytraced_reflections = new MyGroupBox(scrollAreaWidgetContents_8);
        groupCheck_raytraced_reflections->setObjectName(QStringLiteral("groupCheck_raytraced_reflections"));
        groupCheck_raytraced_reflections->setCheckable(true);
        verticalLayout_72 = new QVBoxLayout(groupCheck_raytraced_reflections);
        verticalLayout_72->setSpacing(2);
        verticalLayout_72->setContentsMargins(2, 2, 2, 2);
        verticalLayout_72->setObjectName(QStringLiteral("verticalLayout_72"));
        verticalLayout_72->setContentsMargins(2, 2, 2, 2);
        gridLayout_9 = new QGridLayout();
        gridLayout_9->setSpacing(2);
        gridLayout_9->setObjectName(QStringLiteral("gridLayout_9"));
        spinboxInt_reflections_max = new MySpinBox(groupCheck_raytraced_reflections);
        spinboxInt_reflections_max->setObjectName(QStringLiteral("spinboxInt_reflections_max"));
        spinboxInt_reflections_max->setMaximum(9);

        gridLayout_9->addWidget(spinboxInt_reflections_max, 0, 2, 1, 1);

        label_62 = new QLabel(groupCheck_raytraced_reflections);
        label_62->setObjectName(QStringLiteral("label_62"));

        gridLayout_9->addWidget(label_62, 0, 0, 1, 1);

        sliderInt_reflections_max = new QSlider(groupCheck_raytraced_reflections);
        sliderInt_reflections_max->setObjectName(QStringLiteral("sliderInt_reflections_max"));
        sliderInt_reflections_max->setMaximum(9);
        sliderInt_reflections_max->setSingleStep(1);
        sliderInt_reflections_max->setPageStep(1);
        sliderInt_reflections_max->setOrientation(Qt::Horizontal);

        gridLayout_9->addWidget(sliderInt_reflections_max, 0, 1, 1, 1);


        verticalLayout_72->addLayout(gridLayout_9);


        verticalLayout_34->addWidget(groupCheck_raytraced_reflections);

        groupCheck_DOF_enabled = new MyGroupBox(scrollAreaWidgetContents_8);
        groupCheck_DOF_enabled->setObjectName(QStringLiteral("groupCheck_DOF_enabled"));
        groupCheck_DOF_enabled->setCheckable(true);
        verticalLayout_73 = new QVBoxLayout(groupCheck_DOF_enabled);
        verticalLayout_73->setSpacing(2);
        verticalLayout_73->setContentsMargins(2, 2, 2, 2);
        verticalLayout_73->setObjectName(QStringLiteral("verticalLayout_73"));
        verticalLayout_73->setContentsMargins(2, 2, 2, 2);
        gridLayout_35 = new QGridLayout();
        gridLayout_35->setSpacing(2);
        gridLayout_35->setObjectName(QStringLiteral("gridLayout_35"));
        label_131 = new QLabel(groupCheck_DOF_enabled);
        label_131->setObjectName(QStringLiteral("label_131"));

        gridLayout_35->addWidget(label_131, 0, 0, 1, 1);

        label_136 = new QLabel(groupCheck_DOF_enabled);
        label_136->setObjectName(QStringLiteral("label_136"));

        gridLayout_35->addWidget(label_136, 1, 0, 1, 1);

        logslider_DOF_focus = new QSlider(groupCheck_DOF_enabled);
        logslider_DOF_focus->setObjectName(QStringLiteral("logslider_DOF_focus"));
        sizePolicy1.setHeightForWidth(logslider_DOF_focus->sizePolicy().hasHeightForWidth());
        logslider_DOF_focus->setSizePolicy(sizePolicy1);
        logslider_DOF_focus->setSizeIncrement(QSize(0, 0));
        logslider_DOF_focus->setMinimum(-1500);
        logslider_DOF_focus->setMaximum(400);
        logslider_DOF_focus->setOrientation(Qt::Horizontal);

        gridLayout_35->addWidget(logslider_DOF_focus, 0, 1, 1, 1);

        logedit_DOF_focus = new MyLineEdit(groupCheck_DOF_enabled);
        logedit_DOF_focus->setObjectName(QStringLiteral("logedit_DOF_focus"));
        sizePolicy1.setHeightForWidth(logedit_DOF_focus->sizePolicy().hasHeightForWidth());
        logedit_DOF_focus->setSizePolicy(sizePolicy1);

        gridLayout_35->addWidget(logedit_DOF_focus, 0, 2, 1, 1);

        slider_DOF_radius = new QSlider(groupCheck_DOF_enabled);
        slider_DOF_radius->setObjectName(QStringLiteral("slider_DOF_radius"));
        slider_DOF_radius->setMinimum(1);
        slider_DOF_radius->setMaximum(10000);
        slider_DOF_radius->setSingleStep(1);
        slider_DOF_radius->setOrientation(Qt::Horizontal);

        gridLayout_35->addWidget(slider_DOF_radius, 1, 1, 1, 1);

        spinbox_DOF_radius = new MyDoubleSpinBox(groupCheck_DOF_enabled);
        spinbox_DOF_radius->setObjectName(QStringLiteral("spinbox_DOF_radius"));
        spinbox_DOF_radius->setDecimals(2);
        spinbox_DOF_radius->setMinimum(0.01);
        spinbox_DOF_radius->setMaximum(500);
        spinbox_DOF_radius->setSingleStep(1);
        spinbox_DOF_radius->setValue(1);

        gridLayout_35->addWidget(spinbox_DOF_radius, 1, 2, 1, 1);


        verticalLayout_73->addLayout(gridLayout_35);

        pushButton_DOF_update = new QPushButton(groupCheck_DOF_enabled);
        pushButton_DOF_update->setObjectName(QStringLiteral("pushButton_DOF_update"));

        verticalLayout_73->addWidget(pushButton_DOF_update);

        pushButton_DOF_set_focus = new QPushButton(groupCheck_DOF_enabled);
        pushButton_DOF_set_focus->setObjectName(QStringLiteral("pushButton_DOF_set_focus"));

        verticalLayout_73->addWidget(pushButton_DOF_set_focus);


        verticalLayout_34->addWidget(groupCheck_DOF_enabled);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_34->addItem(verticalSpacer_2);

        scrollArea_7->setWidget(scrollAreaWidgetContents_8);

        verticalLayout_64->addWidget(scrollArea_7);

        tabWidget_2->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        verticalLayout_65 = new QVBoxLayout(tab_3);
        verticalLayout_65->setSpacing(2);
        verticalLayout_65->setContentsMargins(2, 2, 2, 2);
        verticalLayout_65->setObjectName(QStringLiteral("verticalLayout_65"));
        verticalLayout_65->setContentsMargins(2, 2, 2, 2);
        scrollArea_8 = new QScrollArea(tab_3);
        scrollArea_8->setObjectName(QStringLiteral("scrollArea_8"));
        scrollArea_8->setWidgetResizable(true);
        scrollAreaWidgetContents_9 = new QWidget();
        scrollAreaWidgetContents_9->setObjectName(QStringLiteral("scrollAreaWidgetContents_9"));
        scrollAreaWidgetContents_9->setGeometry(QRect(0, 0, 289, 533));
        verticalLayout_35 = new QVBoxLayout(scrollAreaWidgetContents_9);
        verticalLayout_35->setSpacing(2);
        verticalLayout_35->setContentsMargins(2, 2, 2, 2);
        verticalLayout_35->setObjectName(QStringLiteral("verticalLayout_35"));
        verticalLayout_35->setContentsMargins(2, 2, 2, 2);
        groupCheck_basic_fog_enabled = new MyGroupBox(scrollAreaWidgetContents_9);
        groupCheck_basic_fog_enabled->setObjectName(QStringLiteral("groupCheck_basic_fog_enabled"));
        groupCheck_basic_fog_enabled->setCheckable(true);
        verticalLayout_30 = new QVBoxLayout(groupCheck_basic_fog_enabled);
        verticalLayout_30->setSpacing(2);
        verticalLayout_30->setContentsMargins(2, 2, 2, 2);
        verticalLayout_30->setObjectName(QStringLiteral("verticalLayout_30"));
        verticalLayout_30->setContentsMargins(2, 2, 2, 2);
        gridLayout_10 = new QGridLayout();
        gridLayout_10->setSpacing(2);
        gridLayout_10->setObjectName(QStringLiteral("gridLayout_10"));
        logslider_basic_fog_visibility = new QSlider(groupCheck_basic_fog_enabled);
        logslider_basic_fog_visibility->setObjectName(QStringLiteral("logslider_basic_fog_visibility"));
        logslider_basic_fog_visibility->setMinimum(-1500);
        logslider_basic_fog_visibility->setMaximum(500);
        logslider_basic_fog_visibility->setOrientation(Qt::Horizontal);

        gridLayout_10->addWidget(logslider_basic_fog_visibility, 0, 1, 1, 1);

        logedit_basic_fog_visibility = new MyLineEdit(groupCheck_basic_fog_enabled);
        logedit_basic_fog_visibility->setObjectName(QStringLiteral("logedit_basic_fog_visibility"));
        logedit_basic_fog_visibility->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);

        gridLayout_10->addWidget(logedit_basic_fog_visibility, 0, 2, 1, 1);

        label_64 = new QLabel(groupCheck_basic_fog_enabled);
        label_64->setObjectName(QStringLiteral("label_64"));

        gridLayout_10->addWidget(label_64, 1, 0, 1, 1);

        colorButton_basic_fog_color = new MyColorButton(groupCheck_basic_fog_enabled);
        colorButton_basic_fog_color->setObjectName(QStringLiteral("colorButton_basic_fog_color"));

        gridLayout_10->addWidget(colorButton_basic_fog_color, 1, 1, 1, 1);

        label_63 = new QLabel(groupCheck_basic_fog_enabled);
        label_63->setObjectName(QStringLiteral("label_63"));

        gridLayout_10->addWidget(label_63, 0, 0, 1, 1);


        verticalLayout_30->addLayout(gridLayout_10);

        pushButton_set_fog_by_mouse = new QPushButton(groupCheck_basic_fog_enabled);
        pushButton_set_fog_by_mouse->setObjectName(QStringLiteral("pushButton_set_fog_by_mouse"));

        verticalLayout_30->addWidget(pushButton_set_fog_by_mouse);


        verticalLayout_35->addWidget(groupCheck_basic_fog_enabled);

        groupCheck_glow_enabled = new MyGroupBox(scrollAreaWidgetContents_9);
        groupCheck_glow_enabled->setObjectName(QStringLiteral("groupCheck_glow_enabled"));
        groupCheck_glow_enabled->setCheckable(true);
        verticalLayout_28 = new QVBoxLayout(groupCheck_glow_enabled);
        verticalLayout_28->setSpacing(2);
        verticalLayout_28->setContentsMargins(2, 2, 2, 2);
        verticalLayout_28->setObjectName(QStringLiteral("verticalLayout_28"));
        verticalLayout_28->setContentsMargins(2, 2, 2, 2);
        gridLayout_14 = new QGridLayout();
        gridLayout_14->setSpacing(2);
        gridLayout_14->setObjectName(QStringLiteral("gridLayout_14"));
        label_88 = new QLabel(groupCheck_glow_enabled);
        label_88->setObjectName(QStringLiteral("label_88"));

        gridLayout_14->addWidget(label_88, 1, 0, 1, 1);

        label_89 = new QLabel(groupCheck_glow_enabled);
        label_89->setObjectName(QStringLiteral("label_89"));

        gridLayout_14->addWidget(label_89, 2, 0, 1, 1);

        colorButton_glow_color_2 = new MyColorButton(groupCheck_glow_enabled);
        colorButton_glow_color_2->setObjectName(QStringLiteral("colorButton_glow_color_2"));

        gridLayout_14->addWidget(colorButton_glow_color_2, 2, 1, 1, 1);

        logslider_glow_intensity = new QSlider(groupCheck_glow_enabled);
        logslider_glow_intensity->setObjectName(QStringLiteral("logslider_glow_intensity"));
        logslider_glow_intensity->setMinimum(-500);
        logslider_glow_intensity->setMaximum(500);
        logslider_glow_intensity->setOrientation(Qt::Horizontal);

        gridLayout_14->addWidget(logslider_glow_intensity, 0, 1, 1, 1);

        colorButton_glow_color_1 = new MyColorButton(groupCheck_glow_enabled);
        colorButton_glow_color_1->setObjectName(QStringLiteral("colorButton_glow_color_1"));

        gridLayout_14->addWidget(colorButton_glow_color_1, 1, 1, 1, 1);

        label_87 = new QLabel(groupCheck_glow_enabled);
        label_87->setObjectName(QStringLiteral("label_87"));

        gridLayout_14->addWidget(label_87, 0, 0, 1, 1);

        logedit_glow_intensity = new MyLineEdit(groupCheck_glow_enabled);
        logedit_glow_intensity->setObjectName(QStringLiteral("logedit_glow_intensity"));

        gridLayout_14->addWidget(logedit_glow_intensity, 0, 2, 1, 1);


        verticalLayout_28->addLayout(gridLayout_14);


        verticalLayout_35->addWidget(groupCheck_glow_enabled);

        groupCheck_volumetric_fog_enabled = new MyGroupBox(scrollAreaWidgetContents_9);
        groupCheck_volumetric_fog_enabled->setObjectName(QStringLiteral("groupCheck_volumetric_fog_enabled"));
        groupCheck_volumetric_fog_enabled->setCheckable(true);
        verticalLayout_33 = new QVBoxLayout(groupCheck_volumetric_fog_enabled);
        verticalLayout_33->setSpacing(2);
        verticalLayout_33->setContentsMargins(2, 2, 2, 2);
        verticalLayout_33->setObjectName(QStringLiteral("verticalLayout_33"));
        verticalLayout_33->setContentsMargins(2, 2, 2, 2);
        gridLayout_13 = new QGridLayout();
        gridLayout_13->setSpacing(2);
        gridLayout_13->setObjectName(QStringLiteral("gridLayout_13"));
        logedit_volumetric_fog_density = new MyLineEdit(groupCheck_volumetric_fog_enabled);
        logedit_volumetric_fog_density->setObjectName(QStringLiteral("logedit_volumetric_fog_density"));

        gridLayout_13->addWidget(logedit_volumetric_fog_density, 1, 2, 1, 1);

        label_77 = new QLabel(groupCheck_volumetric_fog_enabled);
        label_77->setObjectName(QStringLiteral("label_77"));

        gridLayout_13->addWidget(label_77, 4, 0, 1, 1);

        label_76 = new QLabel(groupCheck_volumetric_fog_enabled);
        label_76->setObjectName(QStringLiteral("label_76"));

        gridLayout_13->addWidget(label_76, 3, 0, 1, 1);

        label_67 = new QLabel(groupCheck_volumetric_fog_enabled);
        label_67->setObjectName(QStringLiteral("label_67"));

        gridLayout_13->addWidget(label_67, 2, 0, 1, 1);

        logslider_volumetric_fog_colour_2_distance = new QSlider(groupCheck_volumetric_fog_enabled);
        logslider_volumetric_fog_colour_2_distance->setObjectName(QStringLiteral("logslider_volumetric_fog_colour_2_distance"));
        logslider_volumetric_fog_colour_2_distance->setMinimum(-1000);
        logslider_volumetric_fog_colour_2_distance->setMaximum(500);
        logslider_volumetric_fog_colour_2_distance->setOrientation(Qt::Horizontal);

        gridLayout_13->addWidget(logslider_volumetric_fog_colour_2_distance, 3, 1, 1, 1);

        logedit_volumetric_fog_colour_2_distance = new MyLineEdit(groupCheck_volumetric_fog_enabled);
        logedit_volumetric_fog_colour_2_distance->setObjectName(QStringLiteral("logedit_volumetric_fog_colour_2_distance"));

        gridLayout_13->addWidget(logedit_volumetric_fog_colour_2_distance, 3, 2, 1, 1);

        colorButton_fog_color_1 = new MyColorButton(groupCheck_volumetric_fog_enabled);
        colorButton_fog_color_1->setObjectName(QStringLiteral("colorButton_fog_color_1"));

        gridLayout_13->addWidget(colorButton_fog_color_1, 5, 1, 1, 1);

        logslider_volumetric_fog_distance_factor = new QSlider(groupCheck_volumetric_fog_enabled);
        logslider_volumetric_fog_distance_factor->setObjectName(QStringLiteral("logslider_volumetric_fog_distance_factor"));
        logslider_volumetric_fog_distance_factor->setMinimum(-1000);
        logslider_volumetric_fog_distance_factor->setMaximum(500);
        logslider_volumetric_fog_distance_factor->setOrientation(Qt::Horizontal);

        gridLayout_13->addWidget(logslider_volumetric_fog_distance_factor, 4, 1, 1, 1);

        logedit_volumetric_fog_colour_1_distance = new MyLineEdit(groupCheck_volumetric_fog_enabled);
        logedit_volumetric_fog_colour_1_distance->setObjectName(QStringLiteral("logedit_volumetric_fog_colour_1_distance"));

        gridLayout_13->addWidget(logedit_volumetric_fog_colour_1_distance, 2, 2, 1, 1);

        logslider_volumetric_fog_colour_1_distance = new QSlider(groupCheck_volumetric_fog_enabled);
        logslider_volumetric_fog_colour_1_distance->setObjectName(QStringLiteral("logslider_volumetric_fog_colour_1_distance"));
        logslider_volumetric_fog_colour_1_distance->setMinimum(-1000);
        logslider_volumetric_fog_colour_1_distance->setMaximum(500);
        logslider_volumetric_fog_colour_1_distance->setOrientation(Qt::Horizontal);

        gridLayout_13->addWidget(logslider_volumetric_fog_colour_1_distance, 2, 1, 1, 1);

        label_65 = new QLabel(groupCheck_volumetric_fog_enabled);
        label_65->setObjectName(QStringLiteral("label_65"));

        gridLayout_13->addWidget(label_65, 1, 0, 1, 1);

        label_78 = new QLabel(groupCheck_volumetric_fog_enabled);
        label_78->setObjectName(QStringLiteral("label_78"));

        gridLayout_13->addWidget(label_78, 6, 0, 1, 1);

        colorButton_fog_color_2 = new MyColorButton(groupCheck_volumetric_fog_enabled);
        colorButton_fog_color_2->setObjectName(QStringLiteral("colorButton_fog_color_2"));

        gridLayout_13->addWidget(colorButton_fog_color_2, 6, 1, 1, 1);

        label_79 = new QLabel(groupCheck_volumetric_fog_enabled);
        label_79->setObjectName(QStringLiteral("label_79"));

        gridLayout_13->addWidget(label_79, 7, 0, 1, 1);

        colorButton_fog_color_3 = new MyColorButton(groupCheck_volumetric_fog_enabled);
        colorButton_fog_color_3->setObjectName(QStringLiteral("colorButton_fog_color_3"));

        gridLayout_13->addWidget(colorButton_fog_color_3, 7, 1, 1, 1);

        logedit_volumetric_fog_distance_factor = new MyLineEdit(groupCheck_volumetric_fog_enabled);
        logedit_volumetric_fog_distance_factor->setObjectName(QStringLiteral("logedit_volumetric_fog_distance_factor"));

        gridLayout_13->addWidget(logedit_volumetric_fog_distance_factor, 4, 2, 1, 1);

        logslider_volumetric_fog_density = new QSlider(groupCheck_volumetric_fog_enabled);
        logslider_volumetric_fog_density->setObjectName(QStringLiteral("logslider_volumetric_fog_density"));
        logslider_volumetric_fog_density->setMinimum(-1000);
        logslider_volumetric_fog_density->setMaximum(500);
        logslider_volumetric_fog_density->setOrientation(Qt::Horizontal);

        gridLayout_13->addWidget(logslider_volumetric_fog_density, 1, 1, 1, 1);

        button_calculateFog = new QPushButton(groupCheck_volumetric_fog_enabled);
        button_calculateFog->setObjectName(QStringLiteral("button_calculateFog"));

        gridLayout_13->addWidget(button_calculateFog, 0, 0, 1, 3);

        label_66 = new QLabel(groupCheck_volumetric_fog_enabled);
        label_66->setObjectName(QStringLiteral("label_66"));

        gridLayout_13->addWidget(label_66, 5, 0, 1, 1);


        verticalLayout_33->addLayout(gridLayout_13);


        verticalLayout_35->addWidget(groupCheck_volumetric_fog_enabled);

        groupCheck_iteration_fog_enable = new MyGroupBox(scrollAreaWidgetContents_9);
        groupCheck_iteration_fog_enable->setObjectName(QStringLiteral("groupCheck_iteration_fog_enable"));
        groupCheck_iteration_fog_enable->setCheckable(true);
        verticalLayout_27 = new QVBoxLayout(groupCheck_iteration_fog_enable);
        verticalLayout_27->setSpacing(2);
        verticalLayout_27->setContentsMargins(2, 2, 2, 2);
        verticalLayout_27->setObjectName(QStringLiteral("verticalLayout_27"));
        verticalLayout_27->setContentsMargins(2, 2, 2, 2);
        gridLayout_8 = new QGridLayout();
        gridLayout_8->setSpacing(2);
        gridLayout_8->setObjectName(QStringLiteral("gridLayout_8"));
        colorButton_iteration_fog_color_1 = new MyColorButton(groupCheck_iteration_fog_enable);
        colorButton_iteration_fog_color_1->setObjectName(QStringLiteral("colorButton_iteration_fog_color_1"));

        gridLayout_8->addWidget(colorButton_iteration_fog_color_1, 4, 1, 1, 1);

        spinbox_iteration_fog_opacity_trim = new MyDoubleSpinBox(groupCheck_iteration_fog_enable);
        spinbox_iteration_fog_opacity_trim->setObjectName(QStringLiteral("spinbox_iteration_fog_opacity_trim"));
        spinbox_iteration_fog_opacity_trim->setDecimals(2);
        spinbox_iteration_fog_opacity_trim->setMaximum(1000);
        spinbox_iteration_fog_opacity_trim->setSingleStep(1);

        gridLayout_8->addWidget(spinbox_iteration_fog_opacity_trim, 1, 2, 1, 1);

        label_85 = new QLabel(groupCheck_iteration_fog_enable);
        label_85->setObjectName(QStringLiteral("label_85"));

        gridLayout_8->addWidget(label_85, 5, 0, 1, 1);

        spinbox_iteration_fog_color_1_maxiter = new MyDoubleSpinBox(groupCheck_iteration_fog_enable);
        spinbox_iteration_fog_color_1_maxiter->setObjectName(QStringLiteral("spinbox_iteration_fog_color_1_maxiter"));
        spinbox_iteration_fog_color_1_maxiter->setDecimals(2);
        spinbox_iteration_fog_color_1_maxiter->setMaximum(1000);
        spinbox_iteration_fog_color_1_maxiter->setSingleStep(1);

        gridLayout_8->addWidget(spinbox_iteration_fog_color_1_maxiter, 2, 2, 1, 1);

        logedit_iteration_fog_opacity = new MyLineEdit(groupCheck_iteration_fog_enable);
        logedit_iteration_fog_opacity->setObjectName(QStringLiteral("logedit_iteration_fog_opacity"));

        gridLayout_8->addWidget(logedit_iteration_fog_opacity, 0, 2, 1, 1);

        colorButton_iteration_fog_color_3 = new MyColorButton(groupCheck_iteration_fog_enable);
        colorButton_iteration_fog_color_3->setObjectName(QStringLiteral("colorButton_iteration_fog_color_3"));

        gridLayout_8->addWidget(colorButton_iteration_fog_color_3, 6, 1, 1, 1);

        slider_iteration_fog_color_2_maxiter = new QSlider(groupCheck_iteration_fog_enable);
        slider_iteration_fog_color_2_maxiter->setObjectName(QStringLiteral("slider_iteration_fog_color_2_maxiter"));
        slider_iteration_fog_color_2_maxiter->setMaximum(5000);
        slider_iteration_fog_color_2_maxiter->setSingleStep(1);
        slider_iteration_fog_color_2_maxiter->setOrientation(Qt::Horizontal);

        gridLayout_8->addWidget(slider_iteration_fog_color_2_maxiter, 3, 1, 1, 1);

        slider_iteration_fog_opacity_trim = new QSlider(groupCheck_iteration_fog_enable);
        slider_iteration_fog_opacity_trim->setObjectName(QStringLiteral("slider_iteration_fog_opacity_trim"));
        slider_iteration_fog_opacity_trim->setMaximum(5000);
        slider_iteration_fog_opacity_trim->setSingleStep(1);
        slider_iteration_fog_opacity_trim->setOrientation(Qt::Horizontal);

        gridLayout_8->addWidget(slider_iteration_fog_opacity_trim, 1, 1, 1, 1);

        slider_iteration_fog_color_1_maxiter = new QSlider(groupCheck_iteration_fog_enable);
        slider_iteration_fog_color_1_maxiter->setObjectName(QStringLiteral("slider_iteration_fog_color_1_maxiter"));
        slider_iteration_fog_color_1_maxiter->setMaximum(5000);
        slider_iteration_fog_color_1_maxiter->setSingleStep(1);
        slider_iteration_fog_color_1_maxiter->setOrientation(Qt::Horizontal);

        gridLayout_8->addWidget(slider_iteration_fog_color_1_maxiter, 2, 1, 1, 1);

        colorButton_iteration_fog_color_2 = new MyColorButton(groupCheck_iteration_fog_enable);
        colorButton_iteration_fog_color_2->setObjectName(QStringLiteral("colorButton_iteration_fog_color_2"));

        gridLayout_8->addWidget(colorButton_iteration_fog_color_2, 5, 1, 1, 1);

        label_84 = new QLabel(groupCheck_iteration_fog_enable);
        label_84->setObjectName(QStringLiteral("label_84"));

        gridLayout_8->addWidget(label_84, 4, 0, 1, 1);

        logslider_iteration_fog_opacity = new QSlider(groupCheck_iteration_fog_enable);
        logslider_iteration_fog_opacity->setObjectName(QStringLiteral("logslider_iteration_fog_opacity"));
        logslider_iteration_fog_opacity->setMinimum(-1000);
        logslider_iteration_fog_opacity->setMaximum(1000);
        logslider_iteration_fog_opacity->setOrientation(Qt::Horizontal);

        gridLayout_8->addWidget(logslider_iteration_fog_opacity, 0, 1, 1, 1);

        spinbox_iteration_fog_color_2_maxiter = new MyDoubleSpinBox(groupCheck_iteration_fog_enable);
        spinbox_iteration_fog_color_2_maxiter->setObjectName(QStringLiteral("spinbox_iteration_fog_color_2_maxiter"));
        spinbox_iteration_fog_color_2_maxiter->setDecimals(2);
        spinbox_iteration_fog_color_2_maxiter->setMaximum(1000);
        spinbox_iteration_fog_color_2_maxiter->setSingleStep(1);

        gridLayout_8->addWidget(spinbox_iteration_fog_color_2_maxiter, 3, 2, 1, 1);

        label_80 = new QLabel(groupCheck_iteration_fog_enable);
        label_80->setObjectName(QStringLiteral("label_80"));

        gridLayout_8->addWidget(label_80, 0, 0, 1, 1);

        label_86 = new QLabel(groupCheck_iteration_fog_enable);
        label_86->setObjectName(QStringLiteral("label_86"));

        gridLayout_8->addWidget(label_86, 6, 0, 1, 1);

        label_81 = new QLabel(groupCheck_iteration_fog_enable);
        label_81->setObjectName(QStringLiteral("label_81"));

        gridLayout_8->addWidget(label_81, 1, 0, 1, 1);

        label_83 = new QLabel(groupCheck_iteration_fog_enable);
        label_83->setObjectName(QStringLiteral("label_83"));

        gridLayout_8->addWidget(label_83, 3, 0, 1, 1);

        label_82 = new QLabel(groupCheck_iteration_fog_enable);
        label_82->setObjectName(QStringLiteral("label_82"));

        gridLayout_8->addWidget(label_82, 2, 0, 1, 1);


        verticalLayout_27->addLayout(gridLayout_8);


        verticalLayout_35->addWidget(groupCheck_iteration_fog_enable);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_35->addItem(verticalSpacer_4);

        scrollArea_8->setWidget(scrollAreaWidgetContents_9);

        verticalLayout_65->addWidget(scrollArea_8);

        tabWidget_2->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        verticalLayout_66 = new QVBoxLayout(tab_4);
        verticalLayout_66->setSpacing(2);
        verticalLayout_66->setContentsMargins(2, 2, 2, 2);
        verticalLayout_66->setObjectName(QStringLiteral("verticalLayout_66"));
        verticalLayout_66->setContentsMargins(2, 2, 2, 2);
        scrollArea_9 = new QScrollArea(tab_4);
        scrollArea_9->setObjectName(QStringLiteral("scrollArea_9"));
        scrollArea_9->setWidgetResizable(true);
        scrollAreaWidgetContents_10 = new QWidget();
        scrollAreaWidgetContents_10->setObjectName(QStringLiteral("scrollAreaWidgetContents_10"));
        scrollAreaWidgetContents_10->setGeometry(QRect(0, 0, 289, 204));
        verticalLayout_36 = new QVBoxLayout(scrollAreaWidgetContents_10);
        verticalLayout_36->setSpacing(2);
        verticalLayout_36->setContentsMargins(2, 2, 2, 2);
        verticalLayout_36->setObjectName(QStringLiteral("verticalLayout_36"));
        verticalLayout_36->setContentsMargins(2, 2, 2, 2);
        groupBox_14 = new QGroupBox(scrollAreaWidgetContents_10);
        groupBox_14->setObjectName(QStringLiteral("groupBox_14"));
        verticalLayout_37 = new QVBoxLayout(groupBox_14);
        verticalLayout_37->setSpacing(2);
        verticalLayout_37->setContentsMargins(2, 2, 2, 2);
        verticalLayout_37->setObjectName(QStringLiteral("verticalLayout_37"));
        verticalLayout_37->setContentsMargins(2, 2, 2, 2);
        gridLayout_15 = new QGridLayout();
        gridLayout_15->setSpacing(2);
        gridLayout_15->setObjectName(QStringLiteral("gridLayout_15"));
        colorButton_background_color_2 = new MyColorButton(groupBox_14);
        colorButton_background_color_2->setObjectName(QStringLiteral("colorButton_background_color_2"));

        gridLayout_15->addWidget(colorButton_background_color_2, 1, 1, 1, 1);

        label_58 = new QLabel(groupBox_14);
        label_58->setObjectName(QStringLiteral("label_58"));

        gridLayout_15->addWidget(label_58, 1, 0, 1, 1);

        label_57 = new QLabel(groupBox_14);
        label_57->setObjectName(QStringLiteral("label_57"));

        gridLayout_15->addWidget(label_57, 0, 0, 1, 1);

        colorButton_background_color_1 = new MyColorButton(groupBox_14);
        colorButton_background_color_1->setObjectName(QStringLiteral("colorButton_background_color_1"));

        gridLayout_15->addWidget(colorButton_background_color_1, 0, 1, 1, 1);

        label_59 = new QLabel(groupBox_14);
        label_59->setObjectName(QStringLiteral("label_59"));

        gridLayout_15->addWidget(label_59, 2, 0, 1, 1);

        colorButton_background_color_3 = new MyColorButton(groupBox_14);
        colorButton_background_color_3->setObjectName(QStringLiteral("colorButton_background_color_3"));

        gridLayout_15->addWidget(colorButton_background_color_3, 2, 1, 1, 1);


        verticalLayout_37->addLayout(gridLayout_15);


        verticalLayout_36->addWidget(groupBox_14);

        groupCheck_textured_background = new MyGroupBox(scrollAreaWidgetContents_10);
        groupCheck_textured_background->setObjectName(QStringLiteral("groupCheck_textured_background"));
        groupCheck_textured_background->setCheckable(true);
        verticalLayout_38 = new QVBoxLayout(groupCheck_textured_background);
        verticalLayout_38->setSpacing(2);
        verticalLayout_38->setContentsMargins(2, 2, 2, 2);
        verticalLayout_38->setObjectName(QStringLiteral("verticalLayout_38"));
        verticalLayout_38->setContentsMargins(2, 2, 2, 2);
        gridLayout_16 = new QGridLayout();
        gridLayout_16->setSpacing(2);
        gridLayout_16->setObjectName(QStringLiteral("gridLayout_16"));
        button_selectBackgroundTexture = new QPushButton(groupCheck_textured_background);
        button_selectBackgroundTexture->setObjectName(QStringLiteral("button_selectBackgroundTexture"));

        gridLayout_16->addWidget(button_selectBackgroundTexture, 0, 2, 1, 1);

        text_file_background = new MyLineEdit(groupCheck_textured_background);
        text_file_background->setObjectName(QStringLiteral("text_file_background"));

        gridLayout_16->addWidget(text_file_background, 0, 1, 1, 1);

        label_61 = new QLabel(groupCheck_textured_background);
        label_61->setObjectName(QStringLiteral("label_61"));

        gridLayout_16->addWidget(label_61, 0, 0, 1, 1);

        label_90 = new QLabel(groupCheck_textured_background);
        label_90->setObjectName(QStringLiteral("label_90"));

        gridLayout_16->addWidget(label_90, 1, 0, 1, 1);

        comboBox_textured_background_map_type = new QComboBox(groupCheck_textured_background);
        comboBox_textured_background_map_type->setObjectName(QStringLiteral("comboBox_textured_background_map_type"));

        gridLayout_16->addWidget(comboBox_textured_background_map_type, 1, 1, 1, 1);


        verticalLayout_38->addLayout(gridLayout_16);

        label_backgroundTextureView = new QLabel(groupCheck_textured_background);
        label_backgroundTextureView->setObjectName(QStringLiteral("label_backgroundTextureView"));
        label_backgroundTextureView->setMinimumSize(QSize(0, 50));

        verticalLayout_38->addWidget(label_backgroundTextureView);


        verticalLayout_36->addWidget(groupCheck_textured_background);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_36->addItem(verticalSpacer_5);

        scrollArea_9->setWidget(scrollAreaWidgetContents_10);

        verticalLayout_66->addWidget(scrollArea_9);

        tabWidget_2->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        verticalLayout_67 = new QVBoxLayout(tab_5);
        verticalLayout_67->setSpacing(2);
        verticalLayout_67->setContentsMargins(2, 2, 2, 2);
        verticalLayout_67->setObjectName(QStringLiteral("verticalLayout_67"));
        verticalLayout_67->setContentsMargins(2, 2, 2, 2);
        scrollArea_10 = new QScrollArea(tab_5);
        scrollArea_10->setObjectName(QStringLiteral("scrollArea_10"));
        scrollArea_10->setWidgetResizable(true);
        scrollAreaWidgetContents_11 = new QWidget();
        scrollAreaWidgetContents_11->setObjectName(QStringLiteral("scrollAreaWidgetContents_11"));
        scrollAreaWidgetContents_11->setGeometry(QRect(0, 0, 289, 1302));
        verticalLayout_41 = new QVBoxLayout(scrollAreaWidgetContents_11);
        verticalLayout_41->setSpacing(2);
        verticalLayout_41->setContentsMargins(2, 2, 2, 2);
        verticalLayout_41->setObjectName(QStringLiteral("verticalLayout_41"));
        verticalLayout_41->setContentsMargins(2, 2, 2, 2);
        groupBox_7 = new QGroupBox(scrollAreaWidgetContents_11);
        groupBox_7->setObjectName(QStringLiteral("groupBox_7"));
        verticalLayout_12 = new QVBoxLayout(groupBox_7);
        verticalLayout_12->setSpacing(2);
        verticalLayout_12->setContentsMargins(2, 2, 2, 2);
        verticalLayout_12->setObjectName(QStringLiteral("verticalLayout_12"));
        verticalLayout_12->setContentsMargins(2, 2, 2, 2);
        checkBox_shadows_enabled = new MyCheckBox(groupBox_7);
        checkBox_shadows_enabled->setObjectName(QStringLiteral("checkBox_shadows_enabled"));

        verticalLayout_12->addWidget(checkBox_shadows_enabled);

        checkBox_penetrating_lights = new MyCheckBox(groupBox_7);
        checkBox_penetrating_lights->setObjectName(QStringLiteral("checkBox_penetrating_lights"));

        verticalLayout_12->addWidget(checkBox_penetrating_lights);


        verticalLayout_41->addWidget(groupBox_7);

        groupCheck_main_light_enable = new MyGroupBox(scrollAreaWidgetContents_11);
        groupCheck_main_light_enable->setObjectName(QStringLiteral("groupCheck_main_light_enable"));
        groupCheck_main_light_enable->setCheckable(true);
        verticalLayout_8 = new QVBoxLayout(groupCheck_main_light_enable);
        verticalLayout_8->setSpacing(2);
        verticalLayout_8->setContentsMargins(2, 2, 2, 2);
        verticalLayout_8->setObjectName(QStringLiteral("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(2, 2, 2, 2);
        gridLayoutMainLightSource = new QGridLayout();
        gridLayoutMainLightSource->setSpacing(2);
        gridLayoutMainLightSource->setObjectName(QStringLiteral("gridLayoutMainLightSource"));
        slider_shadows_cone_angle = new QSlider(groupCheck_main_light_enable);
        slider_shadows_cone_angle->setObjectName(QStringLiteral("slider_shadows_cone_angle"));
        slider_shadows_cone_angle->setMaximum(4500);
        slider_shadows_cone_angle->setOrientation(Qt::Horizontal);

        gridLayoutMainLightSource->addWidget(slider_shadows_cone_angle, 6, 1, 1, 1);

        label_8 = new QLabel(groupCheck_main_light_enable);
        label_8->setObjectName(QStringLiteral("label_8"));

        gridLayoutMainLightSource->addWidget(label_8, 4, 0, 1, 1);

        label_2 = new QLabel(groupCheck_main_light_enable);
        label_2->setObjectName(QStringLiteral("label_2"));

        gridLayoutMainLightSource->addWidget(label_2, 0, 0, 1, 1);

        spinboxd_main_light_alpha = new MyDoubleSpinBox(groupCheck_main_light_enable);
        spinboxd_main_light_alpha->setObjectName(QStringLiteral("spinboxd_main_light_alpha"));
        spinboxd_main_light_alpha->setAccelerated(true);
        spinboxd_main_light_alpha->setDecimals(2);
        spinboxd_main_light_alpha->setMinimum(-180);
        spinboxd_main_light_alpha->setMaximum(180);
        spinboxd_main_light_alpha->setSingleStep(1);

        gridLayoutMainLightSource->addWidget(spinboxd_main_light_alpha, 4, 2, 1, 1);

        spinbox_main_light_visibility_size = new MyDoubleSpinBox(groupCheck_main_light_enable);
        spinbox_main_light_visibility_size->setObjectName(QStringLiteral("spinbox_main_light_visibility_size"));
        spinbox_main_light_visibility_size->setDecimals(2);
        spinbox_main_light_visibility_size->setMaximum(18000);
        spinbox_main_light_visibility_size->setSingleStep(0.1);

        gridLayoutMainLightSource->addWidget(spinbox_main_light_visibility_size, 2, 2, 1, 1);

        spinbox_main_light_intensity = new MyDoubleSpinBox(groupCheck_main_light_enable);
        spinbox_main_light_intensity->setObjectName(QStringLiteral("spinbox_main_light_intensity"));
        spinbox_main_light_intensity->setDecimals(2);
        spinbox_main_light_intensity->setMaximum(1000);
        spinbox_main_light_intensity->setSingleStep(0.1);

        gridLayoutMainLightSource->addWidget(spinbox_main_light_intensity, 0, 2, 1, 1);

        spinbox_main_light_visibility = new MyDoubleSpinBox(groupCheck_main_light_enable);
        spinbox_main_light_visibility->setObjectName(QStringLiteral("spinbox_main_light_visibility"));
        spinbox_main_light_visibility->setDecimals(2);
        spinbox_main_light_visibility->setMaximum(10000);
        spinbox_main_light_visibility->setSingleStep(0.1);

        gridLayoutMainLightSource->addWidget(spinbox_main_light_visibility, 1, 2, 1, 1);

        label_5 = new QLabel(groupCheck_main_light_enable);
        label_5->setObjectName(QStringLiteral("label_5"));

        gridLayoutMainLightSource->addWidget(label_5, 2, 0, 1, 1);

        spinbox_shadows_cone_angle = new MyDoubleSpinBox(groupCheck_main_light_enable);
        spinbox_shadows_cone_angle->setObjectName(QStringLiteral("spinbox_shadows_cone_angle"));
        spinbox_shadows_cone_angle->setFrame(true);
        spinbox_shadows_cone_angle->setAccelerated(true);
        spinbox_shadows_cone_angle->setDecimals(2);
        spinbox_shadows_cone_angle->setMinimum(-100000);
        spinbox_shadows_cone_angle->setMaximum(100000);
        spinbox_shadows_cone_angle->setSingleStep(1);

        gridLayoutMainLightSource->addWidget(spinbox_shadows_cone_angle, 6, 2, 1, 1);

        label_10 = new QLabel(groupCheck_main_light_enable);
        label_10->setObjectName(QStringLiteral("label_10"));

        gridLayoutMainLightSource->addWidget(label_10, 5, 0, 1, 1);

        slider_main_light_visibility_size = new QSlider(groupCheck_main_light_enable);
        slider_main_light_visibility_size->setObjectName(QStringLiteral("slider_main_light_visibility_size"));
        slider_main_light_visibility_size->setMaximum(5000);
        slider_main_light_visibility_size->setOrientation(Qt::Horizontal);

        gridLayoutMainLightSource->addWidget(slider_main_light_visibility_size, 2, 1, 1, 1);

        spinboxd_main_light_beta = new MyDoubleSpinBox(groupCheck_main_light_enable);
        spinboxd_main_light_beta->setObjectName(QStringLiteral("spinboxd_main_light_beta"));
        spinboxd_main_light_beta->setFrame(true);
        spinboxd_main_light_beta->setAccelerated(true);
        spinboxd_main_light_beta->setDecimals(2);
        spinboxd_main_light_beta->setMinimum(-100000);
        spinboxd_main_light_beta->setMaximum(100000);
        spinboxd_main_light_beta->setSingleStep(1);

        gridLayoutMainLightSource->addWidget(spinboxd_main_light_beta, 5, 2, 1, 1);

        label_30 = new QLabel(groupCheck_main_light_enable);
        label_30->setObjectName(QStringLiteral("label_30"));

        gridLayoutMainLightSource->addWidget(label_30, 6, 0, 1, 1);

        slider_main_light_visibility = new QSlider(groupCheck_main_light_enable);
        slider_main_light_visibility->setObjectName(QStringLiteral("slider_main_light_visibility"));
        slider_main_light_visibility->setMaximum(2000);
        slider_main_light_visibility->setOrientation(Qt::Horizontal);

        gridLayoutMainLightSource->addWidget(slider_main_light_visibility, 1, 1, 1, 1);

        label_6 = new QLabel(groupCheck_main_light_enable);
        label_6->setObjectName(QStringLiteral("label_6"));

        gridLayoutMainLightSource->addWidget(label_6, 1, 0, 1, 1);

        label_7 = new QLabel(groupCheck_main_light_enable);
        label_7->setObjectName(QStringLiteral("label_7"));

        gridLayoutMainLightSource->addWidget(label_7, 3, 0, 1, 1);

        slider_main_light_intensity = new QSlider(groupCheck_main_light_enable);
        slider_main_light_intensity->setObjectName(QStringLiteral("slider_main_light_intensity"));
        slider_main_light_intensity->setMaximum(200);
        slider_main_light_intensity->setSingleStep(1);
        slider_main_light_intensity->setOrientation(Qt::Horizontal);

        gridLayoutMainLightSource->addWidget(slider_main_light_intensity, 0, 1, 1, 1);

        colorButton_main_light_colour = new MyColorButton(groupCheck_main_light_enable);
        colorButton_main_light_colour->setObjectName(QStringLiteral("colorButton_main_light_colour"));

        gridLayoutMainLightSource->addWidget(colorButton_main_light_colour, 3, 1, 1, 1);

        dial_main_light_alpha = new QDial(groupCheck_main_light_enable);
        dial_main_light_alpha->setObjectName(QStringLiteral("dial_main_light_alpha"));
        dial_main_light_alpha->setMinimum(-18000);
        dial_main_light_alpha->setMaximum(18000);
        dial_main_light_alpha->setWrapping(true);

        gridLayoutMainLightSource->addWidget(dial_main_light_alpha, 4, 1, 1, 1);

        dial_main_light_beta = new QDial(groupCheck_main_light_enable);
        dial_main_light_beta->setObjectName(QStringLiteral("dial_main_light_beta"));
        dial_main_light_beta->setMinimum(-18000);
        dial_main_light_beta->setMaximum(18000);
        dial_main_light_beta->setWrapping(true);

        gridLayoutMainLightSource->addWidget(dial_main_light_beta, 5, 1, 1, 1);


        verticalLayout_8->addLayout(gridLayoutMainLightSource);

        checkBox_main_light_position_relative = new MyCheckBox(groupCheck_main_light_enable);
        checkBox_main_light_position_relative->setObjectName(QStringLiteral("checkBox_main_light_position_relative"));

        verticalLayout_8->addWidget(checkBox_main_light_position_relative);


        verticalLayout_41->addWidget(groupCheck_main_light_enable);

        groupBox_Lights = new QGroupBox(scrollAreaWidgetContents_11);
        groupBox_Lights->setObjectName(QStringLiteral("groupBox_Lights"));
        verticalLayout_9 = new QVBoxLayout(groupBox_Lights);
        verticalLayout_9->setSpacing(2);
        verticalLayout_9->setContentsMargins(2, 2, 2, 2);
        verticalLayout_9->setObjectName(QStringLiteral("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(2, 2, 2, 2);
        gridLayout_4 = new QGridLayout();
        gridLayout_4->setSpacing(2);
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        groupCheck_aux_light_enabled_1 = new MyGroupBox(groupBox_Lights);
        groupCheck_aux_light_enabled_1->setObjectName(QStringLiteral("groupCheck_aux_light_enabled_1"));
        groupCheck_aux_light_enabled_1->setCheckable(true);
        verticalLayout_10 = new QVBoxLayout(groupCheck_aux_light_enabled_1);
        verticalLayout_10->setSpacing(2);
        verticalLayout_10->setContentsMargins(2, 2, 2, 2);
        verticalLayout_10->setObjectName(QStringLiteral("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(2, 2, 2, 2);
        formLayout_coordinates_5 = new QFormLayout();
        formLayout_coordinates_5->setSpacing(2);
        formLayout_coordinates_5->setObjectName(QStringLiteral("formLayout_coordinates_5"));
        formLayout_coordinates_5->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_coordinates_5->setHorizontalSpacing(2);
        formLayout_coordinates_5->setVerticalSpacing(1);
        label_21 = new QLabel(groupCheck_aux_light_enabled_1);
        label_21->setObjectName(QStringLiteral("label_21"));

        formLayout_coordinates_5->setWidget(0, QFormLayout::LabelRole, label_21);

        vect3_aux_light_position_1_x = new MyLineEdit(groupCheck_aux_light_enabled_1);
        vect3_aux_light_position_1_x->setObjectName(QStringLiteral("vect3_aux_light_position_1_x"));

        formLayout_coordinates_5->setWidget(0, QFormLayout::FieldRole, vect3_aux_light_position_1_x);

        label_22 = new QLabel(groupCheck_aux_light_enabled_1);
        label_22->setObjectName(QStringLiteral("label_22"));

        formLayout_coordinates_5->setWidget(1, QFormLayout::LabelRole, label_22);

        vect3_aux_light_position_1_y = new MyLineEdit(groupCheck_aux_light_enabled_1);
        vect3_aux_light_position_1_y->setObjectName(QStringLiteral("vect3_aux_light_position_1_y"));

        formLayout_coordinates_5->setWidget(1, QFormLayout::FieldRole, vect3_aux_light_position_1_y);

        label_23 = new QLabel(groupCheck_aux_light_enabled_1);
        label_23->setObjectName(QStringLiteral("label_23"));

        formLayout_coordinates_5->setWidget(2, QFormLayout::LabelRole, label_23);

        vect3_aux_light_position_1_z = new MyLineEdit(groupCheck_aux_light_enabled_1);
        vect3_aux_light_position_1_z->setObjectName(QStringLiteral("vect3_aux_light_position_1_z"));

        formLayout_coordinates_5->setWidget(2, QFormLayout::FieldRole, vect3_aux_light_position_1_z);


        verticalLayout_10->addLayout(formLayout_coordinates_5);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(2);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        label_11 = new QLabel(groupCheck_aux_light_enabled_1);
        label_11->setObjectName(QStringLiteral("label_11"));

        horizontalLayout_3->addWidget(label_11);

        logedit_aux_light_intensity_1 = new MyLineEdit(groupCheck_aux_light_enabled_1);
        logedit_aux_light_intensity_1->setObjectName(QStringLiteral("logedit_aux_light_intensity_1"));

        horizontalLayout_3->addWidget(logedit_aux_light_intensity_1);


        verticalLayout_10->addLayout(horizontalLayout_3);

        logslider_aux_light_intensity_1 = new QSlider(groupCheck_aux_light_enabled_1);
        logslider_aux_light_intensity_1->setObjectName(QStringLiteral("logslider_aux_light_intensity_1"));
        logslider_aux_light_intensity_1->setMinimum(-1500);
        logslider_aux_light_intensity_1->setMaximum(1500);
        logslider_aux_light_intensity_1->setOrientation(Qt::Horizontal);

        verticalLayout_10->addWidget(logslider_aux_light_intensity_1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(2);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        label_12 = new QLabel(groupCheck_aux_light_enabled_1);
        label_12->setObjectName(QStringLiteral("label_12"));

        horizontalLayout_4->addWidget(label_12);

        colorButton_aux_light_colour_1 = new MyColorButton(groupCheck_aux_light_enabled_1);
        colorButton_aux_light_colour_1->setObjectName(QStringLiteral("colorButton_aux_light_colour_1"));

        horizontalLayout_4->addWidget(colorButton_aux_light_colour_1);


        verticalLayout_10->addLayout(horizontalLayout_4);

        pushButton_place_light_by_mouse_1 = new QPushButton(groupCheck_aux_light_enabled_1);
        pushButton_place_light_by_mouse_1->setObjectName(QStringLiteral("pushButton_place_light_by_mouse_1"));

        verticalLayout_10->addWidget(pushButton_place_light_by_mouse_1);


        gridLayout_4->addWidget(groupCheck_aux_light_enabled_1, 0, 0, 1, 1);

        groupCheck_aux_light_enabled_2 = new MyGroupBox(groupBox_Lights);
        groupCheck_aux_light_enabled_2->setObjectName(QStringLiteral("groupCheck_aux_light_enabled_2"));
        groupCheck_aux_light_enabled_2->setCheckable(true);
        verticalLayout_11 = new QVBoxLayout(groupCheck_aux_light_enabled_2);
        verticalLayout_11->setSpacing(2);
        verticalLayout_11->setContentsMargins(2, 2, 2, 2);
        verticalLayout_11->setObjectName(QStringLiteral("verticalLayout_11"));
        verticalLayout_11->setContentsMargins(2, 2, 2, 2);
        formLayout_coordinates_6 = new QFormLayout();
        formLayout_coordinates_6->setSpacing(2);
        formLayout_coordinates_6->setObjectName(QStringLiteral("formLayout_coordinates_6"));
        formLayout_coordinates_6->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_coordinates_6->setHorizontalSpacing(2);
        formLayout_coordinates_6->setVerticalSpacing(1);
        label_24 = new QLabel(groupCheck_aux_light_enabled_2);
        label_24->setObjectName(QStringLiteral("label_24"));

        formLayout_coordinates_6->setWidget(0, QFormLayout::LabelRole, label_24);

        vect3_aux_light_position_2_x = new MyLineEdit(groupCheck_aux_light_enabled_2);
        vect3_aux_light_position_2_x->setObjectName(QStringLiteral("vect3_aux_light_position_2_x"));

        formLayout_coordinates_6->setWidget(0, QFormLayout::FieldRole, vect3_aux_light_position_2_x);

        label_25 = new QLabel(groupCheck_aux_light_enabled_2);
        label_25->setObjectName(QStringLiteral("label_25"));

        formLayout_coordinates_6->setWidget(1, QFormLayout::LabelRole, label_25);

        vect3_aux_light_position_2_y = new MyLineEdit(groupCheck_aux_light_enabled_2);
        vect3_aux_light_position_2_y->setObjectName(QStringLiteral("vect3_aux_light_position_2_y"));

        formLayout_coordinates_6->setWidget(1, QFormLayout::FieldRole, vect3_aux_light_position_2_y);

        label_26 = new QLabel(groupCheck_aux_light_enabled_2);
        label_26->setObjectName(QStringLiteral("label_26"));

        formLayout_coordinates_6->setWidget(2, QFormLayout::LabelRole, label_26);

        vect3_aux_light_position_2_z = new MyLineEdit(groupCheck_aux_light_enabled_2);
        vect3_aux_light_position_2_z->setObjectName(QStringLiteral("vect3_aux_light_position_2_z"));

        formLayout_coordinates_6->setWidget(2, QFormLayout::FieldRole, vect3_aux_light_position_2_z);


        verticalLayout_11->addLayout(formLayout_coordinates_6);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(2);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        label_13 = new QLabel(groupCheck_aux_light_enabled_2);
        label_13->setObjectName(QStringLiteral("label_13"));

        horizontalLayout_5->addWidget(label_13);

        logedit_aux_light_intensity_2 = new MyLineEdit(groupCheck_aux_light_enabled_2);
        logedit_aux_light_intensity_2->setObjectName(QStringLiteral("logedit_aux_light_intensity_2"));

        horizontalLayout_5->addWidget(logedit_aux_light_intensity_2);


        verticalLayout_11->addLayout(horizontalLayout_5);

        logslider_aux_light_intensity_2 = new QSlider(groupCheck_aux_light_enabled_2);
        logslider_aux_light_intensity_2->setObjectName(QStringLiteral("logslider_aux_light_intensity_2"));
        logslider_aux_light_intensity_2->setMinimum(-1500);
        logslider_aux_light_intensity_2->setMaximum(1500);
        logslider_aux_light_intensity_2->setOrientation(Qt::Horizontal);

        verticalLayout_11->addWidget(logslider_aux_light_intensity_2);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(2);
        horizontalLayout_6->setObjectName(QStringLiteral("horizontalLayout_6"));
        label_14 = new QLabel(groupCheck_aux_light_enabled_2);
        label_14->setObjectName(QStringLiteral("label_14"));

        horizontalLayout_6->addWidget(label_14);

        colorButton_aux_light_colour_2 = new MyColorButton(groupCheck_aux_light_enabled_2);
        colorButton_aux_light_colour_2->setObjectName(QStringLiteral("colorButton_aux_light_colour_2"));

        horizontalLayout_6->addWidget(colorButton_aux_light_colour_2);


        verticalLayout_11->addLayout(horizontalLayout_6);

        pushButton_place_light_by_mouse_2 = new QPushButton(groupCheck_aux_light_enabled_2);
        pushButton_place_light_by_mouse_2->setObjectName(QStringLiteral("pushButton_place_light_by_mouse_2"));

        verticalLayout_11->addWidget(pushButton_place_light_by_mouse_2);


        gridLayout_4->addWidget(groupCheck_aux_light_enabled_2, 0, 1, 1, 1);

        groupCheck_aux_light_enabled_3 = new MyGroupBox(groupBox_Lights);
        groupCheck_aux_light_enabled_3->setObjectName(QStringLiteral("groupCheck_aux_light_enabled_3"));
        groupCheck_aux_light_enabled_3->setCheckable(true);
        verticalLayout_15 = new QVBoxLayout(groupCheck_aux_light_enabled_3);
        verticalLayout_15->setSpacing(2);
        verticalLayout_15->setContentsMargins(2, 2, 2, 2);
        verticalLayout_15->setObjectName(QStringLiteral("verticalLayout_15"));
        verticalLayout_15->setContentsMargins(2, 2, 2, 2);
        formLayout_coordinates_7 = new QFormLayout();
        formLayout_coordinates_7->setSpacing(2);
        formLayout_coordinates_7->setObjectName(QStringLiteral("formLayout_coordinates_7"));
        formLayout_coordinates_7->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_coordinates_7->setHorizontalSpacing(2);
        formLayout_coordinates_7->setVerticalSpacing(1);
        label_27 = new QLabel(groupCheck_aux_light_enabled_3);
        label_27->setObjectName(QStringLiteral("label_27"));

        formLayout_coordinates_7->setWidget(0, QFormLayout::LabelRole, label_27);

        vect3_aux_light_position_3_x = new MyLineEdit(groupCheck_aux_light_enabled_3);
        vect3_aux_light_position_3_x->setObjectName(QStringLiteral("vect3_aux_light_position_3_x"));

        formLayout_coordinates_7->setWidget(0, QFormLayout::FieldRole, vect3_aux_light_position_3_x);

        label_28 = new QLabel(groupCheck_aux_light_enabled_3);
        label_28->setObjectName(QStringLiteral("label_28"));

        formLayout_coordinates_7->setWidget(1, QFormLayout::LabelRole, label_28);

        vect3_aux_light_position_3_y = new MyLineEdit(groupCheck_aux_light_enabled_3);
        vect3_aux_light_position_3_y->setObjectName(QStringLiteral("vect3_aux_light_position_3_y"));

        formLayout_coordinates_7->setWidget(1, QFormLayout::FieldRole, vect3_aux_light_position_3_y);

        label_29 = new QLabel(groupCheck_aux_light_enabled_3);
        label_29->setObjectName(QStringLiteral("label_29"));

        formLayout_coordinates_7->setWidget(2, QFormLayout::LabelRole, label_29);

        vect3_aux_light_position_3_z = new MyLineEdit(groupCheck_aux_light_enabled_3);
        vect3_aux_light_position_3_z->setObjectName(QStringLiteral("vect3_aux_light_position_3_z"));

        formLayout_coordinates_7->setWidget(2, QFormLayout::FieldRole, vect3_aux_light_position_3_z);


        verticalLayout_15->addLayout(formLayout_coordinates_7);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setSpacing(2);
        horizontalLayout_7->setObjectName(QStringLiteral("horizontalLayout_7"));
        label_31 = new QLabel(groupCheck_aux_light_enabled_3);
        label_31->setObjectName(QStringLiteral("label_31"));

        horizontalLayout_7->addWidget(label_31);

        logedit_aux_light_intensity_3 = new MyLineEdit(groupCheck_aux_light_enabled_3);
        logedit_aux_light_intensity_3->setObjectName(QStringLiteral("logedit_aux_light_intensity_3"));

        horizontalLayout_7->addWidget(logedit_aux_light_intensity_3);


        verticalLayout_15->addLayout(horizontalLayout_7);

        logslider_aux_light_intensity_3 = new QSlider(groupCheck_aux_light_enabled_3);
        logslider_aux_light_intensity_3->setObjectName(QStringLiteral("logslider_aux_light_intensity_3"));
        logslider_aux_light_intensity_3->setMinimum(-1500);
        logslider_aux_light_intensity_3->setMaximum(1500);
        logslider_aux_light_intensity_3->setOrientation(Qt::Horizontal);

        verticalLayout_15->addWidget(logslider_aux_light_intensity_3);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(2);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        label_32 = new QLabel(groupCheck_aux_light_enabled_3);
        label_32->setObjectName(QStringLiteral("label_32"));

        horizontalLayout_8->addWidget(label_32);

        colorButton_aux_light_colour_3 = new MyColorButton(groupCheck_aux_light_enabled_3);
        colorButton_aux_light_colour_3->setObjectName(QStringLiteral("colorButton_aux_light_colour_3"));

        horizontalLayout_8->addWidget(colorButton_aux_light_colour_3);


        verticalLayout_15->addLayout(horizontalLayout_8);

        pushButton_place_light_by_mouse_3 = new QPushButton(groupCheck_aux_light_enabled_3);
        pushButton_place_light_by_mouse_3->setObjectName(QStringLiteral("pushButton_place_light_by_mouse_3"));

        verticalLayout_15->addWidget(pushButton_place_light_by_mouse_3);


        gridLayout_4->addWidget(groupCheck_aux_light_enabled_3, 1, 0, 1, 1);

        groupCheck_aux_light_enabled_4 = new MyGroupBox(groupBox_Lights);
        groupCheck_aux_light_enabled_4->setObjectName(QStringLiteral("groupCheck_aux_light_enabled_4"));
        groupCheck_aux_light_enabled_4->setCheckable(true);
        verticalLayout_16 = new QVBoxLayout(groupCheck_aux_light_enabled_4);
        verticalLayout_16->setSpacing(2);
        verticalLayout_16->setContentsMargins(2, 2, 2, 2);
        verticalLayout_16->setObjectName(QStringLiteral("verticalLayout_16"));
        verticalLayout_16->setContentsMargins(2, 2, 2, 2);
        formLayout_coordinates_8 = new QFormLayout();
        formLayout_coordinates_8->setSpacing(2);
        formLayout_coordinates_8->setObjectName(QStringLiteral("formLayout_coordinates_8"));
        formLayout_coordinates_8->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        formLayout_coordinates_8->setHorizontalSpacing(2);
        formLayout_coordinates_8->setVerticalSpacing(1);
        label_33 = new QLabel(groupCheck_aux_light_enabled_4);
        label_33->setObjectName(QStringLiteral("label_33"));

        formLayout_coordinates_8->setWidget(0, QFormLayout::LabelRole, label_33);

        vect3_aux_light_position_4_x = new MyLineEdit(groupCheck_aux_light_enabled_4);
        vect3_aux_light_position_4_x->setObjectName(QStringLiteral("vect3_aux_light_position_4_x"));

        formLayout_coordinates_8->setWidget(0, QFormLayout::FieldRole, vect3_aux_light_position_4_x);

        label_34 = new QLabel(groupCheck_aux_light_enabled_4);
        label_34->setObjectName(QStringLiteral("label_34"));

        formLayout_coordinates_8->setWidget(1, QFormLayout::LabelRole, label_34);

        vect3_aux_light_position_4_y = new MyLineEdit(groupCheck_aux_light_enabled_4);
        vect3_aux_light_position_4_y->setObjectName(QStringLiteral("vect3_aux_light_position_4_y"));

        formLayout_coordinates_8->setWidget(1, QFormLayout::FieldRole, vect3_aux_light_position_4_y);

        label_35 = new QLabel(groupCheck_aux_light_enabled_4);
        label_35->setObjectName(QStringLiteral("label_35"));

        formLayout_coordinates_8->setWidget(2, QFormLayout::LabelRole, label_35);

        vect3_aux_light_position_4_z = new MyLineEdit(groupCheck_aux_light_enabled_4);
        vect3_aux_light_position_4_z->setObjectName(QStringLiteral("vect3_aux_light_position_4_z"));

        formLayout_coordinates_8->setWidget(2, QFormLayout::FieldRole, vect3_aux_light_position_4_z);


        verticalLayout_16->addLayout(formLayout_coordinates_8);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(2);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        label_36 = new QLabel(groupCheck_aux_light_enabled_4);
        label_36->setObjectName(QStringLiteral("label_36"));

        horizontalLayout_9->addWidget(label_36);

        logedit_aux_light_intensity_4 = new MyLineEdit(groupCheck_aux_light_enabled_4);
        logedit_aux_light_intensity_4->setObjectName(QStringLiteral("logedit_aux_light_intensity_4"));

        horizontalLayout_9->addWidget(logedit_aux_light_intensity_4);


        verticalLayout_16->addLayout(horizontalLayout_9);

        logslider_aux_light_intensity_4 = new QSlider(groupCheck_aux_light_enabled_4);
        logslider_aux_light_intensity_4->setObjectName(QStringLiteral("logslider_aux_light_intensity_4"));
        logslider_aux_light_intensity_4->setMinimum(-1500);
        logslider_aux_light_intensity_4->setMaximum(1500);
        logslider_aux_light_intensity_4->setValue(0);
        logslider_aux_light_intensity_4->setOrientation(Qt::Horizontal);

        verticalLayout_16->addWidget(logslider_aux_light_intensity_4);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setSpacing(2);
        horizontalLayout_10->setObjectName(QStringLiteral("horizontalLayout_10"));
        label_37 = new QLabel(groupCheck_aux_light_enabled_4);
        label_37->setObjectName(QStringLiteral("label_37"));

        horizontalLayout_10->addWidget(label_37);

        colorButton_aux_light_colour_4 = new MyColorButton(groupCheck_aux_light_enabled_4);
        colorButton_aux_light_colour_4->setObjectName(QStringLiteral("colorButton_aux_light_colour_4"));

        horizontalLayout_10->addWidget(colorButton_aux_light_colour_4);


        verticalLayout_16->addLayout(horizontalLayout_10);

        pushButton_place_light_by_mouse_4 = new QPushButton(groupCheck_aux_light_enabled_4);
        pushButton_place_light_by_mouse_4->setObjectName(QStringLiteral("pushButton_place_light_by_mouse_4"));

        verticalLayout_16->addWidget(pushButton_place_light_by_mouse_4);


        gridLayout_4->addWidget(groupCheck_aux_light_enabled_4, 1, 1, 1, 1);


        verticalLayout_9->addLayout(gridLayout_4);

        groupBox_8 = new QGroupBox(groupBox_Lights);
        groupBox_8->setObjectName(QStringLiteral("groupBox_8"));
        verticalLayout_17 = new QVBoxLayout(groupBox_8);
        verticalLayout_17->setSpacing(2);
        verticalLayout_17->setContentsMargins(2, 2, 2, 2);
        verticalLayout_17->setObjectName(QStringLiteral("verticalLayout_17"));
        verticalLayout_17->setContentsMargins(2, 2, 2, 2);
        gridLayout_5 = new QGridLayout();
        gridLayout_5->setSpacing(2);
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        label_38 = new QLabel(groupBox_8);
        label_38->setObjectName(QStringLiteral("label_38"));

        gridLayout_5->addWidget(label_38, 2, 0, 1, 1);

        logslider_aux_light_visibility_size = new QSlider(groupBox_8);
        logslider_aux_light_visibility_size->setObjectName(QStringLiteral("logslider_aux_light_visibility_size"));
        logslider_aux_light_visibility_size->setMinimum(-1500);
        logslider_aux_light_visibility_size->setMaximum(300);
        logslider_aux_light_visibility_size->setOrientation(Qt::Horizontal);

        gridLayout_5->addWidget(logslider_aux_light_visibility_size, 2, 1, 1, 1);

        logslider_aux_light_visibility = new QSlider(groupBox_8);
        logslider_aux_light_visibility->setObjectName(QStringLiteral("logslider_aux_light_visibility"));
        logslider_aux_light_visibility->setMinimum(-1500);
        logslider_aux_light_visibility->setMaximum(1500);
        logslider_aux_light_visibility->setOrientation(Qt::Horizontal);

        gridLayout_5->addWidget(logslider_aux_light_visibility, 1, 1, 1, 1);

        logedit_aux_light_visibility = new MyLineEdit(groupBox_8);
        logedit_aux_light_visibility->setObjectName(QStringLiteral("logedit_aux_light_visibility"));

        gridLayout_5->addWidget(logedit_aux_light_visibility, 1, 2, 1, 1);

        logedit_aux_light_visibility_size = new MyLineEdit(groupBox_8);
        logedit_aux_light_visibility_size->setObjectName(QStringLiteral("logedit_aux_light_visibility_size"));

        gridLayout_5->addWidget(logedit_aux_light_visibility_size, 2, 2, 1, 1);

        label_39 = new QLabel(groupBox_8);
        label_39->setObjectName(QStringLiteral("label_39"));

        gridLayout_5->addWidget(label_39, 1, 0, 1, 1);

        label_134 = new QLabel(groupBox_8);
        label_134->setObjectName(QStringLiteral("label_134"));

        gridLayout_5->addWidget(label_134, 3, 0, 1, 1);

        logslider_aux_light_manual_placement_dist = new QSlider(groupBox_8);
        logslider_aux_light_manual_placement_dist->setObjectName(QStringLiteral("logslider_aux_light_manual_placement_dist"));
        logslider_aux_light_manual_placement_dist->setMinimum(-1500);
        logslider_aux_light_manual_placement_dist->setMaximum(300);
        logslider_aux_light_manual_placement_dist->setOrientation(Qt::Horizontal);

        gridLayout_5->addWidget(logslider_aux_light_manual_placement_dist, 3, 1, 1, 1);

        logedit_aux_light_manual_placement_dist = new MyLineEdit(groupBox_8);
        logedit_aux_light_manual_placement_dist->setObjectName(QStringLiteral("logedit_aux_light_manual_placement_dist"));

        gridLayout_5->addWidget(logedit_aux_light_manual_placement_dist, 3, 2, 1, 1);


        verticalLayout_17->addLayout(gridLayout_5);


        verticalLayout_9->addWidget(groupBox_8);


        verticalLayout_41->addWidget(groupBox_Lights);

        groupBox_9 = new QGroupBox(scrollAreaWidgetContents_11);
        groupBox_9->setObjectName(QStringLiteral("groupBox_9"));
        verticalLayout_18 = new QVBoxLayout(groupBox_9);
        verticalLayout_18->setSpacing(2);
        verticalLayout_18->setContentsMargins(2, 2, 2, 2);
        verticalLayout_18->setObjectName(QStringLiteral("verticalLayout_18"));
        verticalLayout_18->setContentsMargins(2, 2, 2, 2);
        gridLayout_6 = new QGridLayout();
        gridLayout_6->setSpacing(2);
        gridLayout_6->setObjectName(QStringLiteral("gridLayout_6"));
        logslider_aux_light_volumetric_intensity_1 = new QSlider(groupBox_9);
        logslider_aux_light_volumetric_intensity_1->setObjectName(QStringLiteral("logslider_aux_light_volumetric_intensity_1"));
        logslider_aux_light_volumetric_intensity_1->setMinimum(-1500);
        logslider_aux_light_volumetric_intensity_1->setMaximum(1500);
        logslider_aux_light_volumetric_intensity_1->setOrientation(Qt::Horizontal);

        gridLayout_6->addWidget(logslider_aux_light_volumetric_intensity_1, 3, 1, 1, 1);

        label_40 = new QLabel(groupBox_9);
        label_40->setObjectName(QStringLiteral("label_40"));

        gridLayout_6->addWidget(label_40, 5, 0, 1, 1);

        label_41 = new QLabel(groupBox_9);
        label_41->setObjectName(QStringLiteral("label_41"));

        gridLayout_6->addWidget(label_41, 3, 0, 1, 1);

        label_42 = new QLabel(groupBox_9);
        label_42->setObjectName(QStringLiteral("label_42"));

        gridLayout_6->addWidget(label_42, 1, 0, 1, 1);

        logedit_aux_light_volumetric_intensity_3 = new MyLineEdit(groupBox_9);
        logedit_aux_light_volumetric_intensity_3->setObjectName(QStringLiteral("logedit_aux_light_volumetric_intensity_3"));

        gridLayout_6->addWidget(logedit_aux_light_volumetric_intensity_3, 7, 2, 1, 1);

        logedit_aux_light_volumetric_intensity_2 = new MyLineEdit(groupBox_9);
        logedit_aux_light_volumetric_intensity_2->setObjectName(QStringLiteral("logedit_aux_light_volumetric_intensity_2"));

        gridLayout_6->addWidget(logedit_aux_light_volumetric_intensity_2, 5, 2, 1, 1);

        logslider_main_light_volumetric_intensity = new QSlider(groupBox_9);
        logslider_main_light_volumetric_intensity->setObjectName(QStringLiteral("logslider_main_light_volumetric_intensity"));
        logslider_main_light_volumetric_intensity->setMinimum(-1500);
        logslider_main_light_volumetric_intensity->setMaximum(1500);
        logslider_main_light_volumetric_intensity->setOrientation(Qt::Horizontal);

        gridLayout_6->addWidget(logslider_main_light_volumetric_intensity, 1, 1, 1, 1);

        logedit_main_light_volumetric_intensity = new MyLineEdit(groupBox_9);
        logedit_main_light_volumetric_intensity->setObjectName(QStringLiteral("logedit_main_light_volumetric_intensity"));

        gridLayout_6->addWidget(logedit_main_light_volumetric_intensity, 1, 2, 1, 1);

        logedit_aux_light_volumetric_intensity_1 = new MyLineEdit(groupBox_9);
        logedit_aux_light_volumetric_intensity_1->setObjectName(QStringLiteral("logedit_aux_light_volumetric_intensity_1"));

        gridLayout_6->addWidget(logedit_aux_light_volumetric_intensity_1, 3, 2, 1, 1);

        label_43 = new QLabel(groupBox_9);
        label_43->setObjectName(QStringLiteral("label_43"));

        gridLayout_6->addWidget(label_43, 7, 0, 1, 1);

        logslider_aux_light_volumetric_intensity_3 = new QSlider(groupBox_9);
        logslider_aux_light_volumetric_intensity_3->setObjectName(QStringLiteral("logslider_aux_light_volumetric_intensity_3"));
        logslider_aux_light_volumetric_intensity_3->setMinimum(-1500);
        logslider_aux_light_volumetric_intensity_3->setMaximum(1500);
        logslider_aux_light_volumetric_intensity_3->setOrientation(Qt::Horizontal);

        gridLayout_6->addWidget(logslider_aux_light_volumetric_intensity_3, 7, 1, 1, 1);

        label_44 = new QLabel(groupBox_9);
        label_44->setObjectName(QStringLiteral("label_44"));

        gridLayout_6->addWidget(label_44, 9, 0, 1, 1);

        logslider_aux_light_volumetric_intensity_4 = new QSlider(groupBox_9);
        logslider_aux_light_volumetric_intensity_4->setObjectName(QStringLiteral("logslider_aux_light_volumetric_intensity_4"));
        logslider_aux_light_volumetric_intensity_4->setMinimum(-1500);
        logslider_aux_light_volumetric_intensity_4->setMaximum(1500);
        logslider_aux_light_volumetric_intensity_4->setOrientation(Qt::Horizontal);

        gridLayout_6->addWidget(logslider_aux_light_volumetric_intensity_4, 9, 1, 1, 1);

        logedit_aux_light_volumetric_intensity_4 = new MyLineEdit(groupBox_9);
        logedit_aux_light_volumetric_intensity_4->setObjectName(QStringLiteral("logedit_aux_light_volumetric_intensity_4"));

        gridLayout_6->addWidget(logedit_aux_light_volumetric_intensity_4, 9, 2, 1, 1);

        logslider_aux_light_volumetric_intensity_2 = new QSlider(groupBox_9);
        logslider_aux_light_volumetric_intensity_2->setObjectName(QStringLiteral("logslider_aux_light_volumetric_intensity_2"));
        logslider_aux_light_volumetric_intensity_2->setMinimum(-1500);
        logslider_aux_light_volumetric_intensity_2->setMaximum(1500);
        logslider_aux_light_volumetric_intensity_2->setOrientation(Qt::Horizontal);

        gridLayout_6->addWidget(logslider_aux_light_volumetric_intensity_2, 5, 1, 1, 1);

        checkBox_main_light_volumetric_enabled = new MyCheckBox(groupBox_9);
        checkBox_main_light_volumetric_enabled->setObjectName(QStringLiteral("checkBox_main_light_volumetric_enabled"));

        gridLayout_6->addWidget(checkBox_main_light_volumetric_enabled, 0, 0, 1, 3);

        checkBox_aux_light_volumetric_enabled_1 = new QCheckBox(groupBox_9);
        checkBox_aux_light_volumetric_enabled_1->setObjectName(QStringLiteral("checkBox_aux_light_volumetric_enabled_1"));

        gridLayout_6->addWidget(checkBox_aux_light_volumetric_enabled_1, 2, 0, 1, 3);

        checkBox_aux_light_volumetric_enabled_2 = new QCheckBox(groupBox_9);
        checkBox_aux_light_volumetric_enabled_2->setObjectName(QStringLiteral("checkBox_aux_light_volumetric_enabled_2"));

        gridLayout_6->addWidget(checkBox_aux_light_volumetric_enabled_2, 4, 0, 1, 3);

        checkBox_aux_light_volumetric_enabled_3 = new QCheckBox(groupBox_9);
        checkBox_aux_light_volumetric_enabled_3->setObjectName(QStringLiteral("checkBox_aux_light_volumetric_enabled_3"));

        gridLayout_6->addWidget(checkBox_aux_light_volumetric_enabled_3, 6, 0, 1, 3);

        checkBox_aux_light_volumetric_enabled_4 = new QCheckBox(groupBox_9);
        checkBox_aux_light_volumetric_enabled_4->setObjectName(QStringLiteral("checkBox_aux_light_volumetric_enabled_4"));

        gridLayout_6->addWidget(checkBox_aux_light_volumetric_enabled_4, 8, 0, 1, 3);


        verticalLayout_18->addLayout(gridLayout_6);


        verticalLayout_41->addWidget(groupBox_9);

        groupCheck_fake_lights_enabled = new MyGroupBox(scrollAreaWidgetContents_11);
        groupCheck_fake_lights_enabled->setObjectName(QStringLiteral("groupCheck_fake_lights_enabled"));
        groupCheck_fake_lights_enabled->setCheckable(true);
        verticalLayout_39 = new QVBoxLayout(groupCheck_fake_lights_enabled);
        verticalLayout_39->setSpacing(2);
        verticalLayout_39->setContentsMargins(2, 2, 2, 2);
        verticalLayout_39->setObjectName(QStringLiteral("verticalLayout_39"));
        verticalLayout_39->setContentsMargins(2, 2, 2, 2);
        gridLayout_17 = new QGridLayout();
        gridLayout_17->setSpacing(2);
        gridLayout_17->setObjectName(QStringLiteral("gridLayout_17"));
        spinboxInt_fake_lights_min_iter = new MySpinBox(groupCheck_fake_lights_enabled);
        spinboxInt_fake_lights_min_iter->setObjectName(QStringLiteral("spinboxInt_fake_lights_min_iter"));
        spinboxInt_fake_lights_min_iter->setMaximum(500);

        gridLayout_17->addWidget(spinboxInt_fake_lights_min_iter, 0, 2, 1, 1);

        label_94 = new QLabel(groupCheck_fake_lights_enabled);
        label_94->setObjectName(QStringLiteral("label_94"));

        gridLayout_17->addWidget(label_94, 4, 0, 1, 1);

        spinboxInt_fake_lights_max_iter = new MySpinBox(groupCheck_fake_lights_enabled);
        spinboxInt_fake_lights_max_iter->setObjectName(QStringLiteral("spinboxInt_fake_lights_max_iter"));
        spinboxInt_fake_lights_max_iter->setMaximum(500);

        gridLayout_17->addWidget(spinboxInt_fake_lights_max_iter, 1, 2, 1, 1);

        logedit_fake_lights_intensity = new MyLineEdit(groupCheck_fake_lights_enabled);
        logedit_fake_lights_intensity->setObjectName(QStringLiteral("logedit_fake_lights_intensity"));

        gridLayout_17->addWidget(logedit_fake_lights_intensity, 2, 2, 1, 1);

        sliderInt_fake_lights_max_iter = new QSlider(groupCheck_fake_lights_enabled);
        sliderInt_fake_lights_max_iter->setObjectName(QStringLiteral("sliderInt_fake_lights_max_iter"));
        sliderInt_fake_lights_max_iter->setMaximum(50);
        sliderInt_fake_lights_max_iter->setSingleStep(1);
        sliderInt_fake_lights_max_iter->setPageStep(1);
        sliderInt_fake_lights_max_iter->setOrientation(Qt::Horizontal);

        gridLayout_17->addWidget(sliderInt_fake_lights_max_iter, 1, 1, 1, 1);

        logslider_fake_lights_intensity = new QSlider(groupCheck_fake_lights_enabled);
        logslider_fake_lights_intensity->setObjectName(QStringLiteral("logslider_fake_lights_intensity"));
        logslider_fake_lights_intensity->setMinimum(-1500);
        logslider_fake_lights_intensity->setMaximum(1500);
        logslider_fake_lights_intensity->setOrientation(Qt::Horizontal);

        gridLayout_17->addWidget(logslider_fake_lights_intensity, 2, 1, 1, 1);

        label_60 = new QLabel(groupCheck_fake_lights_enabled);
        label_60->setObjectName(QStringLiteral("label_60"));

        gridLayout_17->addWidget(label_60, 0, 0, 1, 1);

        logslider_fake_lights_visibility = new QSlider(groupCheck_fake_lights_enabled);
        logslider_fake_lights_visibility->setObjectName(QStringLiteral("logslider_fake_lights_visibility"));
        logslider_fake_lights_visibility->setMinimum(-1500);
        logslider_fake_lights_visibility->setMaximum(1500);
        logslider_fake_lights_visibility->setOrientation(Qt::Horizontal);

        gridLayout_17->addWidget(logslider_fake_lights_visibility, 3, 1, 1, 1);

        label_92 = new QLabel(groupCheck_fake_lights_enabled);
        label_92->setObjectName(QStringLiteral("label_92"));

        gridLayout_17->addWidget(label_92, 2, 0, 1, 1);

        spinbox_fake_lights_visibility_size = new MyDoubleSpinBox(groupCheck_fake_lights_enabled);
        spinbox_fake_lights_visibility_size->setObjectName(QStringLiteral("spinbox_fake_lights_visibility_size"));
        spinbox_fake_lights_visibility_size->setDecimals(2);
        spinbox_fake_lights_visibility_size->setMinimum(0.1);
        spinbox_fake_lights_visibility_size->setMaximum(10);
        spinbox_fake_lights_visibility_size->setSingleStep(0.5);

        gridLayout_17->addWidget(spinbox_fake_lights_visibility_size, 4, 2, 1, 1);

        logedit_fake_lights_visibility = new MyLineEdit(groupCheck_fake_lights_enabled);
        logedit_fake_lights_visibility->setObjectName(QStringLiteral("logedit_fake_lights_visibility"));

        gridLayout_17->addWidget(logedit_fake_lights_visibility, 3, 2, 1, 1);

        label_97 = new QLabel(groupCheck_fake_lights_enabled);
        label_97->setObjectName(QStringLiteral("label_97"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(label_97->sizePolicy().hasHeightForWidth());
        label_97->setSizePolicy(sizePolicy3);
        label_97->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_17->addWidget(label_97, 6, 1, 1, 1);

        label_91 = new QLabel(groupCheck_fake_lights_enabled);
        label_91->setObjectName(QStringLiteral("label_91"));

        gridLayout_17->addWidget(label_91, 1, 0, 1, 1);

        slider_fake_lights_visibility_size = new QSlider(groupCheck_fake_lights_enabled);
        slider_fake_lights_visibility_size->setObjectName(QStringLiteral("slider_fake_lights_visibility_size"));
        slider_fake_lights_visibility_size->setMinimum(10);
        slider_fake_lights_visibility_size->setMaximum(1000);
        slider_fake_lights_visibility_size->setOrientation(Qt::Horizontal);

        gridLayout_17->addWidget(slider_fake_lights_visibility_size, 4, 1, 1, 1);

        label_93 = new QLabel(groupCheck_fake_lights_enabled);
        label_93->setObjectName(QStringLiteral("label_93"));

        gridLayout_17->addWidget(label_93, 3, 0, 1, 1);

        sliderInt_fake_lights_min_iter = new QSlider(groupCheck_fake_lights_enabled);
        sliderInt_fake_lights_min_iter->setObjectName(QStringLiteral("sliderInt_fake_lights_min_iter"));
        sliderInt_fake_lights_min_iter->setMaximum(50);
        sliderInt_fake_lights_min_iter->setSingleStep(1);
        sliderInt_fake_lights_min_iter->setPageStep(1);
        sliderInt_fake_lights_min_iter->setOrientation(Qt::Horizontal);

        gridLayout_17->addWidget(sliderInt_fake_lights_min_iter, 0, 1, 1, 1);

        label_95 = new QLabel(groupCheck_fake_lights_enabled);
        label_95->setObjectName(QStringLiteral("label_95"));

        gridLayout_17->addWidget(label_95, 5, 0, 1, 1);

        label_96 = new QLabel(groupCheck_fake_lights_enabled);
        label_96->setObjectName(QStringLiteral("label_96"));
        sizePolicy3.setHeightForWidth(label_96->sizePolicy().hasHeightForWidth());
        label_96->setSizePolicy(sizePolicy3);
        label_96->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_17->addWidget(label_96, 5, 1, 1, 1);

        label_98 = new QLabel(groupCheck_fake_lights_enabled);
        label_98->setObjectName(QStringLiteral("label_98"));
        sizePolicy3.setHeightForWidth(label_98->sizePolicy().hasHeightForWidth());
        label_98->setSizePolicy(sizePolicy3);
        label_98->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_17->addWidget(label_98, 7, 1, 1, 1);

        vect3_fake_lights_orbit_trap_x = new MyLineEdit(groupCheck_fake_lights_enabled);
        vect3_fake_lights_orbit_trap_x->setObjectName(QStringLiteral("vect3_fake_lights_orbit_trap_x"));

        gridLayout_17->addWidget(vect3_fake_lights_orbit_trap_x, 5, 2, 1, 1);

        vect3_fake_lights_orbit_trap_y = new MyLineEdit(groupCheck_fake_lights_enabled);
        vect3_fake_lights_orbit_trap_y->setObjectName(QStringLiteral("vect3_fake_lights_orbit_trap_y"));

        gridLayout_17->addWidget(vect3_fake_lights_orbit_trap_y, 6, 2, 1, 1);

        vect3_fake_lights_orbit_trap_z = new MyLineEdit(groupCheck_fake_lights_enabled);
        vect3_fake_lights_orbit_trap_z->setObjectName(QStringLiteral("vect3_fake_lights_orbit_trap_z"));

        gridLayout_17->addWidget(vect3_fake_lights_orbit_trap_z, 7, 2, 1, 1);


        verticalLayout_39->addLayout(gridLayout_17);


        verticalLayout_41->addWidget(groupCheck_fake_lights_enabled);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_41->addItem(verticalSpacer_6);

        scrollArea_10->setWidget(scrollAreaWidgetContents_11);

        verticalLayout_67->addWidget(scrollArea_10);

        tabWidget_2->addTab(tab_5, QString());

        verticalLayout_26->addWidget(tabWidget_2);

        scrollArea_2->setWidget(scrollAreaWidgetContents_3);

        verticalLayout_6->addWidget(scrollArea_2);

        dockWidget_effects->setWidget(dockWidgetContents_3);
        RenderWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidget_effects);
        dockWidget_fractal = new QDockWidget(RenderWindow);
        dockWidget_fractal->setObjectName(QStringLiteral("dockWidget_fractal"));
        dockWidget_fractal->setFont(font2);
        dockWidget_fractal->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        dockWidgetContents_2 = new QWidget();
        dockWidgetContents_2->setObjectName(QStringLiteral("dockWidgetContents_2"));
        verticalLayout_7 = new QVBoxLayout(dockWidgetContents_2);
        verticalLayout_7->setSpacing(2);
        verticalLayout_7->setContentsMargins(2, 2, 2, 2);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(2, 2, 2, 2);
        scrollArea_5 = new QScrollArea(dockWidgetContents_2);
        scrollArea_5->setObjectName(QStringLiteral("scrollArea_5"));
        scrollArea_5->setWidgetResizable(true);
        scrollAreaWidgetContents_6 = new QWidget();
        scrollAreaWidgetContents_6->setObjectName(QStringLiteral("scrollAreaWidgetContents_6"));
        scrollAreaWidgetContents_6->setGeometry(QRect(0, 0, 339, 313));
        verticalLayout_59 = new QVBoxLayout(scrollAreaWidgetContents_6);
        verticalLayout_59->setSpacing(2);
        verticalLayout_59->setContentsMargins(2, 2, 2, 2);
        verticalLayout_59->setObjectName(QStringLiteral("verticalLayout_59"));
        verticalLayout_59->setContentsMargins(2, 2, 2, 2);
        tabWidget_fractal = new QTabWidget(scrollAreaWidgetContents_6);
        tabWidget_fractal->setObjectName(QStringLiteral("tabWidget_fractal"));
        tabWidget_fractal->setTabPosition(QTabWidget::West);
        tabWidget_fractal->setDocumentMode(false);
        tabWidget_fractal->setMovable(true);
        tabWidget_fractal_formulas = new QWidget();
        tabWidget_fractal_formulas->setObjectName(QStringLiteral("tabWidget_fractal_formulas"));
        verticalLayout_21 = new QVBoxLayout(tabWidget_fractal_formulas);
        verticalLayout_21->setSpacing(2);
        verticalLayout_21->setContentsMargins(2, 2, 2, 2);
        verticalLayout_21->setObjectName(QStringLiteral("verticalLayout_21"));
        verticalLayout_21->setContentsMargins(2, 2, 2, 2);
        tabWidget_fractals = new QTabWidget(tabWidget_fractal_formulas);
        tabWidget_fractals->setObjectName(QStringLiteral("tabWidget_fractals"));
        tab_fractal_formula_1 = new QWidget();
        tab_fractal_formula_1->setObjectName(QStringLiteral("tab_fractal_formula_1"));
        verticalLayout_49 = new QVBoxLayout(tab_fractal_formula_1);
        verticalLayout_49->setSpacing(2);
        verticalLayout_49->setContentsMargins(2, 2, 2, 2);
        verticalLayout_49->setObjectName(QStringLiteral("verticalLayout_49"));
        verticalLayout_49->setContentsMargins(2, 2, 2, 2);
        scrollArea_fractal_1 = new QScrollArea(tab_fractal_formula_1);
        scrollArea_fractal_1->setObjectName(QStringLiteral("scrollArea_fractal_1"));
        scrollArea_fractal_1->setWidgetResizable(true);
        scrollAreaWidgetContents_fractal_1 = new QWidget();
        scrollAreaWidgetContents_fractal_1->setObjectName(QStringLiteral("scrollAreaWidgetContents_fractal_1"));
        scrollAreaWidgetContents_fractal_1->setGeometry(QRect(0, 0, 281, 445));
        verticalLayoutScroll_fractal_1 = new QVBoxLayout(scrollAreaWidgetContents_fractal_1);
        verticalLayoutScroll_fractal_1->setSpacing(2);
        verticalLayoutScroll_fractal_1->setContentsMargins(2, 2, 2, 2);
        verticalLayoutScroll_fractal_1->setObjectName(QStringLiteral("verticalLayoutScroll_fractal_1"));
        verticalLayoutScroll_fractal_1->setContentsMargins(2, 2, 2, 2);
        frame_iterations_formula_1 = new QFrame(scrollAreaWidgetContents_fractal_1);
        frame_iterations_formula_1->setObjectName(QStringLiteral("frame_iterations_formula_1"));
        frame_iterations_formula_1->setFrameShape(QFrame::StyledPanel);
        frame_iterations_formula_1->setFrameShadow(QFrame::Raised);
        verticalLayout_56 = new QVBoxLayout(frame_iterations_formula_1);
        verticalLayout_56->setSpacing(2);
        verticalLayout_56->setContentsMargins(2, 2, 2, 2);
        verticalLayout_56->setObjectName(QStringLiteral("verticalLayout_56"));
        verticalLayout_56->setContentsMargins(2, 2, 2, 2);
        gridLayout_27 = new QGridLayout();
        gridLayout_27->setSpacing(2);
        gridLayout_27->setObjectName(QStringLiteral("gridLayout_27"));
        gridLayout_27->setContentsMargins(-1, 0, -1, -1);
        label_formula_iterations_1 = new QLabel(frame_iterations_formula_1);
        label_formula_iterations_1->setObjectName(QStringLiteral("label_formula_iterations_1"));

        gridLayout_27->addWidget(label_formula_iterations_1, 1, 0, 1, 1);

        sliderInt_formula_iterations_1 = new QSlider(frame_iterations_formula_1);
        sliderInt_formula_iterations_1->setObjectName(QStringLiteral("sliderInt_formula_iterations_1"));
        sliderInt_formula_iterations_1->setMinimum(1);
        sliderInt_formula_iterations_1->setMaximum(250);
        sliderInt_formula_iterations_1->setSingleStep(8);
        sliderInt_formula_iterations_1->setPageStep(64);
        sliderInt_formula_iterations_1->setOrientation(Qt::Horizontal);

        gridLayout_27->addWidget(sliderInt_formula_iterations_1, 1, 1, 1, 1);

        spinboxInt_formula_iterations_1 = new MySpinBox(frame_iterations_formula_1);
        spinboxInt_formula_iterations_1->setObjectName(QStringLiteral("spinboxInt_formula_iterations_1"));
        spinboxInt_formula_iterations_1->setMinimum(1);
        spinboxInt_formula_iterations_1->setMaximum(500);

        gridLayout_27->addWidget(spinboxInt_formula_iterations_1, 1, 2, 1, 1);

        comboBox_formula_1 = new QComboBox(frame_iterations_formula_1);
        comboBox_formula_1->setObjectName(QStringLiteral("comboBox_formula_1"));
        comboBox_formula_1->setMaxVisibleItems(50);

        gridLayout_27->addWidget(comboBox_formula_1, 0, 0, 1, 3);


        verticalLayout_56->addLayout(gridLayout_27);


        verticalLayoutScroll_fractal_1->addWidget(frame_iterations_formula_1);

        groupBox_formula_parameters_1 = new QGroupBox(scrollAreaWidgetContents_fractal_1);
        groupBox_formula_parameters_1->setObjectName(QStringLiteral("groupBox_formula_parameters_1"));
        verticalLayout_77 = new QVBoxLayout(groupBox_formula_parameters_1);
        verticalLayout_77->setSpacing(2);
        verticalLayout_77->setContentsMargins(2, 2, 2, 2);
        verticalLayout_77->setObjectName(QStringLiteral("verticalLayout_77"));
        verticalLayout_77->setContentsMargins(2, 2, 2, 2);
        verticalLayout_fractal_1 = new QVBoxLayout();
        verticalLayout_fractal_1->setSpacing(2);
        verticalLayout_fractal_1->setObjectName(QStringLiteral("verticalLayout_fractal_1"));

        verticalLayout_77->addLayout(verticalLayout_fractal_1);


        verticalLayoutScroll_fractal_1->addWidget(groupBox_formula_parameters_1);

        groupBox_formula_transform_1 = new QGroupBox(scrollAreaWidgetContents_fractal_1);
        groupBox_formula_transform_1->setObjectName(QStringLiteral("groupBox_formula_transform_1"));
        verticalLayout_22 = new QVBoxLayout(groupBox_formula_transform_1);
        verticalLayout_22->setSpacing(2);
        verticalLayout_22->setContentsMargins(2, 2, 2, 2);
        verticalLayout_22->setObjectName(QStringLiteral("verticalLayout_22"));
        verticalLayout_22->setContentsMargins(2, 2, 2, 2);
        gridLayout_41 = new QGridLayout();
        gridLayout_41->setSpacing(2);
        gridLayout_41->setObjectName(QStringLiteral("gridLayout_41"));
        label_158 = new QLabel(groupBox_formula_transform_1);
        label_158->setObjectName(QStringLiteral("label_158"));
        sizePolicy3.setHeightForWidth(label_158->sizePolicy().hasHeightForWidth());
        label_158->setSizePolicy(sizePolicy3);
        label_158->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_41->addWidget(label_158, 2, 1, 1, 1);

        vect3_formula_position_1_z = new MyLineEdit(groupBox_formula_transform_1);
        vect3_formula_position_1_z->setObjectName(QStringLiteral("vect3_formula_position_1_z"));

        gridLayout_41->addWidget(vect3_formula_position_1_z, 2, 2, 1, 1);

        dial3_formula_rotation_1_y = new QDial(groupBox_formula_transform_1);
        dial3_formula_rotation_1_y->setObjectName(QStringLiteral("dial3_formula_rotation_1_y"));
        dial3_formula_rotation_1_y->setMinimum(-18000);
        dial3_formula_rotation_1_y->setMaximum(18000);
        dial3_formula_rotation_1_y->setWrapping(true);

        gridLayout_41->addWidget(dial3_formula_rotation_1_y, 5, 1, 1, 1);

        label_163 = new QLabel(groupBox_formula_transform_1);
        label_163->setObjectName(QStringLiteral("label_163"));

        gridLayout_41->addWidget(label_163, 0, 0, 3, 1);

        label_157 = new QLabel(groupBox_formula_transform_1);
        label_157->setObjectName(QStringLiteral("label_157"));

        gridLayout_41->addWidget(label_157, 5, 0, 1, 1);

        label_159 = new QLabel(groupBox_formula_transform_1);
        label_159->setObjectName(QStringLiteral("label_159"));
        sizePolicy3.setHeightForWidth(label_159->sizePolicy().hasHeightForWidth());
        label_159->setSizePolicy(sizePolicy3);
        label_159->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_41->addWidget(label_159, 0, 1, 1, 1);

        vect3_formula_position_1_y = new MyLineEdit(groupBox_formula_transform_1);
        vect3_formula_position_1_y->setObjectName(QStringLiteral("vect3_formula_position_1_y"));

        gridLayout_41->addWidget(vect3_formula_position_1_y, 1, 2, 1, 1);

        spinboxd3_formula_rotation_1_z = new MyDoubleSpinBox(groupBox_formula_transform_1);
        spinboxd3_formula_rotation_1_z->setObjectName(QStringLiteral("spinboxd3_formula_rotation_1_z"));
        spinboxd3_formula_rotation_1_z->setDecimals(2);
        spinboxd3_formula_rotation_1_z->setMinimum(-36000);
        spinboxd3_formula_rotation_1_z->setMaximum(36000);
        spinboxd3_formula_rotation_1_z->setSingleStep(0.1);

        gridLayout_41->addWidget(spinboxd3_formula_rotation_1_z, 6, 2, 1, 1);

        spinboxd3_formula_rotation_1_y = new MyDoubleSpinBox(groupBox_formula_transform_1);
        spinboxd3_formula_rotation_1_y->setObjectName(QStringLiteral("spinboxd3_formula_rotation_1_y"));
        spinboxd3_formula_rotation_1_y->setDecimals(2);
        spinboxd3_formula_rotation_1_y->setMinimum(-36000);
        spinboxd3_formula_rotation_1_y->setMaximum(36000);
        spinboxd3_formula_rotation_1_y->setSingleStep(0.1);

        gridLayout_41->addWidget(spinboxd3_formula_rotation_1_y, 5, 2, 1, 1);

        label_167 = new QLabel(groupBox_formula_transform_1);
        label_167->setObjectName(QStringLiteral("label_167"));
        sizePolicy3.setHeightForWidth(label_167->sizePolicy().hasHeightForWidth());
        label_167->setSizePolicy(sizePolicy3);
        label_167->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_41->addWidget(label_167, 8, 1, 1, 1);

        spinboxd3_formula_rotation_1_x = new MyDoubleSpinBox(groupBox_formula_transform_1);
        spinboxd3_formula_rotation_1_x->setObjectName(QStringLiteral("spinboxd3_formula_rotation_1_x"));
        spinboxd3_formula_rotation_1_x->setDecimals(2);
        spinboxd3_formula_rotation_1_x->setMinimum(-36000);
        spinboxd3_formula_rotation_1_x->setMaximum(36000);
        spinboxd3_formula_rotation_1_x->setSingleStep(0.1);

        gridLayout_41->addWidget(spinboxd3_formula_rotation_1_x, 4, 2, 1, 1);

        vect3_formula_position_1_x = new MyLineEdit(groupBox_formula_transform_1);
        vect3_formula_position_1_x->setObjectName(QStringLiteral("vect3_formula_position_1_x"));

        gridLayout_41->addWidget(vect3_formula_position_1_x, 0, 2, 1, 1);

        dial3_formula_rotation_1_x = new QDial(groupBox_formula_transform_1);
        dial3_formula_rotation_1_x->setObjectName(QStringLiteral("dial3_formula_rotation_1_x"));
        dial3_formula_rotation_1_x->setMinimum(-18000);
        dial3_formula_rotation_1_x->setMaximum(18000);
        dial3_formula_rotation_1_x->setWrapping(true);

        gridLayout_41->addWidget(dial3_formula_rotation_1_x, 4, 1, 1, 1);

        vect3_formula_repeat_1_x = new MyLineEdit(groupBox_formula_transform_1);
        vect3_formula_repeat_1_x->setObjectName(QStringLiteral("vect3_formula_repeat_1_x"));

        gridLayout_41->addWidget(vect3_formula_repeat_1_x, 7, 2, 1, 1);

        dial3_formula_rotation_1_z = new QDial(groupBox_formula_transform_1);
        dial3_formula_rotation_1_z->setObjectName(QStringLiteral("dial3_formula_rotation_1_z"));
        dial3_formula_rotation_1_z->setMinimum(-18000);
        dial3_formula_rotation_1_z->setMaximum(18000);
        dial3_formula_rotation_1_z->setWrapping(true);

        gridLayout_41->addWidget(dial3_formula_rotation_1_z, 6, 1, 1, 1);

        label_160 = new QLabel(groupBox_formula_transform_1);
        label_160->setObjectName(QStringLiteral("label_160"));

        gridLayout_41->addWidget(label_160, 4, 0, 1, 1);

        label_162 = new QLabel(groupBox_formula_transform_1);
        label_162->setObjectName(QStringLiteral("label_162"));

        gridLayout_41->addWidget(label_162, 6, 0, 1, 1);

        label_161 = new QLabel(groupBox_formula_transform_1);
        label_161->setObjectName(QStringLiteral("label_161"));
        sizePolicy3.setHeightForWidth(label_161->sizePolicy().hasHeightForWidth());
        label_161->setSizePolicy(sizePolicy3);
        label_161->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_41->addWidget(label_161, 1, 1, 1, 1);

        vect3_formula_repeat_1_y = new MyLineEdit(groupBox_formula_transform_1);
        vect3_formula_repeat_1_y->setObjectName(QStringLiteral("vect3_formula_repeat_1_y"));

        gridLayout_41->addWidget(vect3_formula_repeat_1_y, 8, 2, 1, 1);

        label_165 = new QLabel(groupBox_formula_transform_1);
        label_165->setObjectName(QStringLiteral("label_165"));
        sizePolicy3.setHeightForWidth(label_165->sizePolicy().hasHeightForWidth());
        label_165->setSizePolicy(sizePolicy3);
        label_165->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_41->addWidget(label_165, 7, 1, 1, 1);

        vect3_formula_repeat_1_z = new MyLineEdit(groupBox_formula_transform_1);
        vect3_formula_repeat_1_z->setObjectName(QStringLiteral("vect3_formula_repeat_1_z"));

        gridLayout_41->addWidget(vect3_formula_repeat_1_z, 9, 2, 1, 1);

        label_166 = new QLabel(groupBox_formula_transform_1);
        label_166->setObjectName(QStringLiteral("label_166"));
        sizePolicy3.setHeightForWidth(label_166->sizePolicy().hasHeightForWidth());
        label_166->setSizePolicy(sizePolicy3);
        label_166->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_41->addWidget(label_166, 9, 1, 1, 1);

        label_164 = new QLabel(groupBox_formula_transform_1);
        label_164->setObjectName(QStringLiteral("label_164"));

        gridLayout_41->addWidget(label_164, 7, 0, 3, 1);

        label_168 = new QLabel(groupBox_formula_transform_1);
        label_168->setObjectName(QStringLiteral("label_168"));

        gridLayout_41->addWidget(label_168, 3, 0, 1, 1);

        logedit_formula_scale_1 = new MyLineEdit(groupBox_formula_transform_1);
        logedit_formula_scale_1->setObjectName(QStringLiteral("logedit_formula_scale_1"));
        sizePolicy1.setHeightForWidth(logedit_formula_scale_1->sizePolicy().hasHeightForWidth());
        logedit_formula_scale_1->setSizePolicy(sizePolicy1);

        gridLayout_41->addWidget(logedit_formula_scale_1, 3, 2, 1, 1);

        logslider_formula_scale_1 = new QSlider(groupBox_formula_transform_1);
        logslider_formula_scale_1->setObjectName(QStringLiteral("logslider_formula_scale_1"));
        sizePolicy1.setHeightForWidth(logslider_formula_scale_1->sizePolicy().hasHeightForWidth());
        logslider_formula_scale_1->setSizePolicy(sizePolicy1);
        logslider_formula_scale_1->setSizeIncrement(QSize(0, 0));
        logslider_formula_scale_1->setMinimum(-1000);
        logslider_formula_scale_1->setMaximum(300);
        logslider_formula_scale_1->setOrientation(Qt::Horizontal);

        gridLayout_41->addWidget(logslider_formula_scale_1, 3, 1, 1, 1);


        verticalLayout_22->addLayout(gridLayout_41);


        verticalLayoutScroll_fractal_1->addWidget(groupBox_formula_transform_1);

        verticalSpacer_12 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutScroll_fractal_1->addItem(verticalSpacer_12);

        scrollArea_fractal_1->setWidget(scrollAreaWidgetContents_fractal_1);

        verticalLayout_49->addWidget(scrollArea_fractal_1);

        tabWidget_fractals->addTab(tab_fractal_formula_1, QString());
        tab_fractal_formula_2 = new QWidget();
        tab_fractal_formula_2->setObjectName(QStringLiteral("tab_fractal_formula_2"));
        verticalLayout_50 = new QVBoxLayout(tab_fractal_formula_2);
        verticalLayout_50->setSpacing(2);
        verticalLayout_50->setContentsMargins(2, 2, 2, 2);
        verticalLayout_50->setObjectName(QStringLiteral("verticalLayout_50"));
        verticalLayout_50->setContentsMargins(2, 2, 2, 2);
        scrollArea_fractal_2 = new QScrollArea(tab_fractal_formula_2);
        scrollArea_fractal_2->setObjectName(QStringLiteral("scrollArea_fractal_2"));
        scrollArea_fractal_2->setWidgetResizable(true);
        scrollAreaWidgetContents_fractal_2 = new QWidget();
        scrollAreaWidgetContents_fractal_2->setObjectName(QStringLiteral("scrollAreaWidgetContents_fractal_2"));
        scrollAreaWidgetContents_fractal_2->setGeometry(QRect(0, 0, 281, 445));
        verticalLayoutScroll_fractal_3 = new QVBoxLayout(scrollAreaWidgetContents_fractal_2);
        verticalLayoutScroll_fractal_3->setSpacing(2);
        verticalLayoutScroll_fractal_3->setContentsMargins(2, 2, 2, 2);
        verticalLayoutScroll_fractal_3->setObjectName(QStringLiteral("verticalLayoutScroll_fractal_3"));
        verticalLayoutScroll_fractal_3->setContentsMargins(2, 2, 2, 2);
        frame_iterations_formula_2 = new QFrame(scrollAreaWidgetContents_fractal_2);
        frame_iterations_formula_2->setObjectName(QStringLiteral("frame_iterations_formula_2"));
        frame_iterations_formula_2->setFrameShape(QFrame::StyledPanel);
        frame_iterations_formula_2->setFrameShadow(QFrame::Raised);
        verticalLayout_83 = new QVBoxLayout(frame_iterations_formula_2);
        verticalLayout_83->setSpacing(2);
        verticalLayout_83->setContentsMargins(2, 2, 2, 2);
        verticalLayout_83->setObjectName(QStringLiteral("verticalLayout_83"));
        verticalLayout_83->setContentsMargins(2, 2, 2, 2);
        gridLayout_44 = new QGridLayout();
        gridLayout_44->setSpacing(2);
        gridLayout_44->setObjectName(QStringLiteral("gridLayout_44"));
        gridLayout_44->setContentsMargins(-1, 0, -1, -1);
        label_formula_iterations_2 = new QLabel(frame_iterations_formula_2);
        label_formula_iterations_2->setObjectName(QStringLiteral("label_formula_iterations_2"));

        gridLayout_44->addWidget(label_formula_iterations_2, 1, 0, 1, 1);

        sliderInt_formula_iterations_2 = new QSlider(frame_iterations_formula_2);
        sliderInt_formula_iterations_2->setObjectName(QStringLiteral("sliderInt_formula_iterations_2"));
        sliderInt_formula_iterations_2->setMinimum(1);
        sliderInt_formula_iterations_2->setMaximum(250);
        sliderInt_formula_iterations_2->setSingleStep(8);
        sliderInt_formula_iterations_2->setPageStep(64);
        sliderInt_formula_iterations_2->setOrientation(Qt::Horizontal);

        gridLayout_44->addWidget(sliderInt_formula_iterations_2, 1, 1, 1, 1);

        spinboxInt_formula_iterations_2 = new MySpinBox(frame_iterations_formula_2);
        spinboxInt_formula_iterations_2->setObjectName(QStringLiteral("spinboxInt_formula_iterations_2"));
        spinboxInt_formula_iterations_2->setMinimum(1);
        spinboxInt_formula_iterations_2->setMaximum(500);

        gridLayout_44->addWidget(spinboxInt_formula_iterations_2, 1, 2, 1, 1);

        comboBox_formula_2 = new QComboBox(frame_iterations_formula_2);
        comboBox_formula_2->setObjectName(QStringLiteral("comboBox_formula_2"));
        comboBox_formula_2->setMaxVisibleItems(50);

        gridLayout_44->addWidget(comboBox_formula_2, 0, 0, 1, 3);


        verticalLayout_83->addLayout(gridLayout_44);


        verticalLayoutScroll_fractal_3->addWidget(frame_iterations_formula_2);

        groupBox_formula_parameters_2 = new QGroupBox(scrollAreaWidgetContents_fractal_2);
        groupBox_formula_parameters_2->setObjectName(QStringLiteral("groupBox_formula_parameters_2"));
        verticalLayout_84 = new QVBoxLayout(groupBox_formula_parameters_2);
        verticalLayout_84->setSpacing(2);
        verticalLayout_84->setContentsMargins(2, 2, 2, 2);
        verticalLayout_84->setObjectName(QStringLiteral("verticalLayout_84"));
        verticalLayout_84->setContentsMargins(2, 2, 2, 2);
        verticalLayout_fractal_2 = new QVBoxLayout();
        verticalLayout_fractal_2->setSpacing(2);
        verticalLayout_fractal_2->setObjectName(QStringLiteral("verticalLayout_fractal_2"));

        verticalLayout_84->addLayout(verticalLayout_fractal_2);


        verticalLayoutScroll_fractal_3->addWidget(groupBox_formula_parameters_2);

        groupBox_formula_transform_2 = new QGroupBox(scrollAreaWidgetContents_fractal_2);
        groupBox_formula_transform_2->setObjectName(QStringLiteral("groupBox_formula_transform_2"));
        verticalLayout_85 = new QVBoxLayout(groupBox_formula_transform_2);
        verticalLayout_85->setSpacing(2);
        verticalLayout_85->setContentsMargins(2, 2, 2, 2);
        verticalLayout_85->setObjectName(QStringLiteral("verticalLayout_85"));
        verticalLayout_85->setContentsMargins(2, 2, 2, 2);
        gridLayout_45 = new QGridLayout();
        gridLayout_45->setSpacing(2);
        gridLayout_45->setObjectName(QStringLiteral("gridLayout_45"));
        label_179 = new QLabel(groupBox_formula_transform_2);
        label_179->setObjectName(QStringLiteral("label_179"));
        sizePolicy3.setHeightForWidth(label_179->sizePolicy().hasHeightForWidth());
        label_179->setSizePolicy(sizePolicy3);
        label_179->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_45->addWidget(label_179, 2, 1, 1, 1);

        vect3_formula_position_2_z = new MyLineEdit(groupBox_formula_transform_2);
        vect3_formula_position_2_z->setObjectName(QStringLiteral("vect3_formula_position_2_z"));

        gridLayout_45->addWidget(vect3_formula_position_2_z, 2, 2, 1, 1);

        dial3_formula_rotation_2_y = new QDial(groupBox_formula_transform_2);
        dial3_formula_rotation_2_y->setObjectName(QStringLiteral("dial3_formula_rotation_2_y"));
        dial3_formula_rotation_2_y->setMinimum(-18000);
        dial3_formula_rotation_2_y->setMaximum(18000);
        dial3_formula_rotation_2_y->setWrapping(true);

        gridLayout_45->addWidget(dial3_formula_rotation_2_y, 5, 1, 1, 1);

        label_180 = new QLabel(groupBox_formula_transform_2);
        label_180->setObjectName(QStringLiteral("label_180"));

        gridLayout_45->addWidget(label_180, 0, 0, 3, 1);

        label_181 = new QLabel(groupBox_formula_transform_2);
        label_181->setObjectName(QStringLiteral("label_181"));

        gridLayout_45->addWidget(label_181, 5, 0, 1, 1);

        label_182 = new QLabel(groupBox_formula_transform_2);
        label_182->setObjectName(QStringLiteral("label_182"));
        sizePolicy3.setHeightForWidth(label_182->sizePolicy().hasHeightForWidth());
        label_182->setSizePolicy(sizePolicy3);
        label_182->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_45->addWidget(label_182, 0, 1, 1, 1);

        spinboxd3_formula_rotation_2_z = new MyDoubleSpinBox(groupBox_formula_transform_2);
        spinboxd3_formula_rotation_2_z->setObjectName(QStringLiteral("spinboxd3_formula_rotation_2_z"));
        spinboxd3_formula_rotation_2_z->setDecimals(2);
        spinboxd3_formula_rotation_2_z->setMinimum(-36000);
        spinboxd3_formula_rotation_2_z->setMaximum(36000);
        spinboxd3_formula_rotation_2_z->setSingleStep(0.1);

        gridLayout_45->addWidget(spinboxd3_formula_rotation_2_z, 6, 2, 1, 1);

        vect3_formula_position_2_y = new MyLineEdit(groupBox_formula_transform_2);
        vect3_formula_position_2_y->setObjectName(QStringLiteral("vect3_formula_position_2_y"));

        gridLayout_45->addWidget(vect3_formula_position_2_y, 1, 2, 1, 1);

        spinboxd3_formula_rotation_2_y = new MyDoubleSpinBox(groupBox_formula_transform_2);
        spinboxd3_formula_rotation_2_y->setObjectName(QStringLiteral("spinboxd3_formula_rotation_2_y"));
        spinboxd3_formula_rotation_2_y->setDecimals(2);
        spinboxd3_formula_rotation_2_y->setMinimum(-36000);
        spinboxd3_formula_rotation_2_y->setMaximum(36000);
        spinboxd3_formula_rotation_2_y->setSingleStep(0.1);

        gridLayout_45->addWidget(spinboxd3_formula_rotation_2_y, 5, 2, 1, 1);

        label_183 = new QLabel(groupBox_formula_transform_2);
        label_183->setObjectName(QStringLiteral("label_183"));
        sizePolicy3.setHeightForWidth(label_183->sizePolicy().hasHeightForWidth());
        label_183->setSizePolicy(sizePolicy3);
        label_183->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_45->addWidget(label_183, 8, 1, 1, 1);

        vect3_formula_position_2_x = new MyLineEdit(groupBox_formula_transform_2);
        vect3_formula_position_2_x->setObjectName(QStringLiteral("vect3_formula_position_2_x"));

        gridLayout_45->addWidget(vect3_formula_position_2_x, 0, 2, 1, 1);

        spinboxd3_formula_rotation_2_x = new MyDoubleSpinBox(groupBox_formula_transform_2);
        spinboxd3_formula_rotation_2_x->setObjectName(QStringLiteral("spinboxd3_formula_rotation_2_x"));
        spinboxd3_formula_rotation_2_x->setDecimals(2);
        spinboxd3_formula_rotation_2_x->setMinimum(-36000);
        spinboxd3_formula_rotation_2_x->setMaximum(36000);
        spinboxd3_formula_rotation_2_x->setSingleStep(0.1);

        gridLayout_45->addWidget(spinboxd3_formula_rotation_2_x, 4, 2, 1, 1);

        dial3_formula_rotation_2_x = new QDial(groupBox_formula_transform_2);
        dial3_formula_rotation_2_x->setObjectName(QStringLiteral("dial3_formula_rotation_2_x"));
        dial3_formula_rotation_2_x->setMinimum(-18000);
        dial3_formula_rotation_2_x->setMaximum(18000);
        dial3_formula_rotation_2_x->setWrapping(true);

        gridLayout_45->addWidget(dial3_formula_rotation_2_x, 4, 1, 1, 1);

        vect3_formula_repeat_2_x = new MyLineEdit(groupBox_formula_transform_2);
        vect3_formula_repeat_2_x->setObjectName(QStringLiteral("vect3_formula_repeat_2_x"));

        gridLayout_45->addWidget(vect3_formula_repeat_2_x, 7, 2, 1, 1);

        dial3_formula_rotation_2_z = new QDial(groupBox_formula_transform_2);
        dial3_formula_rotation_2_z->setObjectName(QStringLiteral("dial3_formula_rotation_2_z"));
        dial3_formula_rotation_2_z->setMinimum(-18000);
        dial3_formula_rotation_2_z->setMaximum(18000);
        dial3_formula_rotation_2_z->setWrapping(true);

        gridLayout_45->addWidget(dial3_formula_rotation_2_z, 6, 1, 1, 1);

        label_184 = new QLabel(groupBox_formula_transform_2);
        label_184->setObjectName(QStringLiteral("label_184"));

        gridLayout_45->addWidget(label_184, 4, 0, 1, 1);

        label_186 = new QLabel(groupBox_formula_transform_2);
        label_186->setObjectName(QStringLiteral("label_186"));

        gridLayout_45->addWidget(label_186, 6, 0, 1, 1);

        label_185 = new QLabel(groupBox_formula_transform_2);
        label_185->setObjectName(QStringLiteral("label_185"));
        sizePolicy3.setHeightForWidth(label_185->sizePolicy().hasHeightForWidth());
        label_185->setSizePolicy(sizePolicy3);
        label_185->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_45->addWidget(label_185, 1, 1, 1, 1);

        vect3_formula_repeat_2_y = new MyLineEdit(groupBox_formula_transform_2);
        vect3_formula_repeat_2_y->setObjectName(QStringLiteral("vect3_formula_repeat_2_y"));

        gridLayout_45->addWidget(vect3_formula_repeat_2_y, 8, 2, 1, 1);

        label_187 = new QLabel(groupBox_formula_transform_2);
        label_187->setObjectName(QStringLiteral("label_187"));
        sizePolicy3.setHeightForWidth(label_187->sizePolicy().hasHeightForWidth());
        label_187->setSizePolicy(sizePolicy3);
        label_187->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_45->addWidget(label_187, 7, 1, 1, 1);

        vect3_formula_repeat_2_z = new MyLineEdit(groupBox_formula_transform_2);
        vect3_formula_repeat_2_z->setObjectName(QStringLiteral("vect3_formula_repeat_2_z"));

        gridLayout_45->addWidget(vect3_formula_repeat_2_z, 9, 2, 1, 1);

        label_188 = new QLabel(groupBox_formula_transform_2);
        label_188->setObjectName(QStringLiteral("label_188"));
        sizePolicy3.setHeightForWidth(label_188->sizePolicy().hasHeightForWidth());
        label_188->setSizePolicy(sizePolicy3);
        label_188->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_45->addWidget(label_188, 9, 1, 1, 1);

        label_189 = new QLabel(groupBox_formula_transform_2);
        label_189->setObjectName(QStringLiteral("label_189"));

        gridLayout_45->addWidget(label_189, 7, 0, 3, 1);

        logslider_formula_scale_2 = new QSlider(groupBox_formula_transform_2);
        logslider_formula_scale_2->setObjectName(QStringLiteral("logslider_formula_scale_2"));
        sizePolicy1.setHeightForWidth(logslider_formula_scale_2->sizePolicy().hasHeightForWidth());
        logslider_formula_scale_2->setSizePolicy(sizePolicy1);
        logslider_formula_scale_2->setSizeIncrement(QSize(0, 0));
        logslider_formula_scale_2->setMinimum(-1000);
        logslider_formula_scale_2->setMaximum(300);
        logslider_formula_scale_2->setOrientation(Qt::Horizontal);

        gridLayout_45->addWidget(logslider_formula_scale_2, 3, 1, 1, 1);

        logedit_formula_scale_2 = new MyLineEdit(groupBox_formula_transform_2);
        logedit_formula_scale_2->setObjectName(QStringLiteral("logedit_formula_scale_2"));
        sizePolicy1.setHeightForWidth(logedit_formula_scale_2->sizePolicy().hasHeightForWidth());
        logedit_formula_scale_2->setSizePolicy(sizePolicy1);

        gridLayout_45->addWidget(logedit_formula_scale_2, 3, 2, 1, 1);

        label_214 = new QLabel(groupBox_formula_transform_2);
        label_214->setObjectName(QStringLiteral("label_214"));

        gridLayout_45->addWidget(label_214, 3, 0, 1, 1);


        verticalLayout_85->addLayout(gridLayout_45);


        verticalLayoutScroll_fractal_3->addWidget(groupBox_formula_transform_2);

        verticalSpacer_14 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutScroll_fractal_3->addItem(verticalSpacer_14);

        scrollArea_fractal_2->setWidget(scrollAreaWidgetContents_fractal_2);

        verticalLayout_50->addWidget(scrollArea_fractal_2);

        tabWidget_fractals->addTab(tab_fractal_formula_2, QString());
        tab_fractal_formula_3 = new QWidget();
        tab_fractal_formula_3->setObjectName(QStringLiteral("tab_fractal_formula_3"));
        verticalLayout_51 = new QVBoxLayout(tab_fractal_formula_3);
        verticalLayout_51->setSpacing(2);
        verticalLayout_51->setContentsMargins(2, 2, 2, 2);
        verticalLayout_51->setObjectName(QStringLiteral("verticalLayout_51"));
        verticalLayout_51->setContentsMargins(2, 2, 2, 2);
        scrollArea_fractal_3 = new QScrollArea(tab_fractal_formula_3);
        scrollArea_fractal_3->setObjectName(QStringLiteral("scrollArea_fractal_3"));
        scrollArea_fractal_3->setWidgetResizable(true);
        scrollAreaWidgetContents_fractal_3 = new QWidget();
        scrollAreaWidgetContents_fractal_3->setObjectName(QStringLiteral("scrollAreaWidgetContents_fractal_3"));
        scrollAreaWidgetContents_fractal_3->setGeometry(QRect(0, 0, 281, 445));
        verticalLayoutScroll_fractal_4 = new QVBoxLayout(scrollAreaWidgetContents_fractal_3);
        verticalLayoutScroll_fractal_4->setSpacing(2);
        verticalLayoutScroll_fractal_4->setContentsMargins(2, 2, 2, 2);
        verticalLayoutScroll_fractal_4->setObjectName(QStringLiteral("verticalLayoutScroll_fractal_4"));
        verticalLayoutScroll_fractal_4->setContentsMargins(2, 2, 2, 2);
        frame_iterations_formula_3 = new QFrame(scrollAreaWidgetContents_fractal_3);
        frame_iterations_formula_3->setObjectName(QStringLiteral("frame_iterations_formula_3"));
        frame_iterations_formula_3->setFrameShape(QFrame::StyledPanel);
        frame_iterations_formula_3->setFrameShadow(QFrame::Raised);
        verticalLayout_86 = new QVBoxLayout(frame_iterations_formula_3);
        verticalLayout_86->setSpacing(2);
        verticalLayout_86->setContentsMargins(2, 2, 2, 2);
        verticalLayout_86->setObjectName(QStringLiteral("verticalLayout_86"));
        verticalLayout_86->setContentsMargins(2, 2, 2, 2);
        gridLayout_46 = new QGridLayout();
        gridLayout_46->setSpacing(2);
        gridLayout_46->setObjectName(QStringLiteral("gridLayout_46"));
        gridLayout_46->setContentsMargins(-1, 0, -1, -1);
        label_formula_iterations_3 = new QLabel(frame_iterations_formula_3);
        label_formula_iterations_3->setObjectName(QStringLiteral("label_formula_iterations_3"));

        gridLayout_46->addWidget(label_formula_iterations_3, 1, 0, 1, 1);

        sliderInt_formula_iterations_3 = new QSlider(frame_iterations_formula_3);
        sliderInt_formula_iterations_3->setObjectName(QStringLiteral("sliderInt_formula_iterations_3"));
        sliderInt_formula_iterations_3->setMinimum(1);
        sliderInt_formula_iterations_3->setMaximum(250);
        sliderInt_formula_iterations_3->setSingleStep(8);
        sliderInt_formula_iterations_3->setPageStep(64);
        sliderInt_formula_iterations_3->setOrientation(Qt::Horizontal);

        gridLayout_46->addWidget(sliderInt_formula_iterations_3, 1, 1, 1, 1);

        spinboxInt_formula_iterations_3 = new MySpinBox(frame_iterations_formula_3);
        spinboxInt_formula_iterations_3->setObjectName(QStringLiteral("spinboxInt_formula_iterations_3"));
        spinboxInt_formula_iterations_3->setMinimum(1);
        spinboxInt_formula_iterations_3->setMaximum(500);

        gridLayout_46->addWidget(spinboxInt_formula_iterations_3, 1, 2, 1, 1);

        comboBox_formula_3 = new QComboBox(frame_iterations_formula_3);
        comboBox_formula_3->setObjectName(QStringLiteral("comboBox_formula_3"));
        comboBox_formula_3->setMaxVisibleItems(50);

        gridLayout_46->addWidget(comboBox_formula_3, 0, 0, 1, 3);


        verticalLayout_86->addLayout(gridLayout_46);


        verticalLayoutScroll_fractal_4->addWidget(frame_iterations_formula_3);

        groupBox_formula_parameters_3 = new QGroupBox(scrollAreaWidgetContents_fractal_3);
        groupBox_formula_parameters_3->setObjectName(QStringLiteral("groupBox_formula_parameters_3"));
        verticalLayout_87 = new QVBoxLayout(groupBox_formula_parameters_3);
        verticalLayout_87->setSpacing(2);
        verticalLayout_87->setContentsMargins(2, 2, 2, 2);
        verticalLayout_87->setObjectName(QStringLiteral("verticalLayout_87"));
        verticalLayout_87->setContentsMargins(2, 2, 2, 2);
        verticalLayout_fractal_3 = new QVBoxLayout();
        verticalLayout_fractal_3->setSpacing(2);
        verticalLayout_fractal_3->setObjectName(QStringLiteral("verticalLayout_fractal_3"));

        verticalLayout_87->addLayout(verticalLayout_fractal_3);


        verticalLayoutScroll_fractal_4->addWidget(groupBox_formula_parameters_3);

        groupBox_formula_transform_3 = new QGroupBox(scrollAreaWidgetContents_fractal_3);
        groupBox_formula_transform_3->setObjectName(QStringLiteral("groupBox_formula_transform_3"));
        verticalLayout_88 = new QVBoxLayout(groupBox_formula_transform_3);
        verticalLayout_88->setSpacing(2);
        verticalLayout_88->setContentsMargins(2, 2, 2, 2);
        verticalLayout_88->setObjectName(QStringLiteral("verticalLayout_88"));
        verticalLayout_88->setContentsMargins(2, 2, 2, 2);
        gridLayout_47 = new QGridLayout();
        gridLayout_47->setSpacing(2);
        gridLayout_47->setObjectName(QStringLiteral("gridLayout_47"));
        spinboxd3_formula_rotation_3_y = new MyDoubleSpinBox(groupBox_formula_transform_3);
        spinboxd3_formula_rotation_3_y->setObjectName(QStringLiteral("spinboxd3_formula_rotation_3_y"));
        spinboxd3_formula_rotation_3_y->setDecimals(2);
        spinboxd3_formula_rotation_3_y->setMinimum(-36000);
        spinboxd3_formula_rotation_3_y->setMaximum(36000);
        spinboxd3_formula_rotation_3_y->setSingleStep(0.1);

        gridLayout_47->addWidget(spinboxd3_formula_rotation_3_y, 5, 2, 1, 1);

        label_190 = new QLabel(groupBox_formula_transform_3);
        label_190->setObjectName(QStringLiteral("label_190"));
        sizePolicy3.setHeightForWidth(label_190->sizePolicy().hasHeightForWidth());
        label_190->setSizePolicy(sizePolicy3);
        label_190->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_47->addWidget(label_190, 2, 1, 1, 1);

        vect3_formula_position_3_z = new MyLineEdit(groupBox_formula_transform_3);
        vect3_formula_position_3_z->setObjectName(QStringLiteral("vect3_formula_position_3_z"));

        gridLayout_47->addWidget(vect3_formula_position_3_z, 2, 2, 1, 1);

        dial3_formula_rotation_3_y = new QDial(groupBox_formula_transform_3);
        dial3_formula_rotation_3_y->setObjectName(QStringLiteral("dial3_formula_rotation_3_y"));
        dial3_formula_rotation_3_y->setMinimum(-18000);
        dial3_formula_rotation_3_y->setMaximum(18000);
        dial3_formula_rotation_3_y->setWrapping(true);

        gridLayout_47->addWidget(dial3_formula_rotation_3_y, 5, 1, 1, 1);

        label_191 = new QLabel(groupBox_formula_transform_3);
        label_191->setObjectName(QStringLiteral("label_191"));

        gridLayout_47->addWidget(label_191, 0, 0, 3, 1);

        label_192 = new QLabel(groupBox_formula_transform_3);
        label_192->setObjectName(QStringLiteral("label_192"));

        gridLayout_47->addWidget(label_192, 5, 0, 1, 1);

        label_193 = new QLabel(groupBox_formula_transform_3);
        label_193->setObjectName(QStringLiteral("label_193"));
        sizePolicy3.setHeightForWidth(label_193->sizePolicy().hasHeightForWidth());
        label_193->setSizePolicy(sizePolicy3);
        label_193->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_47->addWidget(label_193, 0, 1, 1, 1);

        vect3_formula_position_3_y = new MyLineEdit(groupBox_formula_transform_3);
        vect3_formula_position_3_y->setObjectName(QStringLiteral("vect3_formula_position_3_y"));

        gridLayout_47->addWidget(vect3_formula_position_3_y, 1, 2, 1, 1);

        spinboxd3_formula_rotation_3_z = new MyDoubleSpinBox(groupBox_formula_transform_3);
        spinboxd3_formula_rotation_3_z->setObjectName(QStringLiteral("spinboxd3_formula_rotation_3_z"));
        spinboxd3_formula_rotation_3_z->setDecimals(2);
        spinboxd3_formula_rotation_3_z->setMinimum(-36000);
        spinboxd3_formula_rotation_3_z->setMaximum(36000);
        spinboxd3_formula_rotation_3_z->setSingleStep(0.1);

        gridLayout_47->addWidget(spinboxd3_formula_rotation_3_z, 6, 2, 1, 1);

        label_194 = new QLabel(groupBox_formula_transform_3);
        label_194->setObjectName(QStringLiteral("label_194"));
        sizePolicy3.setHeightForWidth(label_194->sizePolicy().hasHeightForWidth());
        label_194->setSizePolicy(sizePolicy3);
        label_194->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_47->addWidget(label_194, 8, 1, 1, 1);

        spinboxd3_formula_rotation_3_x = new MyDoubleSpinBox(groupBox_formula_transform_3);
        spinboxd3_formula_rotation_3_x->setObjectName(QStringLiteral("spinboxd3_formula_rotation_3_x"));
        spinboxd3_formula_rotation_3_x->setDecimals(2);
        spinboxd3_formula_rotation_3_x->setMinimum(-36000);
        spinboxd3_formula_rotation_3_x->setMaximum(36000);
        spinboxd3_formula_rotation_3_x->setSingleStep(0.1);

        gridLayout_47->addWidget(spinboxd3_formula_rotation_3_x, 4, 2, 1, 1);

        vect3_formula_position_3_x = new MyLineEdit(groupBox_formula_transform_3);
        vect3_formula_position_3_x->setObjectName(QStringLiteral("vect3_formula_position_3_x"));

        gridLayout_47->addWidget(vect3_formula_position_3_x, 0, 2, 1, 1);

        dial3_formula_rotation_3_x = new QDial(groupBox_formula_transform_3);
        dial3_formula_rotation_3_x->setObjectName(QStringLiteral("dial3_formula_rotation_3_x"));
        dial3_formula_rotation_3_x->setMinimum(-18000);
        dial3_formula_rotation_3_x->setMaximum(18000);
        dial3_formula_rotation_3_x->setWrapping(true);

        gridLayout_47->addWidget(dial3_formula_rotation_3_x, 4, 1, 1, 1);

        vect3_formula_repeat_3_x = new MyLineEdit(groupBox_formula_transform_3);
        vect3_formula_repeat_3_x->setObjectName(QStringLiteral("vect3_formula_repeat_3_x"));

        gridLayout_47->addWidget(vect3_formula_repeat_3_x, 7, 2, 1, 1);

        dial3_formula_rotation_3_z = new QDial(groupBox_formula_transform_3);
        dial3_formula_rotation_3_z->setObjectName(QStringLiteral("dial3_formula_rotation_3_z"));
        dial3_formula_rotation_3_z->setMinimum(-18000);
        dial3_formula_rotation_3_z->setMaximum(18000);
        dial3_formula_rotation_3_z->setWrapping(true);

        gridLayout_47->addWidget(dial3_formula_rotation_3_z, 6, 1, 1, 1);

        label_195 = new QLabel(groupBox_formula_transform_3);
        label_195->setObjectName(QStringLiteral("label_195"));

        gridLayout_47->addWidget(label_195, 4, 0, 1, 1);

        label_197 = new QLabel(groupBox_formula_transform_3);
        label_197->setObjectName(QStringLiteral("label_197"));

        gridLayout_47->addWidget(label_197, 6, 0, 1, 1);

        label_196 = new QLabel(groupBox_formula_transform_3);
        label_196->setObjectName(QStringLiteral("label_196"));
        sizePolicy3.setHeightForWidth(label_196->sizePolicy().hasHeightForWidth());
        label_196->setSizePolicy(sizePolicy3);
        label_196->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_47->addWidget(label_196, 1, 1, 1, 1);

        vect3_formula_repeat_3_y = new MyLineEdit(groupBox_formula_transform_3);
        vect3_formula_repeat_3_y->setObjectName(QStringLiteral("vect3_formula_repeat_3_y"));

        gridLayout_47->addWidget(vect3_formula_repeat_3_y, 8, 2, 1, 1);

        label_198 = new QLabel(groupBox_formula_transform_3);
        label_198->setObjectName(QStringLiteral("label_198"));
        sizePolicy3.setHeightForWidth(label_198->sizePolicy().hasHeightForWidth());
        label_198->setSizePolicy(sizePolicy3);
        label_198->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_47->addWidget(label_198, 7, 1, 1, 1);

        vect3_formula_repeat_3_z = new MyLineEdit(groupBox_formula_transform_3);
        vect3_formula_repeat_3_z->setObjectName(QStringLiteral("vect3_formula_repeat_3_z"));

        gridLayout_47->addWidget(vect3_formula_repeat_3_z, 9, 2, 1, 1);

        label_199 = new QLabel(groupBox_formula_transform_3);
        label_199->setObjectName(QStringLiteral("label_199"));
        sizePolicy3.setHeightForWidth(label_199->sizePolicy().hasHeightForWidth());
        label_199->setSizePolicy(sizePolicy3);
        label_199->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_47->addWidget(label_199, 9, 1, 1, 1);

        label_200 = new QLabel(groupBox_formula_transform_3);
        label_200->setObjectName(QStringLiteral("label_200"));

        gridLayout_47->addWidget(label_200, 7, 0, 3, 1);

        logslider_formula_scale_3 = new QSlider(groupBox_formula_transform_3);
        logslider_formula_scale_3->setObjectName(QStringLiteral("logslider_formula_scale_3"));
        sizePolicy1.setHeightForWidth(logslider_formula_scale_3->sizePolicy().hasHeightForWidth());
        logslider_formula_scale_3->setSizePolicy(sizePolicy1);
        logslider_formula_scale_3->setSizeIncrement(QSize(0, 0));
        logslider_formula_scale_3->setMinimum(-1000);
        logslider_formula_scale_3->setMaximum(300);
        logslider_formula_scale_3->setOrientation(Qt::Horizontal);

        gridLayout_47->addWidget(logslider_formula_scale_3, 3, 1, 1, 1);

        logedit_formula_scale_3 = new MyLineEdit(groupBox_formula_transform_3);
        logedit_formula_scale_3->setObjectName(QStringLiteral("logedit_formula_scale_3"));
        sizePolicy1.setHeightForWidth(logedit_formula_scale_3->sizePolicy().hasHeightForWidth());
        logedit_formula_scale_3->setSizePolicy(sizePolicy1);

        gridLayout_47->addWidget(logedit_formula_scale_3, 3, 2, 1, 1);

        label_215 = new QLabel(groupBox_formula_transform_3);
        label_215->setObjectName(QStringLiteral("label_215"));

        gridLayout_47->addWidget(label_215, 3, 0, 1, 1);


        verticalLayout_88->addLayout(gridLayout_47);


        verticalLayoutScroll_fractal_4->addWidget(groupBox_formula_transform_3);

        verticalSpacer_15 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutScroll_fractal_4->addItem(verticalSpacer_15);

        scrollArea_fractal_3->setWidget(scrollAreaWidgetContents_fractal_3);

        verticalLayout_51->addWidget(scrollArea_fractal_3);

        tabWidget_fractals->addTab(tab_fractal_formula_3, QString());
        tab_fractal_formula_4 = new QWidget();
        tab_fractal_formula_4->setObjectName(QStringLiteral("tab_fractal_formula_4"));
        verticalLayout_52 = new QVBoxLayout(tab_fractal_formula_4);
        verticalLayout_52->setSpacing(2);
        verticalLayout_52->setContentsMargins(2, 2, 2, 2);
        verticalLayout_52->setObjectName(QStringLiteral("verticalLayout_52"));
        verticalLayout_52->setContentsMargins(2, 2, 2, 2);
        scrollArea_fractal_4 = new QScrollArea(tab_fractal_formula_4);
        scrollArea_fractal_4->setObjectName(QStringLiteral("scrollArea_fractal_4"));
        scrollArea_fractal_4->setWidgetResizable(true);
        scrollAreaWidgetContents_fractal_4 = new QWidget();
        scrollAreaWidgetContents_fractal_4->setObjectName(QStringLiteral("scrollAreaWidgetContents_fractal_4"));
        scrollAreaWidgetContents_fractal_4->setGeometry(QRect(0, 0, 281, 445));
        verticalLayoutScroll_fractal_5 = new QVBoxLayout(scrollAreaWidgetContents_fractal_4);
        verticalLayoutScroll_fractal_5->setSpacing(2);
        verticalLayoutScroll_fractal_5->setContentsMargins(2, 2, 2, 2);
        verticalLayoutScroll_fractal_5->setObjectName(QStringLiteral("verticalLayoutScroll_fractal_5"));
        verticalLayoutScroll_fractal_5->setContentsMargins(2, 2, 2, 2);
        frame_iterations_formula_4 = new QFrame(scrollAreaWidgetContents_fractal_4);
        frame_iterations_formula_4->setObjectName(QStringLiteral("frame_iterations_formula_4"));
        frame_iterations_formula_4->setFrameShape(QFrame::StyledPanel);
        frame_iterations_formula_4->setFrameShadow(QFrame::Raised);
        verticalLayout_89 = new QVBoxLayout(frame_iterations_formula_4);
        verticalLayout_89->setSpacing(2);
        verticalLayout_89->setContentsMargins(2, 2, 2, 2);
        verticalLayout_89->setObjectName(QStringLiteral("verticalLayout_89"));
        verticalLayout_89->setContentsMargins(2, 2, 2, 2);
        gridLayout_48 = new QGridLayout();
        gridLayout_48->setSpacing(2);
        gridLayout_48->setObjectName(QStringLiteral("gridLayout_48"));
        gridLayout_48->setContentsMargins(-1, 0, -1, -1);
        label_formula_iterations_4 = new QLabel(frame_iterations_formula_4);
        label_formula_iterations_4->setObjectName(QStringLiteral("label_formula_iterations_4"));

        gridLayout_48->addWidget(label_formula_iterations_4, 1, 0, 1, 1);

        sliderInt_formula_iterations_4 = new QSlider(frame_iterations_formula_4);
        sliderInt_formula_iterations_4->setObjectName(QStringLiteral("sliderInt_formula_iterations_4"));
        sliderInt_formula_iterations_4->setMinimum(1);
        sliderInt_formula_iterations_4->setMaximum(250);
        sliderInt_formula_iterations_4->setSingleStep(8);
        sliderInt_formula_iterations_4->setPageStep(64);
        sliderInt_formula_iterations_4->setOrientation(Qt::Horizontal);

        gridLayout_48->addWidget(sliderInt_formula_iterations_4, 1, 1, 1, 1);

        spinboxInt_formula_iterations_4 = new MySpinBox(frame_iterations_formula_4);
        spinboxInt_formula_iterations_4->setObjectName(QStringLiteral("spinboxInt_formula_iterations_4"));
        spinboxInt_formula_iterations_4->setMinimum(1);
        spinboxInt_formula_iterations_4->setMaximum(500);

        gridLayout_48->addWidget(spinboxInt_formula_iterations_4, 1, 2, 1, 1);

        comboBox_formula_4 = new QComboBox(frame_iterations_formula_4);
        comboBox_formula_4->setObjectName(QStringLiteral("comboBox_formula_4"));
        comboBox_formula_4->setMaxVisibleItems(50);

        gridLayout_48->addWidget(comboBox_formula_4, 0, 0, 1, 3);


        verticalLayout_89->addLayout(gridLayout_48);


        verticalLayoutScroll_fractal_5->addWidget(frame_iterations_formula_4);

        groupBox_formula_parameters_4 = new QGroupBox(scrollAreaWidgetContents_fractal_4);
        groupBox_formula_parameters_4->setObjectName(QStringLiteral("groupBox_formula_parameters_4"));
        verticalLayout_90 = new QVBoxLayout(groupBox_formula_parameters_4);
        verticalLayout_90->setSpacing(2);
        verticalLayout_90->setContentsMargins(2, 2, 2, 2);
        verticalLayout_90->setObjectName(QStringLiteral("verticalLayout_90"));
        verticalLayout_90->setContentsMargins(2, 2, 2, 2);
        verticalLayout_fractal_4 = new QVBoxLayout();
        verticalLayout_fractal_4->setSpacing(2);
        verticalLayout_fractal_4->setObjectName(QStringLiteral("verticalLayout_fractal_4"));

        verticalLayout_90->addLayout(verticalLayout_fractal_4);


        verticalLayoutScroll_fractal_5->addWidget(groupBox_formula_parameters_4);

        groupBox_formula_transform_4 = new QGroupBox(scrollAreaWidgetContents_fractal_4);
        groupBox_formula_transform_4->setObjectName(QStringLiteral("groupBox_formula_transform_4"));
        verticalLayout_91 = new QVBoxLayout(groupBox_formula_transform_4);
        verticalLayout_91->setSpacing(2);
        verticalLayout_91->setContentsMargins(2, 2, 2, 2);
        verticalLayout_91->setObjectName(QStringLiteral("verticalLayout_91"));
        verticalLayout_91->setContentsMargins(2, 2, 2, 2);
        gridLayout_49 = new QGridLayout();
        gridLayout_49->setSpacing(2);
        gridLayout_49->setObjectName(QStringLiteral("gridLayout_49"));
        label_201 = new QLabel(groupBox_formula_transform_4);
        label_201->setObjectName(QStringLiteral("label_201"));
        sizePolicy3.setHeightForWidth(label_201->sizePolicy().hasHeightForWidth());
        label_201->setSizePolicy(sizePolicy3);
        label_201->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_49->addWidget(label_201, 2, 1, 1, 1);

        vect3_formula_position_4_z = new MyLineEdit(groupBox_formula_transform_4);
        vect3_formula_position_4_z->setObjectName(QStringLiteral("vect3_formula_position_4_z"));

        gridLayout_49->addWidget(vect3_formula_position_4_z, 2, 2, 1, 1);

        dial3_formula_rotation_4_y = new QDial(groupBox_formula_transform_4);
        dial3_formula_rotation_4_y->setObjectName(QStringLiteral("dial3_formula_rotation_4_y"));
        dial3_formula_rotation_4_y->setMinimum(-18000);
        dial3_formula_rotation_4_y->setMaximum(18000);
        dial3_formula_rotation_4_y->setWrapping(true);

        gridLayout_49->addWidget(dial3_formula_rotation_4_y, 5, 1, 1, 1);

        label_202 = new QLabel(groupBox_formula_transform_4);
        label_202->setObjectName(QStringLiteral("label_202"));

        gridLayout_49->addWidget(label_202, 0, 0, 3, 1);

        label_203 = new QLabel(groupBox_formula_transform_4);
        label_203->setObjectName(QStringLiteral("label_203"));

        gridLayout_49->addWidget(label_203, 5, 0, 1, 1);

        label_204 = new QLabel(groupBox_formula_transform_4);
        label_204->setObjectName(QStringLiteral("label_204"));
        sizePolicy3.setHeightForWidth(label_204->sizePolicy().hasHeightForWidth());
        label_204->setSizePolicy(sizePolicy3);
        label_204->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_49->addWidget(label_204, 0, 1, 1, 1);

        spinboxd3_formula_rotation_4_z = new MyDoubleSpinBox(groupBox_formula_transform_4);
        spinboxd3_formula_rotation_4_z->setObjectName(QStringLiteral("spinboxd3_formula_rotation_4_z"));
        spinboxd3_formula_rotation_4_z->setDecimals(2);
        spinboxd3_formula_rotation_4_z->setMinimum(-36000);
        spinboxd3_formula_rotation_4_z->setMaximum(36000);
        spinboxd3_formula_rotation_4_z->setSingleStep(0.1);

        gridLayout_49->addWidget(spinboxd3_formula_rotation_4_z, 6, 2, 1, 1);

        vect3_formula_position_4_y = new MyLineEdit(groupBox_formula_transform_4);
        vect3_formula_position_4_y->setObjectName(QStringLiteral("vect3_formula_position_4_y"));

        gridLayout_49->addWidget(vect3_formula_position_4_y, 1, 2, 1, 1);

        spinboxd3_formula_rotation_4_y = new MyDoubleSpinBox(groupBox_formula_transform_4);
        spinboxd3_formula_rotation_4_y->setObjectName(QStringLiteral("spinboxd3_formula_rotation_4_y"));
        spinboxd3_formula_rotation_4_y->setDecimals(2);
        spinboxd3_formula_rotation_4_y->setMinimum(-36000);
        spinboxd3_formula_rotation_4_y->setMaximum(36000);
        spinboxd3_formula_rotation_4_y->setSingleStep(0.1);

        gridLayout_49->addWidget(spinboxd3_formula_rotation_4_y, 5, 2, 1, 1);

        label_205 = new QLabel(groupBox_formula_transform_4);
        label_205->setObjectName(QStringLiteral("label_205"));
        sizePolicy3.setHeightForWidth(label_205->sizePolicy().hasHeightForWidth());
        label_205->setSizePolicy(sizePolicy3);
        label_205->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_49->addWidget(label_205, 8, 1, 1, 1);

        vect3_formula_position_4_x = new MyLineEdit(groupBox_formula_transform_4);
        vect3_formula_position_4_x->setObjectName(QStringLiteral("vect3_formula_position_4_x"));

        gridLayout_49->addWidget(vect3_formula_position_4_x, 0, 2, 1, 1);

        spinboxd3_formula_rotation_4_x = new MyDoubleSpinBox(groupBox_formula_transform_4);
        spinboxd3_formula_rotation_4_x->setObjectName(QStringLiteral("spinboxd3_formula_rotation_4_x"));
        spinboxd3_formula_rotation_4_x->setDecimals(2);
        spinboxd3_formula_rotation_4_x->setMinimum(-36000);
        spinboxd3_formula_rotation_4_x->setMaximum(36000);
        spinboxd3_formula_rotation_4_x->setSingleStep(0.1);

        gridLayout_49->addWidget(spinboxd3_formula_rotation_4_x, 4, 2, 1, 1);

        dial3_formula_rotation_4_x = new QDial(groupBox_formula_transform_4);
        dial3_formula_rotation_4_x->setObjectName(QStringLiteral("dial3_formula_rotation_4_x"));
        dial3_formula_rotation_4_x->setMinimum(-18000);
        dial3_formula_rotation_4_x->setMaximum(18000);
        dial3_formula_rotation_4_x->setWrapping(true);

        gridLayout_49->addWidget(dial3_formula_rotation_4_x, 4, 1, 1, 1);

        vect3_formula_repeat_4_x = new MyLineEdit(groupBox_formula_transform_4);
        vect3_formula_repeat_4_x->setObjectName(QStringLiteral("vect3_formula_repeat_4_x"));

        gridLayout_49->addWidget(vect3_formula_repeat_4_x, 7, 2, 1, 1);

        dial3_formula_rotation_4_z = new QDial(groupBox_formula_transform_4);
        dial3_formula_rotation_4_z->setObjectName(QStringLiteral("dial3_formula_rotation_4_z"));
        dial3_formula_rotation_4_z->setMinimum(-18000);
        dial3_formula_rotation_4_z->setMaximum(18000);
        dial3_formula_rotation_4_z->setWrapping(true);

        gridLayout_49->addWidget(dial3_formula_rotation_4_z, 6, 1, 1, 1);

        label_206 = new QLabel(groupBox_formula_transform_4);
        label_206->setObjectName(QStringLiteral("label_206"));

        gridLayout_49->addWidget(label_206, 4, 0, 1, 1);

        label_208 = new QLabel(groupBox_formula_transform_4);
        label_208->setObjectName(QStringLiteral("label_208"));

        gridLayout_49->addWidget(label_208, 6, 0, 1, 1);

        label_207 = new QLabel(groupBox_formula_transform_4);
        label_207->setObjectName(QStringLiteral("label_207"));
        sizePolicy3.setHeightForWidth(label_207->sizePolicy().hasHeightForWidth());
        label_207->setSizePolicy(sizePolicy3);
        label_207->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_49->addWidget(label_207, 1, 1, 1, 1);

        vect3_formula_repeat_4_y = new MyLineEdit(groupBox_formula_transform_4);
        vect3_formula_repeat_4_y->setObjectName(QStringLiteral("vect3_formula_repeat_4_y"));

        gridLayout_49->addWidget(vect3_formula_repeat_4_y, 8, 2, 1, 1);

        label_209 = new QLabel(groupBox_formula_transform_4);
        label_209->setObjectName(QStringLiteral("label_209"));
        sizePolicy3.setHeightForWidth(label_209->sizePolicy().hasHeightForWidth());
        label_209->setSizePolicy(sizePolicy3);
        label_209->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_49->addWidget(label_209, 7, 1, 1, 1);

        vect3_formula_repeat_4_z = new MyLineEdit(groupBox_formula_transform_4);
        vect3_formula_repeat_4_z->setObjectName(QStringLiteral("vect3_formula_repeat_4_z"));

        gridLayout_49->addWidget(vect3_formula_repeat_4_z, 9, 2, 1, 1);

        label_210 = new QLabel(groupBox_formula_transform_4);
        label_210->setObjectName(QStringLiteral("label_210"));
        sizePolicy3.setHeightForWidth(label_210->sizePolicy().hasHeightForWidth());
        label_210->setSizePolicy(sizePolicy3);
        label_210->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_49->addWidget(label_210, 9, 1, 1, 1);

        label_211 = new QLabel(groupBox_formula_transform_4);
        label_211->setObjectName(QStringLiteral("label_211"));

        gridLayout_49->addWidget(label_211, 7, 0, 3, 1);

        logslider_formula_scale_4 = new QSlider(groupBox_formula_transform_4);
        logslider_formula_scale_4->setObjectName(QStringLiteral("logslider_formula_scale_4"));
        sizePolicy1.setHeightForWidth(logslider_formula_scale_4->sizePolicy().hasHeightForWidth());
        logslider_formula_scale_4->setSizePolicy(sizePolicy1);
        logslider_formula_scale_4->setSizeIncrement(QSize(0, 0));
        logslider_formula_scale_4->setMinimum(-1000);
        logslider_formula_scale_4->setMaximum(300);
        logslider_formula_scale_4->setOrientation(Qt::Horizontal);

        gridLayout_49->addWidget(logslider_formula_scale_4, 3, 1, 1, 1);

        logedit_formula_scale_4 = new MyLineEdit(groupBox_formula_transform_4);
        logedit_formula_scale_4->setObjectName(QStringLiteral("logedit_formula_scale_4"));
        sizePolicy1.setHeightForWidth(logedit_formula_scale_4->sizePolicy().hasHeightForWidth());
        logedit_formula_scale_4->setSizePolicy(sizePolicy1);

        gridLayout_49->addWidget(logedit_formula_scale_4, 3, 2, 1, 1);


        verticalLayout_91->addLayout(gridLayout_49);


        verticalLayoutScroll_fractal_5->addWidget(groupBox_formula_transform_4);

        verticalSpacer_16 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayoutScroll_fractal_5->addItem(verticalSpacer_16);

        scrollArea_fractal_4->setWidget(scrollAreaWidgetContents_fractal_4);

        verticalLayout_52->addWidget(scrollArea_fractal_4);

        tabWidget_fractals->addTab(tab_fractal_formula_4, QString());

        verticalLayout_21->addWidget(tabWidget_fractals);

        tabWidget_fractal->addTab(tabWidget_fractal_formulas, QString());
        tabWidget_fractal_common = new QWidget();
        tabWidget_fractal_common->setObjectName(QStringLiteral("tabWidget_fractal_common"));
        verticalLayout_47 = new QVBoxLayout(tabWidget_fractal_common);
        verticalLayout_47->setSpacing(2);
        verticalLayout_47->setContentsMargins(2, 2, 2, 2);
        verticalLayout_47->setObjectName(QStringLiteral("verticalLayout_47"));
        verticalLayout_47->setContentsMargins(2, 2, 2, 2);
        scrollArea_11 = new QScrollArea(tabWidget_fractal_common);
        scrollArea_11->setObjectName(QStringLiteral("scrollArea_11"));
        scrollArea_11->setWidgetResizable(true);
        scrollAreaWidgetContents_12 = new QWidget();
        scrollAreaWidgetContents_12->setObjectName(QStringLiteral("scrollAreaWidgetContents_12"));
        scrollAreaWidgetContents_12->setGeometry(QRect(0, 0, 289, 456));
        verticalLayout_68 = new QVBoxLayout(scrollAreaWidgetContents_12);
        verticalLayout_68->setSpacing(2);
        verticalLayout_68->setContentsMargins(2, 2, 2, 2);
        verticalLayout_68->setObjectName(QStringLiteral("verticalLayout_68"));
        verticalLayout_68->setContentsMargins(2, 2, 2, 2);
        groupCheck_julia_mode = new MyGroupBox(scrollAreaWidgetContents_12);
        groupCheck_julia_mode->setObjectName(QStringLiteral("groupCheck_julia_mode"));
        groupCheck_julia_mode->setCheckable(true);
        verticalLayout_48 = new QVBoxLayout(groupCheck_julia_mode);
        verticalLayout_48->setSpacing(2);
        verticalLayout_48->setContentsMargins(2, 2, 2, 2);
        verticalLayout_48->setObjectName(QStringLiteral("verticalLayout_48"));
        verticalLayout_48->setContentsMargins(2, 2, 2, 2);
        gridLayout_22 = new QGridLayout();
        gridLayout_22->setSpacing(2);
        gridLayout_22->setObjectName(QStringLiteral("gridLayout_22"));
        label_116 = new QLabel(groupCheck_julia_mode);
        label_116->setObjectName(QStringLiteral("label_116"));
        sizePolicy3.setHeightForWidth(label_116->sizePolicy().hasHeightForWidth());
        label_116->setSizePolicy(sizePolicy3);
        label_116->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_22->addWidget(label_116, 1, 1, 1, 1);

        label_113 = new QLabel(groupCheck_julia_mode);
        label_113->setObjectName(QStringLiteral("label_113"));

        gridLayout_22->addWidget(label_113, 0, 0, 1, 1);

        vect3_julia_c_y = new MyLineEdit(groupCheck_julia_mode);
        vect3_julia_c_y->setObjectName(QStringLiteral("vect3_julia_c_y"));

        gridLayout_22->addWidget(vect3_julia_c_y, 1, 2, 1, 1);

        vect3_julia_c_x = new MyLineEdit(groupCheck_julia_mode);
        vect3_julia_c_x->setObjectName(QStringLiteral("vect3_julia_c_x"));

        gridLayout_22->addWidget(vect3_julia_c_x, 0, 2, 1, 1);

        label_120 = new QLabel(groupCheck_julia_mode);
        label_120->setObjectName(QStringLiteral("label_120"));
        sizePolicy3.setHeightForWidth(label_120->sizePolicy().hasHeightForWidth());
        label_120->setSizePolicy(sizePolicy3);
        label_120->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_22->addWidget(label_120, 2, 1, 1, 1);

        label_115 = new QLabel(groupCheck_julia_mode);
        label_115->setObjectName(QStringLiteral("label_115"));
        sizePolicy3.setHeightForWidth(label_115->sizePolicy().hasHeightForWidth());
        label_115->setSizePolicy(sizePolicy3);
        label_115->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_22->addWidget(label_115, 0, 1, 1, 1);

        vect3_julia_c_z = new MyLineEdit(groupCheck_julia_mode);
        vect3_julia_c_z->setObjectName(QStringLiteral("vect3_julia_c_z"));

        gridLayout_22->addWidget(vect3_julia_c_z, 2, 2, 1, 1);


        verticalLayout_48->addLayout(gridLayout_22);

        pushButton_get_julia_constant = new QPushButton(groupCheck_julia_mode);
        pushButton_get_julia_constant->setObjectName(QStringLiteral("pushButton_get_julia_constant"));

        verticalLayout_48->addWidget(pushButton_get_julia_constant);


        verticalLayout_68->addWidget(groupCheck_julia_mode);

        gridLayout_3 = new QGridLayout();
        gridLayout_3->setSpacing(2);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, -1, -1);
        label_135 = new QLabel(scrollAreaWidgetContents_12);
        label_135->setObjectName(QStringLiteral("label_135"));

        gridLayout_3->addWidget(label_135, 0, 0, 1, 1);

        slider_fractal_constant_factor = new QSlider(scrollAreaWidgetContents_12);
        slider_fractal_constant_factor->setObjectName(QStringLiteral("slider_fractal_constant_factor"));
        slider_fractal_constant_factor->setMinimum(-500);
        slider_fractal_constant_factor->setMaximum(500);
        slider_fractal_constant_factor->setSingleStep(1);
        slider_fractal_constant_factor->setOrientation(Qt::Horizontal);

        gridLayout_3->addWidget(slider_fractal_constant_factor, 0, 1, 1, 1);

        spinbox_fractal_constant_factor = new MyDoubleSpinBox(scrollAreaWidgetContents_12);
        spinbox_fractal_constant_factor->setObjectName(QStringLiteral("spinbox_fractal_constant_factor"));
        spinbox_fractal_constant_factor->setDecimals(2);
        spinbox_fractal_constant_factor->setMinimum(-1000);
        spinbox_fractal_constant_factor->setMaximum(1000);
        spinbox_fractal_constant_factor->setSingleStep(0.1);

        gridLayout_3->addWidget(spinbox_fractal_constant_factor, 0, 2, 1, 1);


        verticalLayout_68->addLayout(gridLayout_3);

        gridLayout_36 = new QGridLayout();
        gridLayout_36->setSpacing(2);
        gridLayout_36->setObjectName(QStringLiteral("gridLayout_36"));
        vect3_fractal_position_z = new MyLineEdit(scrollAreaWidgetContents_12);
        vect3_fractal_position_z->setObjectName(QStringLiteral("vect3_fractal_position_z"));

        gridLayout_36->addWidget(vect3_fractal_position_z, 2, 2, 1, 1);

        label_139 = new QLabel(scrollAreaWidgetContents_12);
        label_139->setObjectName(QStringLiteral("label_139"));
        sizePolicy3.setHeightForWidth(label_139->sizePolicy().hasHeightForWidth());
        label_139->setSizePolicy(sizePolicy3);
        label_139->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_36->addWidget(label_139, 2, 1, 1, 1);

        label_140 = new QLabel(scrollAreaWidgetContents_12);
        label_140->setObjectName(QStringLiteral("label_140"));
        sizePolicy3.setHeightForWidth(label_140->sizePolicy().hasHeightForWidth());
        label_140->setSizePolicy(sizePolicy3);
        label_140->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_36->addWidget(label_140, 0, 1, 1, 1);

        vect3_fractal_position_y = new MyLineEdit(scrollAreaWidgetContents_12);
        vect3_fractal_position_y->setObjectName(QStringLiteral("vect3_fractal_position_y"));

        gridLayout_36->addWidget(vect3_fractal_position_y, 1, 2, 1, 1);

        label_46 = new QLabel(scrollAreaWidgetContents_12);
        label_46->setObjectName(QStringLiteral("label_46"));

        gridLayout_36->addWidget(label_46, 3, 0, 1, 1);

        vect3_fractal_position_x = new MyLineEdit(scrollAreaWidgetContents_12);
        vect3_fractal_position_x->setObjectName(QStringLiteral("vect3_fractal_position_x"));

        gridLayout_36->addWidget(vect3_fractal_position_x, 0, 2, 1, 1);

        label_138 = new QLabel(scrollAreaWidgetContents_12);
        label_138->setObjectName(QStringLiteral("label_138"));

        gridLayout_36->addWidget(label_138, 0, 0, 1, 1);

        label_137 = new QLabel(scrollAreaWidgetContents_12);
        label_137->setObjectName(QStringLiteral("label_137"));
        sizePolicy3.setHeightForWidth(label_137->sizePolicy().hasHeightForWidth());
        label_137->setSizePolicy(sizePolicy3);
        label_137->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_36->addWidget(label_137, 1, 1, 1, 1);

        dial3_fractal_rotation_y = new QDial(scrollAreaWidgetContents_12);
        dial3_fractal_rotation_y->setObjectName(QStringLiteral("dial3_fractal_rotation_y"));
        dial3_fractal_rotation_y->setMinimum(-18000);
        dial3_fractal_rotation_y->setMaximum(18000);
        dial3_fractal_rotation_y->setWrapping(true);

        gridLayout_36->addWidget(dial3_fractal_rotation_y, 4, 1, 1, 1);

        dial3_fractal_rotation_x = new QDial(scrollAreaWidgetContents_12);
        dial3_fractal_rotation_x->setObjectName(QStringLiteral("dial3_fractal_rotation_x"));
        dial3_fractal_rotation_x->setMinimum(-18000);
        dial3_fractal_rotation_x->setMaximum(18000);
        dial3_fractal_rotation_x->setWrapping(true);

        gridLayout_36->addWidget(dial3_fractal_rotation_x, 3, 1, 1, 1);

        spinboxd3_fractal_rotation_x = new MyDoubleSpinBox(scrollAreaWidgetContents_12);
        spinboxd3_fractal_rotation_x->setObjectName(QStringLiteral("spinboxd3_fractal_rotation_x"));
        spinboxd3_fractal_rotation_x->setDecimals(2);
        spinboxd3_fractal_rotation_x->setMinimum(-36000);
        spinboxd3_fractal_rotation_x->setMaximum(36000);
        spinboxd3_fractal_rotation_x->setSingleStep(0.1);

        gridLayout_36->addWidget(spinboxd3_fractal_rotation_x, 3, 2, 1, 1);

        spinboxd3_fractal_rotation_y = new MyDoubleSpinBox(scrollAreaWidgetContents_12);
        spinboxd3_fractal_rotation_y->setObjectName(QStringLiteral("spinboxd3_fractal_rotation_y"));
        spinboxd3_fractal_rotation_y->setDecimals(2);
        spinboxd3_fractal_rotation_y->setMinimum(-36000);
        spinboxd3_fractal_rotation_y->setMaximum(36000);
        spinboxd3_fractal_rotation_y->setSingleStep(0.1);

        gridLayout_36->addWidget(spinboxd3_fractal_rotation_y, 4, 2, 1, 1);

        dial3_fractal_rotation_z = new QDial(scrollAreaWidgetContents_12);
        dial3_fractal_rotation_z->setObjectName(QStringLiteral("dial3_fractal_rotation_z"));
        dial3_fractal_rotation_z->setMinimum(-18000);
        dial3_fractal_rotation_z->setMaximum(18000);
        dial3_fractal_rotation_z->setWrapping(true);

        gridLayout_36->addWidget(dial3_fractal_rotation_z, 5, 1, 1, 1);

        spinboxd3_fractal_rotation_z = new MyDoubleSpinBox(scrollAreaWidgetContents_12);
        spinboxd3_fractal_rotation_z->setObjectName(QStringLiteral("spinboxd3_fractal_rotation_z"));
        spinboxd3_fractal_rotation_z->setDecimals(2);
        spinboxd3_fractal_rotation_z->setMinimum(-36000);
        spinboxd3_fractal_rotation_z->setMaximum(36000);
        spinboxd3_fractal_rotation_z->setSingleStep(0.1);

        gridLayout_36->addWidget(spinboxd3_fractal_rotation_z, 5, 2, 1, 1);

        label_48 = new QLabel(scrollAreaWidgetContents_12);
        label_48->setObjectName(QStringLiteral("label_48"));

        gridLayout_36->addWidget(label_48, 5, 0, 1, 1);

        label_47 = new QLabel(scrollAreaWidgetContents_12);
        label_47->setObjectName(QStringLiteral("label_47"));

        gridLayout_36->addWidget(label_47, 4, 0, 1, 1);

        vect3_repeat_x = new MyLineEdit(scrollAreaWidgetContents_12);
        vect3_repeat_x->setObjectName(QStringLiteral("vect3_repeat_x"));

        gridLayout_36->addWidget(vect3_repeat_x, 6, 2, 1, 1);

        vect3_repeat_y = new MyLineEdit(scrollAreaWidgetContents_12);
        vect3_repeat_y->setObjectName(QStringLiteral("vect3_repeat_y"));

        gridLayout_36->addWidget(vect3_repeat_y, 7, 2, 1, 1);

        vect3_repeat_z = new MyLineEdit(scrollAreaWidgetContents_12);
        vect3_repeat_z->setObjectName(QStringLiteral("vect3_repeat_z"));

        gridLayout_36->addWidget(vect3_repeat_z, 8, 2, 1, 1);

        label_repeat_x_2 = new QLabel(scrollAreaWidgetContents_12);
        label_repeat_x_2->setObjectName(QStringLiteral("label_repeat_x_2"));
        label_repeat_x_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_36->addWidget(label_repeat_x_2, 6, 1, 1, 1);

        label_repeat_y_2 = new QLabel(scrollAreaWidgetContents_12);
        label_repeat_y_2->setObjectName(QStringLiteral("label_repeat_y_2"));
        label_repeat_y_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_36->addWidget(label_repeat_y_2, 7, 1, 1, 1);

        label_repeat_z_2 = new QLabel(scrollAreaWidgetContents_12);
        label_repeat_z_2->setObjectName(QStringLiteral("label_repeat_z_2"));
        label_repeat_z_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_36->addWidget(label_repeat_z_2, 8, 1, 1, 1);

        label_145 = new QLabel(scrollAreaWidgetContents_12);
        label_145->setObjectName(QStringLiteral("label_145"));

        gridLayout_36->addWidget(label_145, 6, 0, 1, 1);


        verticalLayout_68->addLayout(gridLayout_36);

        verticalSpacer_7 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_68->addItem(verticalSpacer_7);

        scrollArea_11->setWidget(scrollAreaWidgetContents_12);

        verticalLayout_47->addWidget(scrollArea_11);

        tabWidget_fractal->addTab(tabWidget_fractal_common, QString());
        tabWidget_fractal_hybrid = new QWidget();
        tabWidget_fractal_hybrid->setObjectName(QStringLiteral("tabWidget_fractal_hybrid"));
        verticalLayout_53 = new QVBoxLayout(tabWidget_fractal_hybrid);
        verticalLayout_53->setSpacing(2);
        verticalLayout_53->setContentsMargins(2, 2, 2, 2);
        verticalLayout_53->setObjectName(QStringLiteral("verticalLayout_53"));
        verticalLayout_53->setContentsMargins(2, 2, 2, 2);
        gridLayout_28 = new QGridLayout();
        gridLayout_28->setSpacing(2);
        gridLayout_28->setObjectName(QStringLiteral("gridLayout_28"));
        checkBox_hybrid_fractal_enable = new MyCheckBox(tabWidget_fractal_hybrid);
        checkBox_hybrid_fractal_enable->setObjectName(QStringLiteral("checkBox_hybrid_fractal_enable"));

        gridLayout_28->addWidget(checkBox_hybrid_fractal_enable, 0, 0, 1, 1);

        checkBox_linear_DE_mode = new MyCheckBox(tabWidget_fractal_hybrid);
        checkBox_linear_DE_mode->setObjectName(QStringLiteral("checkBox_linear_DE_mode"));

        gridLayout_28->addWidget(checkBox_linear_DE_mode, 1, 0, 1, 1);


        verticalLayout_53->addLayout(gridLayout_28);

        groupCheck_boolean_operators = new MyGroupBox(tabWidget_fractal_hybrid);
        groupCheck_boolean_operators->setObjectName(QStringLiteral("groupCheck_boolean_operators"));
        groupCheck_boolean_operators->setCheckable(true);
        groupCheck_boolean_operators->setChecked(true);
        verticalLayout_76 = new QVBoxLayout(groupCheck_boolean_operators);
        verticalLayout_76->setSpacing(2);
        verticalLayout_76->setContentsMargins(2, 2, 2, 2);
        verticalLayout_76->setObjectName(QStringLiteral("verticalLayout_76"));
        verticalLayout_76->setContentsMargins(2, 2, 2, 2);
        gridLayout_40 = new QGridLayout();
        gridLayout_40->setSpacing(2);
        gridLayout_40->setObjectName(QStringLiteral("gridLayout_40"));
        comboBox_boolean_operator_1 = new QComboBox(groupCheck_boolean_operators);
        comboBox_boolean_operator_1->setObjectName(QStringLiteral("comboBox_boolean_operator_1"));

        gridLayout_40->addWidget(comboBox_boolean_operator_1, 1, 1, 1, 1);

        label_154 = new QLabel(groupCheck_boolean_operators);
        label_154->setObjectName(QStringLiteral("label_154"));

        gridLayout_40->addWidget(label_154, 1, 0, 1, 1);

        comboBox_boolean_operator_2 = new QComboBox(groupCheck_boolean_operators);
        comboBox_boolean_operator_2->setObjectName(QStringLiteral("comboBox_boolean_operator_2"));

        gridLayout_40->addWidget(comboBox_boolean_operator_2, 2, 1, 1, 1);

        comboBox_boolean_operator_3 = new QComboBox(groupCheck_boolean_operators);
        comboBox_boolean_operator_3->setObjectName(QStringLiteral("comboBox_boolean_operator_3"));

        gridLayout_40->addWidget(comboBox_boolean_operator_3, 3, 1, 1, 1);

        label_155 = new QLabel(groupCheck_boolean_operators);
        label_155->setObjectName(QStringLiteral("label_155"));

        gridLayout_40->addWidget(label_155, 2, 0, 1, 1);

        label_156 = new QLabel(groupCheck_boolean_operators);
        label_156->setObjectName(QStringLiteral("label_156"));

        gridLayout_40->addWidget(label_156, 3, 0, 1, 1);


        verticalLayout_76->addLayout(gridLayout_40);


        verticalLayout_53->addWidget(groupCheck_boolean_operators);

        groupCheck_box_folding = new MyGroupBox(tabWidget_fractal_hybrid);
        groupCheck_box_folding->setObjectName(QStringLiteral("groupCheck_box_folding"));
        groupCheck_box_folding->setCheckable(true);
        groupCheck_box_folding->setChecked(true);
        verticalLayout_80 = new QVBoxLayout(groupCheck_box_folding);
        verticalLayout_80->setSpacing(2);
        verticalLayout_80->setContentsMargins(2, 2, 2, 2);
        verticalLayout_80->setObjectName(QStringLiteral("verticalLayout_80"));
        verticalLayout_80->setContentsMargins(2, 2, 2, 2);
        gridLayout_42 = new QGridLayout();
        gridLayout_42->setSpacing(2);
        gridLayout_42->setObjectName(QStringLiteral("gridLayout_42"));
        label_128 = new QLabel(groupCheck_box_folding);
        label_128->setObjectName(QStringLiteral("label_128"));

        gridLayout_42->addWidget(label_128, 0, 0, 1, 1);

        slider_box_folding_limit = new QSlider(groupCheck_box_folding);
        slider_box_folding_limit->setObjectName(QStringLiteral("slider_box_folding_limit"));
        slider_box_folding_limit->setMaximum(500);
        slider_box_folding_limit->setSingleStep(1);
        slider_box_folding_limit->setOrientation(Qt::Horizontal);

        gridLayout_42->addWidget(slider_box_folding_limit, 0, 1, 1, 1);

        spinbox_box_folding_limit = new MyDoubleSpinBox(groupCheck_box_folding);
        spinbox_box_folding_limit->setObjectName(QStringLiteral("spinbox_box_folding_limit"));
        spinbox_box_folding_limit->setDecimals(2);
        spinbox_box_folding_limit->setMaximum(1000);
        spinbox_box_folding_limit->setSingleStep(0.1);

        gridLayout_42->addWidget(spinbox_box_folding_limit, 0, 2, 1, 1);

        label_129 = new QLabel(groupCheck_box_folding);
        label_129->setObjectName(QStringLiteral("label_129"));

        gridLayout_42->addWidget(label_129, 1, 0, 1, 1);

        slider_box_folding_value = new QSlider(groupCheck_box_folding);
        slider_box_folding_value->setObjectName(QStringLiteral("slider_box_folding_value"));
        slider_box_folding_value->setMaximum(500);
        slider_box_folding_value->setSingleStep(1);
        slider_box_folding_value->setOrientation(Qt::Horizontal);

        gridLayout_42->addWidget(slider_box_folding_value, 1, 1, 1, 1);

        spinbox_box_folding_value = new MyDoubleSpinBox(groupCheck_box_folding);
        spinbox_box_folding_value->setObjectName(QStringLiteral("spinbox_box_folding_value"));
        spinbox_box_folding_value->setDecimals(2);
        spinbox_box_folding_value->setMaximum(1000);
        spinbox_box_folding_value->setSingleStep(0.1);

        gridLayout_42->addWidget(spinbox_box_folding_value, 1, 2, 1, 1);


        verticalLayout_80->addLayout(gridLayout_42);


        verticalLayout_53->addWidget(groupCheck_box_folding);

        groupCheck_spherical_folding = new MyGroupBox(tabWidget_fractal_hybrid);
        groupCheck_spherical_folding->setObjectName(QStringLiteral("groupCheck_spherical_folding"));
        groupCheck_spherical_folding->setCheckable(true);
        groupCheck_spherical_folding->setChecked(true);
        verticalLayout_81 = new QVBoxLayout(groupCheck_spherical_folding);
        verticalLayout_81->setSpacing(2);
        verticalLayout_81->setContentsMargins(2, 2, 2, 2);
        verticalLayout_81->setObjectName(QStringLiteral("verticalLayout_81"));
        verticalLayout_81->setContentsMargins(2, 2, 2, 2);
        gridLayout_43 = new QGridLayout();
        gridLayout_43->setSpacing(2);
        gridLayout_43->setObjectName(QStringLiteral("gridLayout_43"));
        label_130 = new QLabel(groupCheck_spherical_folding);
        label_130->setObjectName(QStringLiteral("label_130"));

        gridLayout_43->addWidget(label_130, 0, 0, 1, 1);

        slider_spherical_folding_outher = new QSlider(groupCheck_spherical_folding);
        slider_spherical_folding_outher->setObjectName(QStringLiteral("slider_spherical_folding_outher"));
        slider_spherical_folding_outher->setMaximum(500);
        slider_spherical_folding_outher->setSingleStep(1);
        slider_spherical_folding_outher->setOrientation(Qt::Horizontal);

        gridLayout_43->addWidget(slider_spherical_folding_outher, 0, 1, 1, 1);

        spinbox_spherical_folding_outher = new MyDoubleSpinBox(groupCheck_spherical_folding);
        spinbox_spherical_folding_outher->setObjectName(QStringLiteral("spinbox_spherical_folding_outher"));
        spinbox_spherical_folding_outher->setDecimals(2);
        spinbox_spherical_folding_outher->setMaximum(1000);
        spinbox_spherical_folding_outher->setSingleStep(0.1);

        gridLayout_43->addWidget(spinbox_spherical_folding_outher, 0, 2, 1, 1);

        label_169 = new QLabel(groupCheck_spherical_folding);
        label_169->setObjectName(QStringLiteral("label_169"));

        gridLayout_43->addWidget(label_169, 1, 0, 1, 1);

        slider_spherical_folding_inner = new QSlider(groupCheck_spherical_folding);
        slider_spherical_folding_inner->setObjectName(QStringLiteral("slider_spherical_folding_inner"));
        slider_spherical_folding_inner->setMaximum(500);
        slider_spherical_folding_inner->setSingleStep(1);
        slider_spherical_folding_inner->setOrientation(Qt::Horizontal);

        gridLayout_43->addWidget(slider_spherical_folding_inner, 1, 1, 1, 1);

        spinbox_spherical_folding_inner = new MyDoubleSpinBox(groupCheck_spherical_folding);
        spinbox_spherical_folding_inner->setObjectName(QStringLiteral("spinbox_spherical_folding_inner"));
        spinbox_spherical_folding_inner->setDecimals(2);
        spinbox_spherical_folding_inner->setMaximum(1000);
        spinbox_spherical_folding_inner->setSingleStep(0.1);

        gridLayout_43->addWidget(spinbox_spherical_folding_inner, 1, 2, 1, 1);


        verticalLayout_81->addLayout(gridLayout_43);


        verticalLayout_53->addWidget(groupCheck_spherical_folding);

        verticalSpacer_10 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_53->addItem(verticalSpacer_10);

        tabWidget_fractal->addTab(tabWidget_fractal_hybrid, QString());
        tab_primitives = new QWidget();
        tab_primitives->setObjectName(QStringLiteral("tab_primitives"));
        verticalLayout_25 = new QVBoxLayout(tab_primitives);
        verticalLayout_25->setSpacing(2);
        verticalLayout_25->setContentsMargins(2, 2, 2, 2);
        verticalLayout_25->setObjectName(QStringLiteral("verticalLayout_25"));
        verticalLayout_25->setContentsMargins(2, 2, 2, 2);
        scrollArea_primitives = new QScrollArea(tab_primitives);
        scrollArea_primitives->setObjectName(QStringLiteral("scrollArea_primitives"));
        scrollArea_primitives->setWidgetResizable(true);
        scrollAreaWidgetContents_primitives = new QWidget();
        scrollAreaWidgetContents_primitives->setObjectName(QStringLiteral("scrollAreaWidgetContents_primitives"));
        scrollAreaWidgetContents_primitives->setGeometry(QRect(0, 0, 289, 360));
        verticalLayout_74 = new QVBoxLayout(scrollAreaWidgetContents_primitives);
        verticalLayout_74->setSpacing(2);
        verticalLayout_74->setContentsMargins(2, 2, 2, 2);
        verticalLayout_74->setObjectName(QStringLiteral("verticalLayout_74"));
        verticalLayout_74->setContentsMargins(2, 2, 2, 2);
        gridLayout_23 = new QGridLayout();
        gridLayout_23->setSpacing(2);
        gridLayout_23->setObjectName(QStringLiteral("gridLayout_23"));
        pushButton_add_primitive_cylinder = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_cylinder->setObjectName(QStringLiteral("pushButton_add_primitive_cylinder"));
        QSizePolicy sizePolicy4(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(1);
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_cylinder->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_cylinder->setSizePolicy(sizePolicy4);
        QIcon icon19;
        icon19.addFile(QStringLiteral(":/primitives/icons/cylinder.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_cylinder->setIcon(icon19);
        pushButton_add_primitive_cylinder->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_cylinder, 2, 0, 1, 1);

        pushButton_add_primitive_cone = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_cone->setObjectName(QStringLiteral("pushButton_add_primitive_cone"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_cone->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_cone->setSizePolicy(sizePolicy4);
        QIcon icon20;
        icon20.addFile(QStringLiteral(":/primitives/icons/cone.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_cone->setIcon(icon20);
        pushButton_add_primitive_cone->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_cone, 2, 1, 1, 1);

        pushButton_add_primitive_rectangle = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_rectangle->setObjectName(QStringLiteral("pushButton_add_primitive_rectangle"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_rectangle->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_rectangle->setSizePolicy(sizePolicy4);
        QIcon icon21;
        icon21.addFile(QStringLiteral(":/primitives/icons/rectangle.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_rectangle->setIcon(icon21);
        pushButton_add_primitive_rectangle->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_rectangle, 0, 0, 1, 1);

        pushButton_add_primitive_circle = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_circle->setObjectName(QStringLiteral("pushButton_add_primitive_circle"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_circle->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_circle->setSizePolicy(sizePolicy4);
        QIcon icon22;
        icon22.addFile(QStringLiteral(":/primitives/icons/circle.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_circle->setIcon(icon22);
        pushButton_add_primitive_circle->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_circle, 0, 1, 1, 1);

        pushButton_add_primitive_box = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_box->setObjectName(QStringLiteral("pushButton_add_primitive_box"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_box->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_box->setSizePolicy(sizePolicy4);
        QIcon icon23;
        icon23.addFile(QStringLiteral(":/primitives/icons/box.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_box->setIcon(icon23);
        pushButton_add_primitive_box->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_box, 0, 2, 1, 1);

        pushButton_add_primitive_water = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_water->setObjectName(QStringLiteral("pushButton_add_primitive_water"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_water->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_water->setSizePolicy(sizePolicy4);
        QIcon icon24;
        icon24.addFile(QStringLiteral(":/primitives/icons/water.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_water->setIcon(icon24);
        pushButton_add_primitive_water->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_water, 3, 2, 1, 1);

        pushButton_add_primitive_plane = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_plane->setObjectName(QStringLiteral("pushButton_add_primitive_plane"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_plane->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_plane->setSizePolicy(sizePolicy4);
        QIcon icon25;
        icon25.addFile(QStringLiteral(":/primitives/icons/plane.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_plane->setIcon(icon25);
        pushButton_add_primitive_plane->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_plane, 3, 1, 1, 1);

        pushButton_add_primitive_torus = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_torus->setObjectName(QStringLiteral("pushButton_add_primitive_torus"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_torus->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_torus->setSizePolicy(sizePolicy4);
        QIcon icon26;
        icon26.addFile(QStringLiteral(":/primitives/icons/torus.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_torus->setIcon(icon26);
        pushButton_add_primitive_torus->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_torus, 3, 0, 1, 1);

        pushButton_add_primitive_sphere = new QPushButton(scrollAreaWidgetContents_primitives);
        pushButton_add_primitive_sphere->setObjectName(QStringLiteral("pushButton_add_primitive_sphere"));
        sizePolicy4.setHeightForWidth(pushButton_add_primitive_sphere->sizePolicy().hasHeightForWidth());
        pushButton_add_primitive_sphere->setSizePolicy(sizePolicy4);
        QIcon icon27;
        icon27.addFile(QStringLiteral(":/primitives/icons/sphere.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_add_primitive_sphere->setIcon(icon27);
        pushButton_add_primitive_sphere->setIconSize(QSize(32, 32));

        gridLayout_23->addWidget(pushButton_add_primitive_sphere, 2, 2, 1, 1);


        verticalLayout_74->addLayout(gridLayout_23);

        gridLayout_37 = new QGridLayout();
        gridLayout_37->setSpacing(2);
        gridLayout_37->setObjectName(QStringLiteral("gridLayout_37"));
        vect3_all_primitives_position_z = new MyLineEdit(scrollAreaWidgetContents_primitives);
        vect3_all_primitives_position_z->setObjectName(QStringLiteral("vect3_all_primitives_position_z"));

        gridLayout_37->addWidget(vect3_all_primitives_position_z, 2, 2, 1, 1);

        spinboxd3_all_primitives_rotation_x = new MyDoubleSpinBox(scrollAreaWidgetContents_primitives);
        spinboxd3_all_primitives_rotation_x->setObjectName(QStringLiteral("spinboxd3_all_primitives_rotation_x"));
        spinboxd3_all_primitives_rotation_x->setDecimals(2);
        spinboxd3_all_primitives_rotation_x->setMinimum(-36000);
        spinboxd3_all_primitives_rotation_x->setMaximum(36000);
        spinboxd3_all_primitives_rotation_x->setSingleStep(0.1);

        gridLayout_37->addWidget(spinboxd3_all_primitives_rotation_x, 3, 2, 1, 1);

        label_50 = new QLabel(scrollAreaWidgetContents_primitives);
        label_50->setObjectName(QStringLiteral("label_50"));

        gridLayout_37->addWidget(label_50, 4, 0, 1, 1);

        dial3_all_primitives_rotation_z = new QDial(scrollAreaWidgetContents_primitives);
        dial3_all_primitives_rotation_z->setObjectName(QStringLiteral("dial3_all_primitives_rotation_z"));
        dial3_all_primitives_rotation_z->setMinimum(-18000);
        dial3_all_primitives_rotation_z->setMaximum(18000);
        dial3_all_primitives_rotation_z->setWrapping(true);

        gridLayout_37->addWidget(dial3_all_primitives_rotation_z, 5, 1, 1, 1);

        label_141 = new QLabel(scrollAreaWidgetContents_primitives);
        label_141->setObjectName(QStringLiteral("label_141"));
        sizePolicy3.setHeightForWidth(label_141->sizePolicy().hasHeightForWidth());
        label_141->setSizePolicy(sizePolicy3);
        label_141->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_37->addWidget(label_141, 2, 1, 1, 1);

        label_142 = new QLabel(scrollAreaWidgetContents_primitives);
        label_142->setObjectName(QStringLiteral("label_142"));
        sizePolicy3.setHeightForWidth(label_142->sizePolicy().hasHeightForWidth());
        label_142->setSizePolicy(sizePolicy3);
        label_142->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_37->addWidget(label_142, 0, 1, 1, 1);

        vect3_all_primitives_position_x = new MyLineEdit(scrollAreaWidgetContents_primitives);
        vect3_all_primitives_position_x->setObjectName(QStringLiteral("vect3_all_primitives_position_x"));

        gridLayout_37->addWidget(vect3_all_primitives_position_x, 0, 2, 1, 1);

        vect3_all_primitives_position_y = new MyLineEdit(scrollAreaWidgetContents_primitives);
        vect3_all_primitives_position_y->setObjectName(QStringLiteral("vect3_all_primitives_position_y"));

        gridLayout_37->addWidget(vect3_all_primitives_position_y, 1, 2, 1, 1);

        label_49 = new QLabel(scrollAreaWidgetContents_primitives);
        label_49->setObjectName(QStringLiteral("label_49"));

        gridLayout_37->addWidget(label_49, 3, 0, 1, 1);

        label_144 = new QLabel(scrollAreaWidgetContents_primitives);
        label_144->setObjectName(QStringLiteral("label_144"));
        sizePolicy3.setHeightForWidth(label_144->sizePolicy().hasHeightForWidth());
        label_144->setSizePolicy(sizePolicy3);
        label_144->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_37->addWidget(label_144, 1, 1, 1, 1);

        dial3_all_primitives_rotation_y = new QDial(scrollAreaWidgetContents_primitives);
        dial3_all_primitives_rotation_y->setObjectName(QStringLiteral("dial3_all_primitives_rotation_y"));
        dial3_all_primitives_rotation_y->setMinimum(-18000);
        dial3_all_primitives_rotation_y->setMaximum(18000);
        dial3_all_primitives_rotation_y->setWrapping(true);

        gridLayout_37->addWidget(dial3_all_primitives_rotation_y, 4, 1, 1, 1);

        dial3_all_primitives_rotation_x = new QDial(scrollAreaWidgetContents_primitives);
        dial3_all_primitives_rotation_x->setObjectName(QStringLiteral("dial3_all_primitives_rotation_x"));
        dial3_all_primitives_rotation_x->setMinimum(-18000);
        dial3_all_primitives_rotation_x->setMaximum(18000);
        dial3_all_primitives_rotation_x->setWrapping(true);

        gridLayout_37->addWidget(dial3_all_primitives_rotation_x, 3, 1, 1, 1);

        spinboxd3_all_primitives_rotation_y = new MyDoubleSpinBox(scrollAreaWidgetContents_primitives);
        spinboxd3_all_primitives_rotation_y->setObjectName(QStringLiteral("spinboxd3_all_primitives_rotation_y"));
        spinboxd3_all_primitives_rotation_y->setDecimals(2);
        spinboxd3_all_primitives_rotation_y->setMinimum(-36000);
        spinboxd3_all_primitives_rotation_y->setMaximum(36000);
        spinboxd3_all_primitives_rotation_y->setSingleStep(0.1);

        gridLayout_37->addWidget(spinboxd3_all_primitives_rotation_y, 4, 2, 1, 1);

        spinboxd3_all_primitives_rotation_z = new MyDoubleSpinBox(scrollAreaWidgetContents_primitives);
        spinboxd3_all_primitives_rotation_z->setObjectName(QStringLiteral("spinboxd3_all_primitives_rotation_z"));
        spinboxd3_all_primitives_rotation_z->setDecimals(2);
        spinboxd3_all_primitives_rotation_z->setMinimum(-36000);
        spinboxd3_all_primitives_rotation_z->setMaximum(36000);
        spinboxd3_all_primitives_rotation_z->setSingleStep(0.1);

        gridLayout_37->addWidget(spinboxd3_all_primitives_rotation_z, 5, 2, 1, 1);

        label_51 = new QLabel(scrollAreaWidgetContents_primitives);
        label_51->setObjectName(QStringLiteral("label_51"));

        gridLayout_37->addWidget(label_51, 5, 0, 1, 1);

        label_143 = new QLabel(scrollAreaWidgetContents_primitives);
        label_143->setObjectName(QStringLiteral("label_143"));

        gridLayout_37->addWidget(label_143, 0, 0, 3, 1);


        verticalLayout_74->addLayout(gridLayout_37);

        verticalLayout_primitives = new QVBoxLayout();
        verticalLayout_primitives->setSpacing(2);
        verticalLayout_primitives->setObjectName(QStringLiteral("verticalLayout_primitives"));

        verticalLayout_74->addLayout(verticalLayout_primitives);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_74->addItem(verticalSpacer_9);

        scrollArea_primitives->setWidget(scrollAreaWidgetContents_primitives);

        verticalLayout_25->addWidget(scrollArea_primitives);

        tabWidget_fractal->addTab(tab_primitives, QString());

        verticalLayout_59->addWidget(tabWidget_fractal);

        scrollArea_5->setWidget(scrollAreaWidgetContents_6);

        verticalLayout_7->addWidget(scrollArea_5);

        dockWidget_fractal->setWidget(dockWidgetContents_2);
        RenderWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidget_fractal);
        dockWidget_rendering_engine = new QDockWidget(RenderWindow);
        dockWidget_rendering_engine->setObjectName(QStringLiteral("dockWidget_rendering_engine"));
        dockWidget_rendering_engine->setFont(font2);
        dockWidget_rendering_engine->setFeatures(QDockWidget::DockWidgetFloatable|QDockWidget::DockWidgetMovable);
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName(QStringLiteral("dockWidgetContents"));
        verticalLayout_42 = new QVBoxLayout(dockWidgetContents);
        verticalLayout_42->setSpacing(2);
        verticalLayout_42->setContentsMargins(2, 2, 2, 2);
        verticalLayout_42->setObjectName(QStringLiteral("verticalLayout_42"));
        verticalLayout_42->setContentsMargins(2, 2, 2, 2);
        scrollArea_3 = new QScrollArea(dockWidgetContents);
        scrollArea_3->setObjectName(QStringLiteral("scrollArea_3"));
        scrollArea_3->setWidgetResizable(true);
        scrollAreaWidgetContents_4 = new QWidget();
        scrollAreaWidgetContents_4->setObjectName(QStringLiteral("scrollAreaWidgetContents_4"));
        scrollAreaWidgetContents_4->setGeometry(QRect(0, -408, 339, 947));
        verticalLayout_46 = new QVBoxLayout(scrollAreaWidgetContents_4);
        verticalLayout_46->setSpacing(2);
        verticalLayout_46->setContentsMargins(2, 2, 2, 2);
        verticalLayout_46->setObjectName(QStringLiteral("verticalLayout_46"));
        verticalLayout_46->setContentsMargins(2, 2, 2, 2);
        groupBox_4 = new QGroupBox(scrollAreaWidgetContents_4);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        verticalLayout_43 = new QVBoxLayout(groupBox_4);
        verticalLayout_43->setSpacing(2);
        verticalLayout_43->setContentsMargins(2, 2, 2, 2);
        verticalLayout_43->setObjectName(QStringLiteral("verticalLayout_43"));
        verticalLayout_43->setContentsMargins(2, 2, 2, 2);
        gridLayout_19 = new QGridLayout();
        gridLayout_19->setSpacing(2);
        gridLayout_19->setObjectName(QStringLiteral("gridLayout_19"));
        label_103 = new QLabel(groupBox_4);
        label_103->setObjectName(QStringLiteral("label_103"));

        gridLayout_19->addWidget(label_103, 0, 0, 2, 1);

        sliderInt_N = new QSlider(groupBox_4);
        sliderInt_N->setObjectName(QStringLiteral("sliderInt_N"));
        sliderInt_N->setMinimum(1);
        sliderInt_N->setMaximum(250);
        sliderInt_N->setSingleStep(8);
        sliderInt_N->setPageStep(64);
        sliderInt_N->setOrientation(Qt::Horizontal);

        gridLayout_19->addWidget(sliderInt_N, 1, 1, 1, 1);

        logedit_view_distance_min = new MyLineEdit(groupBox_4);
        logedit_view_distance_min->setObjectName(QStringLiteral("logedit_view_distance_min"));
        sizePolicy1.setHeightForWidth(logedit_view_distance_min->sizePolicy().hasHeightForWidth());
        logedit_view_distance_min->setSizePolicy(sizePolicy1);

        gridLayout_19->addWidget(logedit_view_distance_min, 6, 2, 1, 1);

        checkBox_iteration_threshold_mode = new MyCheckBox(groupBox_4);
        checkBox_iteration_threshold_mode->setObjectName(QStringLiteral("checkBox_iteration_threshold_mode"));

        gridLayout_19->addWidget(checkBox_iteration_threshold_mode, 7, 0, 1, 3);

        checkBox_interior_mode = new MyCheckBox(groupBox_4);
        checkBox_interior_mode->setObjectName(QStringLiteral("checkBox_interior_mode"));

        gridLayout_19->addWidget(checkBox_interior_mode, 8, 0, 1, 3);

        logedit_DE_factor = new MyLineEdit(groupBox_4);
        logedit_DE_factor->setObjectName(QStringLiteral("logedit_DE_factor"));
        sizePolicy1.setHeightForWidth(logedit_DE_factor->sizePolicy().hasHeightForWidth());
        logedit_DE_factor->setSizePolicy(sizePolicy1);

        gridLayout_19->addWidget(logedit_DE_factor, 3, 2, 1, 1);

        label_105 = new QLabel(groupBox_4);
        label_105->setObjectName(QStringLiteral("label_105"));

        gridLayout_19->addWidget(label_105, 3, 0, 1, 1);

        label_104 = new QLabel(groupBox_4);
        label_104->setObjectName(QStringLiteral("label_104"));

        gridLayout_19->addWidget(label_104, 2, 0, 1, 1);

        logslider_smoothness = new QSlider(groupBox_4);
        logslider_smoothness->setObjectName(QStringLiteral("logslider_smoothness"));
        sizePolicy1.setHeightForWidth(logslider_smoothness->sizePolicy().hasHeightForWidth());
        logslider_smoothness->setSizePolicy(sizePolicy1);
        logslider_smoothness->setSizeIncrement(QSize(0, 0));
        logslider_smoothness->setMinimum(-300);
        logslider_smoothness->setMaximum(300);
        logslider_smoothness->setOrientation(Qt::Horizontal);

        gridLayout_19->addWidget(logslider_smoothness, 4, 1, 1, 1);

        label_108 = new QLabel(groupBox_4);
        label_108->setObjectName(QStringLiteral("label_108"));

        gridLayout_19->addWidget(label_108, 6, 0, 1, 1);

        label_107 = new QLabel(groupBox_4);
        label_107->setObjectName(QStringLiteral("label_107"));

        gridLayout_19->addWidget(label_107, 5, 0, 1, 1);

        label_106 = new QLabel(groupBox_4);
        label_106->setObjectName(QStringLiteral("label_106"));

        gridLayout_19->addWidget(label_106, 4, 0, 1, 1);

        checkBox_slow_shading = new MyCheckBox(groupBox_4);
        checkBox_slow_shading->setObjectName(QStringLiteral("checkBox_slow_shading"));

        gridLayout_19->addWidget(checkBox_slow_shading, 9, 0, 1, 3);

        spinboxInt_N = new MySpinBox(groupBox_4);
        spinboxInt_N->setObjectName(QStringLiteral("spinboxInt_N"));
        spinboxInt_N->setMinimum(1);
        spinboxInt_N->setMaximum(500);

        gridLayout_19->addWidget(spinboxInt_N, 1, 2, 1, 1);

        logedit_smoothness = new MyLineEdit(groupBox_4);
        logedit_smoothness->setObjectName(QStringLiteral("logedit_smoothness"));
        sizePolicy1.setHeightForWidth(logedit_smoothness->sizePolicy().hasHeightForWidth());
        logedit_smoothness->setSizePolicy(sizePolicy1);

        gridLayout_19->addWidget(logedit_smoothness, 4, 2, 1, 1);

        logslider_view_distance_max = new QSlider(groupBox_4);
        logslider_view_distance_max->setObjectName(QStringLiteral("logslider_view_distance_max"));
        sizePolicy1.setHeightForWidth(logslider_view_distance_max->sizePolicy().hasHeightForWidth());
        logslider_view_distance_max->setSizePolicy(sizePolicy1);
        logslider_view_distance_max->setSizeIncrement(QSize(0, 0));
        logslider_view_distance_max->setMinimum(-1500);
        logslider_view_distance_max->setMaximum(400);
        logslider_view_distance_max->setOrientation(Qt::Horizontal);

        gridLayout_19->addWidget(logslider_view_distance_max, 5, 1, 1, 1);

        logedit_detail_level = new MyLineEdit(groupBox_4);
        logedit_detail_level->setObjectName(QStringLiteral("logedit_detail_level"));
        sizePolicy1.setHeightForWidth(logedit_detail_level->sizePolicy().hasHeightForWidth());
        logedit_detail_level->setSizePolicy(sizePolicy1);

        gridLayout_19->addWidget(logedit_detail_level, 2, 2, 1, 1);

        logedit_view_distance_max = new MyLineEdit(groupBox_4);
        logedit_view_distance_max->setObjectName(QStringLiteral("logedit_view_distance_max"));
        sizePolicy1.setHeightForWidth(logedit_view_distance_max->sizePolicy().hasHeightForWidth());
        logedit_view_distance_max->setSizePolicy(sizePolicy1);

        gridLayout_19->addWidget(logedit_view_distance_max, 5, 2, 1, 1);

        logslider_view_distance_min = new QSlider(groupBox_4);
        logslider_view_distance_min->setObjectName(QStringLiteral("logslider_view_distance_min"));
        sizePolicy1.setHeightForWidth(logslider_view_distance_min->sizePolicy().hasHeightForWidth());
        logslider_view_distance_min->setSizePolicy(sizePolicy1);
        logslider_view_distance_min->setSizeIncrement(QSize(0, 0));
        logslider_view_distance_min->setMinimum(-1500);
        logslider_view_distance_min->setMaximum(400);
        logslider_view_distance_min->setOrientation(Qt::Horizontal);

        gridLayout_19->addWidget(logslider_view_distance_min, 6, 1, 1, 1);

        logslider_DE_factor = new QSlider(groupBox_4);
        logslider_DE_factor->setObjectName(QStringLiteral("logslider_DE_factor"));
        sizePolicy1.setHeightForWidth(logslider_DE_factor->sizePolicy().hasHeightForWidth());
        logslider_DE_factor->setSizePolicy(sizePolicy1);
        logslider_DE_factor->setSizeIncrement(QSize(0, 0));
        logslider_DE_factor->setMinimum(-200);
        logslider_DE_factor->setMaximum(200);
        logslider_DE_factor->setOrientation(Qt::Horizontal);

        gridLayout_19->addWidget(logslider_DE_factor, 3, 1, 1, 1);

        groupCheck_constant_DE_threshold = new QGroupBox(groupBox_4);
        groupCheck_constant_DE_threshold->setObjectName(QStringLiteral("groupCheck_constant_DE_threshold"));
        groupCheck_constant_DE_threshold->setCheckable(true);
        groupCheck_constant_DE_threshold->setChecked(true);
        verticalLayout_44 = new QVBoxLayout(groupCheck_constant_DE_threshold);
        verticalLayout_44->setSpacing(2);
        verticalLayout_44->setContentsMargins(2, 2, 2, 2);
        verticalLayout_44->setObjectName(QStringLiteral("verticalLayout_44"));
        verticalLayout_44->setContentsMargins(2, 2, 2, 2);
        gridLayout_20 = new QGridLayout();
        gridLayout_20->setSpacing(2);
        gridLayout_20->setObjectName(QStringLiteral("gridLayout_20"));
        label_99 = new QLabel(groupCheck_constant_DE_threshold);
        label_99->setObjectName(QStringLiteral("label_99"));

        gridLayout_20->addWidget(label_99, 0, 0, 1, 1);

        logslider_DE_thresh = new QSlider(groupCheck_constant_DE_threshold);
        logslider_DE_thresh->setObjectName(QStringLiteral("logslider_DE_thresh"));
        sizePolicy1.setHeightForWidth(logslider_DE_thresh->sizePolicy().hasHeightForWidth());
        logslider_DE_thresh->setSizePolicy(sizePolicy1);
        logslider_DE_thresh->setSizeIncrement(QSize(0, 0));
        logslider_DE_thresh->setMinimum(-1500);
        logslider_DE_thresh->setMaximum(400);
        logslider_DE_thresh->setOrientation(Qt::Horizontal);

        gridLayout_20->addWidget(logslider_DE_thresh, 0, 1, 1, 1);

        logedit_DE_thresh = new MyLineEdit(groupCheck_constant_DE_threshold);
        logedit_DE_thresh->setObjectName(QStringLiteral("logedit_DE_thresh"));
        sizePolicy1.setHeightForWidth(logedit_DE_thresh->sizePolicy().hasHeightForWidth());
        logedit_DE_thresh->setSizePolicy(sizePolicy1);

        gridLayout_20->addWidget(logedit_DE_thresh, 0, 2, 1, 1);


        verticalLayout_44->addLayout(gridLayout_20);


        gridLayout_19->addWidget(groupCheck_constant_DE_threshold, 10, 0, 1, 3);

        logslider_detail_level = new QSlider(groupBox_4);
        logslider_detail_level->setObjectName(QStringLiteral("logslider_detail_level"));
        sizePolicy1.setHeightForWidth(logslider_detail_level->sizePolicy().hasHeightForWidth());
        logslider_detail_level->setSizePolicy(sizePolicy1);
        logslider_detail_level->setSizeIncrement(QSize(0, 0));
        logslider_detail_level->setMinimum(-300);
        logslider_detail_level->setMaximum(300);
        logslider_detail_level->setOrientation(Qt::Horizontal);

        gridLayout_19->addWidget(logslider_detail_level, 2, 1, 1, 1);


        verticalLayout_43->addLayout(gridLayout_19);


        verticalLayout_46->addWidget(groupBox_4);

        groupCheck_limits_enabled = new MyGroupBox(scrollAreaWidgetContents_4);
        groupCheck_limits_enabled->setObjectName(QStringLiteral("groupCheck_limits_enabled"));
        groupCheck_limits_enabled->setCheckable(true);
        verticalLayout_45 = new QVBoxLayout(groupCheck_limits_enabled);
        verticalLayout_45->setSpacing(2);
        verticalLayout_45->setContentsMargins(2, 2, 2, 2);
        verticalLayout_45->setObjectName(QStringLiteral("verticalLayout_45"));
        verticalLayout_45->setContentsMargins(2, 2, 2, 2);
        gridLayout_21 = new QGridLayout();
        gridLayout_21->setSpacing(2);
        gridLayout_21->setObjectName(QStringLiteral("gridLayout_21"));
        label_110 = new QLabel(groupCheck_limits_enabled);
        label_110->setObjectName(QStringLiteral("label_110"));
        sizePolicy3.setHeightForWidth(label_110->sizePolicy().hasHeightForWidth());
        label_110->setSizePolicy(sizePolicy3);
        label_110->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_21->addWidget(label_110, 0, 1, 1, 1);

        vect3_limit_max_x = new MyLineEdit(groupCheck_limits_enabled);
        vect3_limit_max_x->setObjectName(QStringLiteral("vect3_limit_max_x"));

        gridLayout_21->addWidget(vect3_limit_max_x, 3, 2, 1, 1);

        vect3_limit_min_z = new MyLineEdit(groupCheck_limits_enabled);
        vect3_limit_min_z->setObjectName(QStringLiteral("vect3_limit_min_z"));

        gridLayout_21->addWidget(vect3_limit_min_z, 2, 2, 1, 1);

        label_109 = new QLabel(groupCheck_limits_enabled);
        label_109->setObjectName(QStringLiteral("label_109"));

        gridLayout_21->addWidget(label_109, 0, 0, 1, 1);

        vect3_limit_min_y = new MyLineEdit(groupCheck_limits_enabled);
        vect3_limit_min_y->setObjectName(QStringLiteral("vect3_limit_min_y"));

        gridLayout_21->addWidget(vect3_limit_min_y, 1, 2, 1, 1);

        label_111 = new QLabel(groupCheck_limits_enabled);
        label_111->setObjectName(QStringLiteral("label_111"));
        sizePolicy3.setHeightForWidth(label_111->sizePolicy().hasHeightForWidth());
        label_111->setSizePolicy(sizePolicy3);
        label_111->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_21->addWidget(label_111, 1, 1, 1, 1);

        label_112 = new QLabel(groupCheck_limits_enabled);
        label_112->setObjectName(QStringLiteral("label_112"));
        sizePolicy3.setHeightForWidth(label_112->sizePolicy().hasHeightForWidth());
        label_112->setSizePolicy(sizePolicy3);
        label_112->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_21->addWidget(label_112, 2, 1, 1, 1);

        vect3_limit_min_x = new MyLineEdit(groupCheck_limits_enabled);
        vect3_limit_min_x->setObjectName(QStringLiteral("vect3_limit_min_x"));

        gridLayout_21->addWidget(vect3_limit_min_x, 0, 2, 1, 1);

        vect3_limit_max_y = new MyLineEdit(groupCheck_limits_enabled);
        vect3_limit_max_y->setObjectName(QStringLiteral("vect3_limit_max_y"));

        gridLayout_21->addWidget(vect3_limit_max_y, 4, 2, 1, 1);

        vect3_limit_max_z = new MyLineEdit(groupCheck_limits_enabled);
        vect3_limit_max_z->setObjectName(QStringLiteral("vect3_limit_max_z"));

        gridLayout_21->addWidget(vect3_limit_max_z, 5, 2, 1, 1);

        label_114 = new QLabel(groupCheck_limits_enabled);
        label_114->setObjectName(QStringLiteral("label_114"));

        gridLayout_21->addWidget(label_114, 3, 0, 1, 1);

        label_117 = new QLabel(groupCheck_limits_enabled);
        label_117->setObjectName(QStringLiteral("label_117"));
        sizePolicy3.setHeightForWidth(label_117->sizePolicy().hasHeightForWidth());
        label_117->setSizePolicy(sizePolicy3);
        label_117->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_21->addWidget(label_117, 3, 1, 1, 1);

        label_118 = new QLabel(groupCheck_limits_enabled);
        label_118->setObjectName(QStringLiteral("label_118"));
        sizePolicy3.setHeightForWidth(label_118->sizePolicy().hasHeightForWidth());
        label_118->setSizePolicy(sizePolicy3);
        label_118->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_21->addWidget(label_118, 4, 1, 1, 1);

        label_119 = new QLabel(groupCheck_limits_enabled);
        label_119->setObjectName(QStringLiteral("label_119"));
        sizePolicy3.setHeightForWidth(label_119->sizePolicy().hasHeightForWidth());
        label_119->setSizePolicy(sizePolicy3);
        label_119->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_21->addWidget(label_119, 5, 1, 1, 1);


        verticalLayout_45->addLayout(gridLayout_21);


        verticalLayout_46->addWidget(groupCheck_limits_enabled);

        group_netrender = new QGroupBox(scrollAreaWidgetContents_4);
        group_netrender->setObjectName(QStringLiteral("group_netrender"));
        group_netrender->setMinimumSize(QSize(335, 0));
        group_netrender->setCheckable(false);
        group_netrender->setChecked(false);
        verticalLayout_60 = new QVBoxLayout(group_netrender);
        verticalLayout_60->setSpacing(2);
        verticalLayout_60->setContentsMargins(2, 2, 2, 2);
        verticalLayout_60->setObjectName(QStringLiteral("verticalLayout_60"));
        verticalLayout_60->setContentsMargins(2, 2, 2, 2);
        gridLayout_29 = new QGridLayout();
        gridLayout_29->setSpacing(2);
        gridLayout_29->setObjectName(QStringLiteral("gridLayout_29"));
        label_176 = new QLabel(group_netrender);
        label_176->setObjectName(QStringLiteral("label_176"));

        gridLayout_29->addWidget(label_176, 0, 0, 1, 1);

        combo_netrender_mode = new QComboBox(group_netrender);
        combo_netrender_mode->setObjectName(QStringLiteral("combo_netrender_mode"));

        gridLayout_29->addWidget(combo_netrender_mode, 0, 1, 1, 1);


        verticalLayout_60->addLayout(gridLayout_29);

        groupBox_netrender_client_config = new QGroupBox(group_netrender);
        groupBox_netrender_client_config->setObjectName(QStringLiteral("groupBox_netrender_client_config"));
        groupBox_netrender_client_config->setEnabled(true);
        verticalLayout_62 = new QVBoxLayout(groupBox_netrender_client_config);
        verticalLayout_62->setSpacing(2);
        verticalLayout_62->setContentsMargins(2, 2, 2, 2);
        verticalLayout_62->setObjectName(QStringLiteral("verticalLayout_62"));
        verticalLayout_62->setContentsMargins(2, 2, 2, 2);
        gridLayout_31 = new QGridLayout();
        gridLayout_31->setSpacing(2);
        gridLayout_31->setObjectName(QStringLiteral("gridLayout_31"));
        text_netrender_client_remote_address = new MyLineEdit(groupBox_netrender_client_config);
        text_netrender_client_remote_address->setObjectName(QStringLiteral("text_netrender_client_remote_address"));

        gridLayout_31->addWidget(text_netrender_client_remote_address, 0, 1, 1, 1);

        label_178 = new QLabel(groupBox_netrender_client_config);
        label_178->setObjectName(QStringLiteral("label_178"));

        gridLayout_31->addWidget(label_178, 0, 0, 1, 1);

        label_212 = new QLabel(groupBox_netrender_client_config);
        label_212->setObjectName(QStringLiteral("label_212"));

        gridLayout_31->addWidget(label_212, 1, 0, 1, 1);

        spinboxInt_netrender_client_remote_port = new MySpinBox(groupBox_netrender_client_config);
        spinboxInt_netrender_client_remote_port->setObjectName(QStringLiteral("spinboxInt_netrender_client_remote_port"));
        spinboxInt_netrender_client_remote_port->setMinimum(1);
        spinboxInt_netrender_client_remote_port->setMaximum(99999);

        gridLayout_31->addWidget(spinboxInt_netrender_client_remote_port, 1, 1, 1, 1);


        verticalLayout_62->addLayout(gridLayout_31);

        gridLayout_50 = new QGridLayout();
        gridLayout_50->setSpacing(2);
        gridLayout_50->setObjectName(QStringLiteral("gridLayout_50"));
        bu_netrender_connect = new QPushButton(groupBox_netrender_client_config);
        bu_netrender_connect->setObjectName(QStringLiteral("bu_netrender_connect"));
        QIcon icon28;
        iconThemeName = QStringLiteral("media-playback-start");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon28 = QIcon::fromTheme(iconThemeName);
        } else {
            icon28.addFile(QStringLiteral(":/system/icons/media-playback-start.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        bu_netrender_connect->setIcon(icon28);

        gridLayout_50->addWidget(bu_netrender_connect, 0, 0, 1, 1);

        bu_netrender_disconnect = new QPushButton(groupBox_netrender_client_config);
        bu_netrender_disconnect->setObjectName(QStringLiteral("bu_netrender_disconnect"));
        bu_netrender_disconnect->setEnabled(false);
        QIcon icon29;
        iconThemeName = QStringLiteral("edit-delete");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon29 = QIcon::fromTheme(iconThemeName);
        } else {
            icon29.addFile(QStringLiteral(":/system/icons/edit-delete.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        bu_netrender_disconnect->setIcon(icon29);

        gridLayout_50->addWidget(bu_netrender_disconnect, 0, 1, 1, 1);


        verticalLayout_62->addLayout(gridLayout_50);

        gridLayout_501 = new QGridLayout();
        gridLayout_501->setSpacing(2);
        gridLayout_501->setObjectName(QStringLiteral("gridLayout_501"));
        label_ = new QLabel(groupBox_netrender_client_config);
        label_->setObjectName(QStringLiteral("label_"));

        gridLayout_501->addWidget(label_, 0, 0, 1, 1);

        label_netrender_client_status = new QLabel(groupBox_netrender_client_config);
        label_netrender_client_status->setObjectName(QStringLiteral("label_netrender_client_status"));

        gridLayout_501->addWidget(label_netrender_client_status, 0, 1, 1, 1);


        verticalLayout_62->addLayout(gridLayout_501);


        verticalLayout_60->addWidget(groupBox_netrender_client_config);

        groupBox_netrender_server_config = new QGroupBox(group_netrender);
        groupBox_netrender_server_config->setObjectName(QStringLiteral("groupBox_netrender_server_config"));
        verticalLayout_82 = new QVBoxLayout(groupBox_netrender_server_config);
        verticalLayout_82->setSpacing(2);
        verticalLayout_82->setContentsMargins(2, 2, 2, 2);
        verticalLayout_82->setObjectName(QStringLiteral("verticalLayout_82"));
        verticalLayout_82->setContentsMargins(2, 2, 2, 2);
        gridLayout_502 = new QGridLayout();
        gridLayout_502->setSpacing(2);
        gridLayout_502->setObjectName(QStringLiteral("gridLayout_502"));
        spinboxInt_netrender_server_local_port = new MySpinBox(groupBox_netrender_server_config);
        spinboxInt_netrender_server_local_port->setObjectName(QStringLiteral("spinboxInt_netrender_server_local_port"));
        spinboxInt_netrender_server_local_port->setMinimum(1);
        spinboxInt_netrender_server_local_port->setMaximum(99999);

        gridLayout_502->addWidget(spinboxInt_netrender_server_local_port, 0, 1, 1, 1);

        label_216 = new QLabel(groupBox_netrender_server_config);
        label_216->setObjectName(QStringLiteral("label_216"));

        gridLayout_502->addWidget(label_216, 0, 0, 1, 1);


        verticalLayout_82->addLayout(gridLayout_502);

        gridLayout_503 = new QGridLayout();
        gridLayout_503->setSpacing(2);
        gridLayout_503->setObjectName(QStringLiteral("gridLayout_503"));
        bu_netrender_start_server = new QPushButton(groupBox_netrender_server_config);
        bu_netrender_start_server->setObjectName(QStringLiteral("bu_netrender_start_server"));
        bu_netrender_start_server->setIcon(icon28);

        gridLayout_503->addWidget(bu_netrender_start_server, 0, 0, 1, 1);

        bu_netrender_stop_server = new QPushButton(groupBox_netrender_server_config);
        bu_netrender_stop_server->setObjectName(QStringLiteral("bu_netrender_stop_server"));
        bu_netrender_stop_server->setEnabled(false);
        bu_netrender_stop_server->setIcon(icon29);

        gridLayout_503->addWidget(bu_netrender_stop_server, 0, 1, 1, 1);


        verticalLayout_82->addLayout(gridLayout_503);

        gridLayout_504 = new QGridLayout();
        gridLayout_504->setSpacing(2);
        gridLayout_504->setObjectName(QStringLiteral("gridLayout_504"));
        label_1 = new QLabel(groupBox_netrender_server_config);
        label_1->setObjectName(QStringLiteral("label_1"));

        gridLayout_504->addWidget(label_1, 0, 0, 1, 1);

        label_netrender_server_status = new QLabel(groupBox_netrender_server_config);
        label_netrender_server_status->setObjectName(QStringLiteral("label_netrender_server_status"));

        gridLayout_504->addWidget(label_netrender_server_status, 0, 1, 1, 1);


        verticalLayout_82->addLayout(gridLayout_504);

        label_175 = new QLabel(groupBox_netrender_server_config);
        label_175->setObjectName(QStringLiteral("label_175"));

        verticalLayout_82->addWidget(label_175);

        tableWidget_netrender_connected_clients = new QTableWidget(groupBox_netrender_server_config);
        tableWidget_netrender_connected_clients->setObjectName(QStringLiteral("tableWidget_netrender_connected_clients"));
        QSizePolicy sizePolicy5(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy5.setHorizontalStretch(0);
        sizePolicy5.setVerticalStretch(0);
        sizePolicy5.setHeightForWidth(tableWidget_netrender_connected_clients->sizePolicy().hasHeightForWidth());
        tableWidget_netrender_connected_clients->setSizePolicy(sizePolicy5);

        verticalLayout_82->addWidget(tableWidget_netrender_connected_clients);


        verticalLayout_60->addWidget(groupBox_netrender_server_config);


        verticalLayout_46->addWidget(group_netrender);

        verticalSpacer_8 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_46->addItem(verticalSpacer_8);

        scrollArea_3->setWidget(scrollAreaWidgetContents_4);

        verticalLayout_42->addWidget(scrollArea_3);

        dockWidget_rendering_engine->setWidget(dockWidgetContents);
        RenderWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(1), dockWidget_rendering_engine);
        dockWidget_info = new QDockWidget(RenderWindow);
        dockWidget_info->setObjectName(QStringLiteral("dockWidget_info"));
        dockWidget_info->setEnabled(true);
        dockWidget_info->setFloating(false);
        dockWidgetContents_info = new QWidget();
        dockWidgetContents_info->setObjectName(QStringLiteral("dockWidgetContents_info"));
        horizontalLayout_13 = new QHBoxLayout(dockWidgetContents_info);
        horizontalLayout_13->setSpacing(2);
        horizontalLayout_13->setContentsMargins(2, 2, 2, 2);
        horizontalLayout_13->setObjectName(QStringLiteral("horizontalLayout_13"));
        horizontalLayout_13->setContentsMargins(2, 2, 2, 2);
        log_text = new MyLogWidget(dockWidgetContents_info);
        log_text->setObjectName(QStringLiteral("log_text"));

        horizontalLayout_13->addWidget(log_text);

        verticalLayout_histogram_de = new QVBoxLayout();
        verticalLayout_histogram_de->setSpacing(2);
        verticalLayout_histogram_de->setObjectName(QStringLiteral("verticalLayout_histogram_de"));
        label_174 = new QLabel(dockWidgetContents_info);
        label_174->setObjectName(QStringLiteral("label_174"));
        QSizePolicy sizePolicy6(QSizePolicy::Preferred, QSizePolicy::Maximum);
        sizePolicy6.setHorizontalStretch(0);
        sizePolicy6.setVerticalStretch(0);
        sizePolicy6.setHeightForWidth(label_174->sizePolicy().hasHeightForWidth());
        label_174->setSizePolicy(sizePolicy6);

        verticalLayout_histogram_de->addWidget(label_174);

        label_histogram_de = new MyHistogramLabel(dockWidgetContents_info);
        label_histogram_de->setObjectName(QStringLiteral("label_histogram_de"));

        verticalLayout_histogram_de->addWidget(label_histogram_de);


        horizontalLayout_13->addLayout(verticalLayout_histogram_de);

        verticalLayout_histogram_iter = new QVBoxLayout();
        verticalLayout_histogram_iter->setSpacing(2);
        verticalLayout_histogram_iter->setObjectName(QStringLiteral("verticalLayout_histogram_iter"));
        label_1741 = new QLabel(dockWidgetContents_info);
        label_1741->setObjectName(QStringLiteral("label_1741"));
        sizePolicy6.setHeightForWidth(label_1741->sizePolicy().hasHeightForWidth());
        label_1741->setSizePolicy(sizePolicy6);

        verticalLayout_histogram_iter->addWidget(label_1741);

        label_histogram_iter = new MyHistogramLabel(dockWidgetContents_info);
        label_histogram_iter->setObjectName(QStringLiteral("label_histogram_iter"));

        verticalLayout_histogram_iter->addWidget(label_histogram_iter);


        horizontalLayout_13->addLayout(verticalLayout_histogram_iter);

        horizontalLayout_13->setStretch(0, 6);
        horizontalLayout_13->setStretch(1, 4);
        horizontalLayout_13->setStretch(2, 4);
        dockWidget_info->setWidget(dockWidgetContents_info);
        RenderWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(4), dockWidget_info);
        dockWidget_animation = new QDockWidget(RenderWindow);
        dockWidget_animation->setObjectName(QStringLiteral("dockWidget_animation"));
        dockWidgetContents_animation = new QWidget();
        dockWidgetContents_animation->setObjectName(QStringLiteral("dockWidgetContents_animation"));
        horizontalLayout_14 = new QHBoxLayout(dockWidgetContents_animation);
        horizontalLayout_14->setSpacing(2);
        horizontalLayout_14->setContentsMargins(2, 2, 2, 2);
        horizontalLayout_14->setObjectName(QStringLiteral("horizontalLayout_14"));
        horizontalLayout_14->setContentsMargins(2, 2, 2, 2);
        verticalLayoutAnimation = new QVBoxLayout();
        verticalLayoutAnimation->setSpacing(2);
        verticalLayoutAnimation->setObjectName(QStringLiteral("verticalLayoutAnimation"));
        tabWidgetFlightKeyframe = new QTabWidget(dockWidgetContents_animation);
        tabWidgetFlightKeyframe->setObjectName(QStringLiteral("tabWidgetFlightKeyframe"));
        tab_flight_animation = new QWidget();
        tab_flight_animation->setObjectName(QStringLiteral("tab_flight_animation"));
        horizontalLayout_12 = new QHBoxLayout(tab_flight_animation);
        horizontalLayout_12->setSpacing(2);
        horizontalLayout_12->setContentsMargins(2, 2, 2, 2);
        horizontalLayout_12->setObjectName(QStringLiteral("horizontalLayout_12"));
        horizontalLayout_12->setContentsMargins(2, 2, 2, 2);
        verticalLayout_flight_animtion = new QVBoxLayout();
        verticalLayout_flight_animtion->setSpacing(2);
        verticalLayout_flight_animtion->setObjectName(QStringLiteral("verticalLayout_flight_animtion"));
        gridLayout_39 = new QGridLayout();
        gridLayout_39->setSpacing(2);
        gridLayout_39->setObjectName(QStringLiteral("gridLayout_39"));
        gridLayout_39->setContentsMargins(0, 0, 0, 0);
        pushButton_render_flight = new QPushButton(tab_flight_animation);
        pushButton_render_flight->setObjectName(QStringLiteral("pushButton_render_flight"));
        QIcon icon30;
        iconThemeName = QStringLiteral("video-x-generic");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon30 = QIcon::fromTheme(iconThemeName);
        } else {
            icon30.addFile(QStringLiteral(":/system/icons/video-x-generic.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_render_flight->setIcon(icon30);

        gridLayout_39->addWidget(pushButton_render_flight, 0, 0, 1, 1);

        pushButton_record_flight = new QPushButton(tab_flight_animation);
        pushButton_record_flight->setObjectName(QStringLiteral("pushButton_record_flight"));
        QIcon icon31;
        iconThemeName = QStringLiteral("media-record");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon31 = QIcon::fromTheme(iconThemeName);
        } else {
            icon31.addFile(QStringLiteral(":/system/icons/media-record.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_record_flight->setIcon(icon31);

        gridLayout_39->addWidget(pushButton_record_flight, 0, 1, 1, 1);

        pushButton_delete_all_images = new QPushButton(tab_flight_animation);
        pushButton_delete_all_images->setObjectName(QStringLiteral("pushButton_delete_all_images"));
        pushButton_delete_all_images->setIcon(icon29);

        gridLayout_39->addWidget(pushButton_delete_all_images, 1, 1, 1, 1);

        pushButton_show_animation = new QPushButton(tab_flight_animation);
        pushButton_show_animation->setObjectName(QStringLiteral("pushButton_show_animation"));
        pushButton_show_animation->setIcon(icon28);

        gridLayout_39->addWidget(pushButton_show_animation, 1, 0, 1, 1);

        pushButton_continue_recording = new QPushButton(tab_flight_animation);
        pushButton_continue_recording->setObjectName(QStringLiteral("pushButton_continue_recording"));
        pushButton_continue_recording->setIcon(icon31);

        gridLayout_39->addWidget(pushButton_continue_recording, 0, 2, 1, 1);

        pushButton_flight_refresh_table = new QPushButton(tab_flight_animation);
        pushButton_flight_refresh_table->setObjectName(QStringLiteral("pushButton_flight_refresh_table"));
        QIcon icon32;
        iconThemeName = QStringLiteral("view-refresh");
        if (QIcon::hasThemeIcon(iconThemeName)) {
            icon32 = QIcon::fromTheme(iconThemeName);
        } else {
            icon32.addFile(QStringLiteral(":/system/icons/view-refresh.svg"), QSize(), QIcon::Normal, QIcon::Off);
        }
        pushButton_flight_refresh_table->setIcon(icon32);

        gridLayout_39->addWidget(pushButton_flight_refresh_table, 1, 2, 1, 1);


        verticalLayout_flight_animtion->addLayout(gridLayout_39);

        scrollArea_flyght_animation_parameters = new QScrollArea(tab_flight_animation);
        scrollArea_flyght_animation_parameters->setObjectName(QStringLiteral("scrollArea_flyght_animation_parameters"));
        scrollArea_flyght_animation_parameters->setWidgetResizable(true);
        scrollAreaWidgetContents_flightAnimationParameters = new QWidget();
        scrollAreaWidgetContents_flightAnimationParameters->setObjectName(QStringLiteral("scrollAreaWidgetContents_flightAnimationParameters"));
        scrollAreaWidgetContents_flightAnimationParameters->setGeometry(QRect(0, 0, 355, 275));
        verticalLayout_79 = new QVBoxLayout(scrollAreaWidgetContents_flightAnimationParameters);
        verticalLayout_79->setSpacing(2);
        verticalLayout_79->setContentsMargins(2, 2, 2, 2);
        verticalLayout_79->setObjectName(QStringLiteral("verticalLayout_79"));
        verticalLayout_79->setContentsMargins(2, 2, 2, 2);
        gridLayout_38 = new QGridLayout();
        gridLayout_38->setSpacing(2);
        gridLayout_38->setObjectName(QStringLiteral("gridLayout_38"));
        label_150 = new QLabel(scrollAreaWidgetContents_flightAnimationParameters);
        label_150->setObjectName(QStringLiteral("label_150"));

        gridLayout_38->addWidget(label_150, 6, 0, 1, 1);

        label_147 = new QLabel(scrollAreaWidgetContents_flightAnimationParameters);
        label_147->setObjectName(QStringLiteral("label_147"));

        gridLayout_38->addWidget(label_147, 1, 0, 1, 1);

        label_146 = new QLabel(scrollAreaWidgetContents_flightAnimationParameters);
        label_146->setObjectName(QStringLiteral("label_146"));

        gridLayout_38->addWidget(label_146, 0, 0, 1, 1);

        label_148 = new QLabel(scrollAreaWidgetContents_flightAnimationParameters);
        label_148->setObjectName(QStringLiteral("label_148"));

        gridLayout_38->addWidget(label_148, 4, 0, 1, 1);

        comboBox_flight_speed_control = new QComboBox(scrollAreaWidgetContents_flightAnimationParameters);
        comboBox_flight_speed_control->setObjectName(QStringLiteral("comboBox_flight_speed_control"));

        gridLayout_38->addWidget(comboBox_flight_speed_control, 4, 1, 1, 1);

        text_anim_flight_dir = new MyLineEdit(scrollAreaWidgetContents_flightAnimationParameters);
        text_anim_flight_dir->setObjectName(QStringLiteral("text_anim_flight_dir"));

        gridLayout_38->addWidget(text_anim_flight_dir, 6, 1, 1, 1);

        button_selectAnimFlightImageDir = new QPushButton(scrollAreaWidgetContents_flightAnimationParameters);
        button_selectAnimFlightImageDir->setObjectName(QStringLiteral("button_selectAnimFlightImageDir"));

        gridLayout_38->addWidget(button_selectAnimFlightImageDir, 6, 2, 1, 1);

        logedit_flight_speed = new MyLineEdit(scrollAreaWidgetContents_flightAnimationParameters);
        logedit_flight_speed->setObjectName(QStringLiteral("logedit_flight_speed"));
        QSizePolicy sizePolicy7(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy7.setHorizontalStretch(1);
        sizePolicy7.setVerticalStretch(0);
        sizePolicy7.setHeightForWidth(logedit_flight_speed->sizePolicy().hasHeightForWidth());
        logedit_flight_speed->setSizePolicy(sizePolicy7);

        gridLayout_38->addWidget(logedit_flight_speed, 0, 2, 1, 1);

        logslider_flight_speed = new QSlider(scrollAreaWidgetContents_flightAnimationParameters);
        logslider_flight_speed->setObjectName(QStringLiteral("logslider_flight_speed"));
        QSizePolicy sizePolicy8(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy8.setHorizontalStretch(2);
        sizePolicy8.setVerticalStretch(0);
        sizePolicy8.setHeightForWidth(logslider_flight_speed->sizePolicy().hasHeightForWidth());
        logslider_flight_speed->setSizePolicy(sizePolicy8);
        logslider_flight_speed->setSizeIncrement(QSize(0, 0));
        logslider_flight_speed->setMinimum(-300);
        logslider_flight_speed->setMaximum(300);
        logslider_flight_speed->setOrientation(Qt::Horizontal);

        gridLayout_38->addWidget(logslider_flight_speed, 0, 1, 1, 1);

        slider_flight_inertia = new QSlider(scrollAreaWidgetContents_flightAnimationParameters);
        slider_flight_inertia->setObjectName(QStringLiteral("slider_flight_inertia"));
        slider_flight_inertia->setMaximum(5000);
        slider_flight_inertia->setSingleStep(1);
        slider_flight_inertia->setOrientation(Qt::Horizontal);

        gridLayout_38->addWidget(slider_flight_inertia, 1, 1, 1, 1);

        spinbox_flight_inertia = new MyDoubleSpinBox(scrollAreaWidgetContents_flightAnimationParameters);
        spinbox_flight_inertia->setObjectName(QStringLiteral("spinbox_flight_inertia"));
        spinbox_flight_inertia->setDecimals(2);
        spinbox_flight_inertia->setMaximum(1000);
        spinbox_flight_inertia->setSingleStep(0.1);

        gridLayout_38->addWidget(spinbox_flight_inertia, 1, 2, 1, 1);

        label_151 = new QLabel(scrollAreaWidgetContents_flightAnimationParameters);
        label_151->setObjectName(QStringLiteral("label_151"));

        gridLayout_38->addWidget(label_151, 5, 0, 1, 1);

        slider_flight_sec_per_frame = new QSlider(scrollAreaWidgetContents_flightAnimationParameters);
        slider_flight_sec_per_frame->setObjectName(QStringLiteral("slider_flight_sec_per_frame"));
        slider_flight_sec_per_frame->setMinimum(1);
        slider_flight_sec_per_frame->setMaximum(5000);
        slider_flight_sec_per_frame->setSingleStep(1);
        slider_flight_sec_per_frame->setOrientation(Qt::Horizontal);

        gridLayout_38->addWidget(slider_flight_sec_per_frame, 5, 1, 1, 1);

        spinbox_flight_sec_per_frame = new MyDoubleSpinBox(scrollAreaWidgetContents_flightAnimationParameters);
        spinbox_flight_sec_per_frame->setObjectName(QStringLiteral("spinbox_flight_sec_per_frame"));
        spinbox_flight_sec_per_frame->setDecimals(2);
        spinbox_flight_sec_per_frame->setMinimum(0.01);
        spinbox_flight_sec_per_frame->setMaximum(100);
        spinbox_flight_sec_per_frame->setSingleStep(0.1);

        gridLayout_38->addWidget(spinbox_flight_sec_per_frame, 5, 2, 1, 1);

        slider_flight_roll_speed = new QSlider(scrollAreaWidgetContents_flightAnimationParameters);
        slider_flight_roll_speed->setObjectName(QStringLiteral("slider_flight_roll_speed"));
        slider_flight_roll_speed->setMaximum(5000);
        slider_flight_roll_speed->setSingleStep(1);
        slider_flight_roll_speed->setOrientation(Qt::Horizontal);

        gridLayout_38->addWidget(slider_flight_roll_speed, 3, 1, 1, 1);

        spinbox_flight_rotation_speed = new MyDoubleSpinBox(scrollAreaWidgetContents_flightAnimationParameters);
        spinbox_flight_rotation_speed->setObjectName(QStringLiteral("spinbox_flight_rotation_speed"));
        spinbox_flight_rotation_speed->setDecimals(2);
        spinbox_flight_rotation_speed->setMaximum(1000);
        spinbox_flight_rotation_speed->setSingleStep(0.1);

        gridLayout_38->addWidget(spinbox_flight_rotation_speed, 2, 2, 1, 1);

        slider_flight_rotation_speed = new QSlider(scrollAreaWidgetContents_flightAnimationParameters);
        slider_flight_rotation_speed->setObjectName(QStringLiteral("slider_flight_rotation_speed"));
        slider_flight_rotation_speed->setMaximum(5000);
        slider_flight_rotation_speed->setSingleStep(1);
        slider_flight_rotation_speed->setOrientation(Qt::Horizontal);

        gridLayout_38->addWidget(slider_flight_rotation_speed, 2, 1, 1, 1);

        label_153 = new QLabel(scrollAreaWidgetContents_flightAnimationParameters);
        label_153->setObjectName(QStringLiteral("label_153"));

        gridLayout_38->addWidget(label_153, 3, 0, 1, 1);

        spinbox_flight_roll_speed = new MyDoubleSpinBox(scrollAreaWidgetContents_flightAnimationParameters);
        spinbox_flight_roll_speed->setObjectName(QStringLiteral("spinbox_flight_roll_speed"));
        spinbox_flight_roll_speed->setDecimals(2);
        spinbox_flight_roll_speed->setMaximum(1000);
        spinbox_flight_roll_speed->setSingleStep(0.1);

        gridLayout_38->addWidget(spinbox_flight_roll_speed, 3, 2, 1, 1);

        checkBox_flight_show_thumbnails = new MyCheckBox(scrollAreaWidgetContents_flightAnimationParameters);
        checkBox_flight_show_thumbnails->setObjectName(QStringLiteral("checkBox_flight_show_thumbnails"));

        gridLayout_38->addWidget(checkBox_flight_show_thumbnails, 7, 0, 1, 3);

        label_152 = new QLabel(scrollAreaWidgetContents_flightAnimationParameters);
        label_152->setObjectName(QStringLiteral("label_152"));

        gridLayout_38->addWidget(label_152, 2, 0, 1, 1);

        checkBox_flight_add_speeds = new MyCheckBox(scrollAreaWidgetContents_flightAnimationParameters);
        checkBox_flight_add_speeds->setObjectName(QStringLiteral("checkBox_flight_add_speeds"));

        gridLayout_38->addWidget(checkBox_flight_add_speeds, 8, 0, 1, 3);


        verticalLayout_79->addLayout(gridLayout_38);

        verticalSpacer_11 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_79->addItem(verticalSpacer_11);

        scrollArea_flyght_animation_parameters->setWidget(scrollAreaWidgetContents_flightAnimationParameters);

        verticalLayout_flight_animtion->addWidget(scrollArea_flyght_animation_parameters);


        horizontalLayout_12->addLayout(verticalLayout_flight_animtion);

        verticalLayout_table = new QVBoxLayout();
        verticalLayout_table->setSpacing(2);
        verticalLayout_table->setObjectName(QStringLiteral("verticalLayout_table"));
        tableWidget_flightAnimation = new MyTableWidgetAnim(tab_flight_animation);
        tableWidget_flightAnimation->setObjectName(QStringLiteral("tableWidget_flightAnimation"));
        QSizePolicy sizePolicy9(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy9.setHorizontalStretch(3);
        sizePolicy9.setVerticalStretch(0);
        sizePolicy9.setHeightForWidth(tableWidget_flightAnimation->sizePolicy().hasHeightForWidth());
        tableWidget_flightAnimation->setSizePolicy(sizePolicy9);
        tableWidget_flightAnimation->verticalHeader()->setDefaultSectionSize(20);

        verticalLayout_table->addWidget(tableWidget_flightAnimation);


        horizontalLayout_12->addLayout(verticalLayout_table);

        horizontalLayout_12->setStretch(1, 3);
        tabWidgetFlightKeyframe->addTab(tab_flight_animation, QString());
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        label_149 = new QLabel(tab_7);
        label_149->setObjectName(QStringLiteral("label_149"));
        label_149->setGeometry(QRect(10, 10, 171, 16));
        tabWidgetFlightKeyframe->addTab(tab_7, QString());

        verticalLayoutAnimation->addWidget(tabWidgetFlightKeyframe);


        horizontalLayout_14->addLayout(verticalLayoutAnimation);

        verticalLayout_75 = new QVBoxLayout();
        verticalLayout_75->setSpacing(2);
        verticalLayout_75->setObjectName(QStringLiteral("verticalLayout_75"));

        horizontalLayout_14->addLayout(verticalLayout_75);

        dockWidget_animation->setWidget(dockWidgetContents_animation);
        RenderWindow->addDockWidget(static_cast<Qt::DockWidgetArea>(8), dockWidget_animation);
        QWidget::setTabOrder(sliderInt_image_width, spinboxInt_image_width);
        QWidget::setTabOrder(spinboxInt_image_width, sliderInt_image_height);
        QWidget::setTabOrder(sliderInt_image_height, spinboxInt_image_height);
        QWidget::setTabOrder(spinboxInt_image_height, comboBox_image_proportion);
        QWidget::setTabOrder(comboBox_image_proportion, pushButton_resolution_preset_480);
        QWidget::setTabOrder(pushButton_resolution_preset_480, pushButton_resolution_preset_720);
        QWidget::setTabOrder(pushButton_resolution_preset_720, pushButton_resolution_preset_1080);
        QWidget::setTabOrder(pushButton_resolution_preset_1080, pushButton_resolution_preset_1440);
        QWidget::setTabOrder(pushButton_resolution_preset_1440, pushButton_resolution_preset_2160);
        QWidget::setTabOrder(pushButton_resolution_preset_2160, pushButton_resolution_preset_4320);
        QWidget::setTabOrder(pushButton_resolution_preset_4320, pushButton_resolution_preset_240);
        QWidget::setTabOrder(pushButton_resolution_preset_240, pushButton_resolution_preset_600);
        QWidget::setTabOrder(pushButton_resolution_preset_600, pushButton_resolution_preset_1200);
        QWidget::setTabOrder(pushButton_resolution_preset_1200, slider_brightness);
        QWidget::setTabOrder(slider_brightness, spinbox_brightness);
        QWidget::setTabOrder(spinbox_brightness, slider_contrast);
        QWidget::setTabOrder(slider_contrast, spinbox_contrast);
        QWidget::setTabOrder(spinbox_contrast, slider_gamma);
        QWidget::setTabOrder(slider_gamma, spinbox_gamma);
        QWidget::setTabOrder(spinbox_gamma, checkBox_hdr);
        QWidget::setTabOrder(checkBox_hdr, pushButton_apply_image_changes);
        QWidget::setTabOrder(pushButton_apply_image_changes, slider_fov);
        QWidget::setTabOrder(slider_fov, spinbox_fov);
        QWidget::setTabOrder(spinbox_fov, comboBox_perspective_type);
        QWidget::setTabOrder(comboBox_perspective_type, checkBox_legacy_coordinate_system);
        QWidget::setTabOrder(checkBox_legacy_coordinate_system, scrollArea_6);
        QWidget::setTabOrder(scrollArea_6, slider_shading);
        QWidget::setTabOrder(slider_shading, spinbox_shading);
        QWidget::setTabOrder(spinbox_shading, slider_specular);
        QWidget::setTabOrder(slider_specular, spinbox_specular);
        QWidget::setTabOrder(spinbox_specular, slider_ambient_occlusion);
        QWidget::setTabOrder(slider_ambient_occlusion, spinbox_ambient_occlusion);
        QWidget::setTabOrder(spinbox_ambient_occlusion, slider_reflect);
        QWidget::setTabOrder(slider_reflect, spinbox_reflect);
        QWidget::setTabOrder(spinbox_reflect, groupCheck_ambient_occlusion_enabled);
        QWidget::setTabOrder(groupCheck_ambient_occlusion_enabled, sliderInt_ambient_occlusion_quality);
        QWidget::setTabOrder(sliderInt_ambient_occlusion_quality, spinboxInt_ambient_occlusion_quality);
        QWidget::setTabOrder(spinboxInt_ambient_occlusion_quality, slider_ambient_occlusion_fast_tune);
        QWidget::setTabOrder(slider_ambient_occlusion_fast_tune, spinbox_ambient_occlusion_fast_tune);
        QWidget::setTabOrder(spinbox_ambient_occlusion_fast_tune, comboBox_ambient_occlusion_mode);
        QWidget::setTabOrder(comboBox_ambient_occlusion_mode, text_file_lightmap);
        QWidget::setTabOrder(text_file_lightmap, button_selectLightMapTexture);
        QWidget::setTabOrder(button_selectLightMapTexture, groupCheck_fractal_color);
        QWidget::setTabOrder(groupCheck_fractal_color, slider_coloring_palette_offset);
        QWidget::setTabOrder(slider_coloring_palette_offset, spinbox_coloring_palette_offset);
        QWidget::setTabOrder(spinbox_coloring_palette_offset, sliderInt_coloring_palette_size);
        QWidget::setTabOrder(sliderInt_coloring_palette_size, spinboxInt_coloring_palette_size);
        QWidget::setTabOrder(spinboxInt_coloring_palette_size, slider_coloring_saturation);
        QWidget::setTabOrder(slider_coloring_saturation, spinbox_coloring_saturation);
        QWidget::setTabOrder(spinbox_coloring_saturation, slider_coloring_speed);
        QWidget::setTabOrder(slider_coloring_speed, spinbox_coloring_speed);
        QWidget::setTabOrder(spinbox_coloring_speed, pushButton_randomize);
        QWidget::setTabOrder(pushButton_randomize, spinboxInt_coloring_random_seed);
        QWidget::setTabOrder(spinboxInt_coloring_random_seed, pushButton_randomPalette);
        QWidget::setTabOrder(pushButton_randomPalette, pushButton_getPaletteFromImage);
        QWidget::setTabOrder(pushButton_getPaletteFromImage, groupCheck_env_mapping_enable);
        QWidget::setTabOrder(groupCheck_env_mapping_enable, text_file_envmap);
        QWidget::setTabOrder(text_file_envmap, button_selectEnvMapTexture);
        QWidget::setTabOrder(button_selectEnvMapTexture, groupCheck_raytraced_reflections);
        QWidget::setTabOrder(groupCheck_raytraced_reflections, sliderInt_reflections_max);
        QWidget::setTabOrder(sliderInt_reflections_max, spinboxInt_reflections_max);
        QWidget::setTabOrder(spinboxInt_reflections_max, groupCheck_DOF_enabled);
        QWidget::setTabOrder(groupCheck_DOF_enabled, logslider_DOF_focus);
        QWidget::setTabOrder(logslider_DOF_focus, logedit_DOF_focus);
        QWidget::setTabOrder(logedit_DOF_focus, slider_DOF_radius);
        QWidget::setTabOrder(slider_DOF_radius, spinbox_DOF_radius);
        QWidget::setTabOrder(spinbox_DOF_radius, pushButton_DOF_update);
        QWidget::setTabOrder(pushButton_DOF_update, pushButton_DOF_set_focus);
        QWidget::setTabOrder(pushButton_DOF_set_focus, groupCheck_basic_fog_enabled);
        QWidget::setTabOrder(groupCheck_basic_fog_enabled, logslider_basic_fog_visibility);
        QWidget::setTabOrder(logslider_basic_fog_visibility, logedit_basic_fog_visibility);
        QWidget::setTabOrder(logedit_basic_fog_visibility, pushButton_set_fog_by_mouse);
        QWidget::setTabOrder(pushButton_set_fog_by_mouse, groupCheck_glow_enabled);
        QWidget::setTabOrder(groupCheck_glow_enabled, logslider_glow_intensity);
        QWidget::setTabOrder(logslider_glow_intensity, logedit_glow_intensity);
        QWidget::setTabOrder(logedit_glow_intensity, groupCheck_volumetric_fog_enabled);
        QWidget::setTabOrder(groupCheck_volumetric_fog_enabled, button_calculateFog);
        QWidget::setTabOrder(button_calculateFog, logslider_volumetric_fog_density);
        QWidget::setTabOrder(logslider_volumetric_fog_density, logedit_volumetric_fog_density);
        QWidget::setTabOrder(logedit_volumetric_fog_density, logslider_volumetric_fog_colour_1_distance);
        QWidget::setTabOrder(logslider_volumetric_fog_colour_1_distance, logedit_volumetric_fog_colour_1_distance);
        QWidget::setTabOrder(logedit_volumetric_fog_colour_1_distance, logslider_volumetric_fog_colour_2_distance);
        QWidget::setTabOrder(logslider_volumetric_fog_colour_2_distance, logedit_volumetric_fog_colour_2_distance);
        QWidget::setTabOrder(logedit_volumetric_fog_colour_2_distance, logslider_volumetric_fog_distance_factor);
        QWidget::setTabOrder(logslider_volumetric_fog_distance_factor, logedit_volumetric_fog_distance_factor);
        QWidget::setTabOrder(logedit_volumetric_fog_distance_factor, groupCheck_iteration_fog_enable);
        QWidget::setTabOrder(groupCheck_iteration_fog_enable, logslider_iteration_fog_opacity);
        QWidget::setTabOrder(logslider_iteration_fog_opacity, logedit_iteration_fog_opacity);
        QWidget::setTabOrder(logedit_iteration_fog_opacity, slider_iteration_fog_opacity_trim);
        QWidget::setTabOrder(slider_iteration_fog_opacity_trim, spinbox_iteration_fog_opacity_trim);
        QWidget::setTabOrder(spinbox_iteration_fog_opacity_trim, slider_iteration_fog_color_1_maxiter);
        QWidget::setTabOrder(slider_iteration_fog_color_1_maxiter, spinbox_iteration_fog_color_1_maxiter);
        QWidget::setTabOrder(spinbox_iteration_fog_color_1_maxiter, slider_iteration_fog_color_2_maxiter);
        QWidget::setTabOrder(slider_iteration_fog_color_2_maxiter, spinbox_iteration_fog_color_2_maxiter);
        QWidget::setTabOrder(spinbox_iteration_fog_color_2_maxiter, scrollArea_9);
        QWidget::setTabOrder(scrollArea_9, groupCheck_textured_background);
        QWidget::setTabOrder(groupCheck_textured_background, text_file_background);
        QWidget::setTabOrder(text_file_background, button_selectBackgroundTexture);
        QWidget::setTabOrder(button_selectBackgroundTexture, comboBox_textured_background_map_type);
        QWidget::setTabOrder(comboBox_textured_background_map_type, scrollArea_10);
        QWidget::setTabOrder(scrollArea_10, checkBox_shadows_enabled);
        QWidget::setTabOrder(checkBox_shadows_enabled, checkBox_penetrating_lights);
        QWidget::setTabOrder(checkBox_penetrating_lights, groupCheck_main_light_enable);
        QWidget::setTabOrder(groupCheck_main_light_enable, slider_main_light_intensity);
        QWidget::setTabOrder(slider_main_light_intensity, spinbox_main_light_intensity);
        QWidget::setTabOrder(spinbox_main_light_intensity, slider_main_light_visibility);
        QWidget::setTabOrder(slider_main_light_visibility, spinbox_main_light_visibility);
        QWidget::setTabOrder(spinbox_main_light_visibility, slider_main_light_visibility_size);
        QWidget::setTabOrder(slider_main_light_visibility_size, spinbox_main_light_visibility_size);
        QWidget::setTabOrder(spinbox_main_light_visibility_size, dial_main_light_alpha);
        QWidget::setTabOrder(dial_main_light_alpha, spinboxd_main_light_alpha);
        QWidget::setTabOrder(spinboxd_main_light_alpha, dial_main_light_beta);
        QWidget::setTabOrder(dial_main_light_beta, spinboxd_main_light_beta);
        QWidget::setTabOrder(spinboxd_main_light_beta, slider_shadows_cone_angle);
        QWidget::setTabOrder(slider_shadows_cone_angle, spinbox_shadows_cone_angle);
        QWidget::setTabOrder(spinbox_shadows_cone_angle, checkBox_main_light_position_relative);
        QWidget::setTabOrder(checkBox_main_light_position_relative, groupCheck_aux_light_enabled_1);
        QWidget::setTabOrder(groupCheck_aux_light_enabled_1, vect3_aux_light_position_1_x);
        QWidget::setTabOrder(vect3_aux_light_position_1_x, vect3_aux_light_position_1_y);
        QWidget::setTabOrder(vect3_aux_light_position_1_y, vect3_aux_light_position_1_z);
        QWidget::setTabOrder(vect3_aux_light_position_1_z, logedit_aux_light_intensity_1);
        QWidget::setTabOrder(logedit_aux_light_intensity_1, logslider_aux_light_intensity_1);
        QWidget::setTabOrder(logslider_aux_light_intensity_1, pushButton_place_light_by_mouse_1);
        QWidget::setTabOrder(pushButton_place_light_by_mouse_1, groupCheck_aux_light_enabled_2);
        QWidget::setTabOrder(groupCheck_aux_light_enabled_2, vect3_aux_light_position_2_x);
        QWidget::setTabOrder(vect3_aux_light_position_2_x, vect3_aux_light_position_2_y);
        QWidget::setTabOrder(vect3_aux_light_position_2_y, vect3_aux_light_position_2_z);
        QWidget::setTabOrder(vect3_aux_light_position_2_z, logedit_aux_light_intensity_2);
        QWidget::setTabOrder(logedit_aux_light_intensity_2, logslider_aux_light_intensity_2);
        QWidget::setTabOrder(logslider_aux_light_intensity_2, pushButton_place_light_by_mouse_2);
        QWidget::setTabOrder(pushButton_place_light_by_mouse_2, groupCheck_aux_light_enabled_3);
        QWidget::setTabOrder(groupCheck_aux_light_enabled_3, vect3_aux_light_position_3_x);
        QWidget::setTabOrder(vect3_aux_light_position_3_x, vect3_aux_light_position_3_y);
        QWidget::setTabOrder(vect3_aux_light_position_3_y, vect3_aux_light_position_3_z);
        QWidget::setTabOrder(vect3_aux_light_position_3_z, logedit_aux_light_intensity_3);
        QWidget::setTabOrder(logedit_aux_light_intensity_3, logslider_aux_light_intensity_3);
        QWidget::setTabOrder(logslider_aux_light_intensity_3, pushButton_place_light_by_mouse_3);
        QWidget::setTabOrder(pushButton_place_light_by_mouse_3, groupCheck_aux_light_enabled_4);
        QWidget::setTabOrder(groupCheck_aux_light_enabled_4, vect3_aux_light_position_4_x);
        QWidget::setTabOrder(vect3_aux_light_position_4_x, vect3_aux_light_position_4_y);
        QWidget::setTabOrder(vect3_aux_light_position_4_y, vect3_aux_light_position_4_z);
        QWidget::setTabOrder(vect3_aux_light_position_4_z, logedit_aux_light_intensity_4);
        QWidget::setTabOrder(logedit_aux_light_intensity_4, logslider_aux_light_intensity_4);
        QWidget::setTabOrder(logslider_aux_light_intensity_4, pushButton_place_light_by_mouse_4);
        QWidget::setTabOrder(pushButton_place_light_by_mouse_4, logslider_aux_light_visibility);
        QWidget::setTabOrder(logslider_aux_light_visibility, logedit_aux_light_visibility);
        QWidget::setTabOrder(logedit_aux_light_visibility, logslider_aux_light_visibility_size);
        QWidget::setTabOrder(logslider_aux_light_visibility_size, logedit_aux_light_visibility_size);
        QWidget::setTabOrder(logedit_aux_light_visibility_size, logslider_aux_light_manual_placement_dist);
        QWidget::setTabOrder(logslider_aux_light_manual_placement_dist, logedit_aux_light_manual_placement_dist);
        QWidget::setTabOrder(logedit_aux_light_manual_placement_dist, checkBox_main_light_volumetric_enabled);
        QWidget::setTabOrder(checkBox_main_light_volumetric_enabled, logslider_main_light_volumetric_intensity);
        QWidget::setTabOrder(logslider_main_light_volumetric_intensity, logedit_main_light_volumetric_intensity);
        QWidget::setTabOrder(logedit_main_light_volumetric_intensity, checkBox_aux_light_volumetric_enabled_1);
        QWidget::setTabOrder(checkBox_aux_light_volumetric_enabled_1, logslider_aux_light_volumetric_intensity_1);
        QWidget::setTabOrder(logslider_aux_light_volumetric_intensity_1, logedit_aux_light_volumetric_intensity_1);
        QWidget::setTabOrder(logedit_aux_light_volumetric_intensity_1, checkBox_aux_light_volumetric_enabled_2);
        QWidget::setTabOrder(checkBox_aux_light_volumetric_enabled_2, logslider_aux_light_volumetric_intensity_2);
        QWidget::setTabOrder(logslider_aux_light_volumetric_intensity_2, logedit_aux_light_volumetric_intensity_2);
        QWidget::setTabOrder(logedit_aux_light_volumetric_intensity_2, checkBox_aux_light_volumetric_enabled_3);
        QWidget::setTabOrder(checkBox_aux_light_volumetric_enabled_3, logslider_aux_light_volumetric_intensity_3);
        QWidget::setTabOrder(logslider_aux_light_volumetric_intensity_3, logedit_aux_light_volumetric_intensity_3);
        QWidget::setTabOrder(logedit_aux_light_volumetric_intensity_3, checkBox_aux_light_volumetric_enabled_4);
        QWidget::setTabOrder(checkBox_aux_light_volumetric_enabled_4, logslider_aux_light_volumetric_intensity_4);
        QWidget::setTabOrder(logslider_aux_light_volumetric_intensity_4, logedit_aux_light_volumetric_intensity_4);
        QWidget::setTabOrder(logedit_aux_light_volumetric_intensity_4, groupCheck_fake_lights_enabled);
        QWidget::setTabOrder(groupCheck_fake_lights_enabled, sliderInt_fake_lights_min_iter);
        QWidget::setTabOrder(sliderInt_fake_lights_min_iter, spinboxInt_fake_lights_min_iter);
        QWidget::setTabOrder(spinboxInt_fake_lights_min_iter, sliderInt_fake_lights_max_iter);
        QWidget::setTabOrder(sliderInt_fake_lights_max_iter, spinboxInt_fake_lights_max_iter);
        QWidget::setTabOrder(spinboxInt_fake_lights_max_iter, logslider_fake_lights_intensity);
        QWidget::setTabOrder(logslider_fake_lights_intensity, logedit_fake_lights_intensity);
        QWidget::setTabOrder(logedit_fake_lights_intensity, logslider_fake_lights_visibility);
        QWidget::setTabOrder(logslider_fake_lights_visibility, logedit_fake_lights_visibility);
        QWidget::setTabOrder(logedit_fake_lights_visibility, slider_fake_lights_visibility_size);
        QWidget::setTabOrder(slider_fake_lights_visibility_size, spinbox_fake_lights_visibility_size);
        QWidget::setTabOrder(spinbox_fake_lights_visibility_size, vect3_fake_lights_orbit_trap_x);
        QWidget::setTabOrder(vect3_fake_lights_orbit_trap_x, vect3_fake_lights_orbit_trap_y);
        QWidget::setTabOrder(vect3_fake_lights_orbit_trap_y, vect3_fake_lights_orbit_trap_z);
        QWidget::setTabOrder(vect3_fake_lights_orbit_trap_z, tabWidget_fractals);
        QWidget::setTabOrder(tabWidget_fractals, comboBox_formula_1);
        QWidget::setTabOrder(comboBox_formula_1, spinboxInt_formula_iterations_1);
        QWidget::setTabOrder(spinboxInt_formula_iterations_1, sliderInt_formula_iterations_1);
        QWidget::setTabOrder(sliderInt_formula_iterations_1, scrollArea_fractal_1);
        QWidget::setTabOrder(scrollArea_fractal_1, scrollArea_11);
        QWidget::setTabOrder(scrollArea_11, groupCheck_julia_mode);
        QWidget::setTabOrder(groupCheck_julia_mode, vect3_julia_c_x);
        QWidget::setTabOrder(vect3_julia_c_x, vect3_julia_c_y);
        QWidget::setTabOrder(vect3_julia_c_y, vect3_julia_c_z);
        QWidget::setTabOrder(vect3_julia_c_z, pushButton_get_julia_constant);
        QWidget::setTabOrder(pushButton_get_julia_constant, slider_fractal_constant_factor);
        QWidget::setTabOrder(slider_fractal_constant_factor, spinbox_fractal_constant_factor);
        QWidget::setTabOrder(spinbox_fractal_constant_factor, vect3_fractal_position_x);
        QWidget::setTabOrder(vect3_fractal_position_x, vect3_fractal_position_y);
        QWidget::setTabOrder(vect3_fractal_position_y, vect3_fractal_position_z);
        QWidget::setTabOrder(vect3_fractal_position_z, dial3_fractal_rotation_x);
        QWidget::setTabOrder(dial3_fractal_rotation_x, spinboxd3_fractal_rotation_x);
        QWidget::setTabOrder(spinboxd3_fractal_rotation_x, dial3_fractal_rotation_y);
        QWidget::setTabOrder(dial3_fractal_rotation_y, spinboxd3_fractal_rotation_y);
        QWidget::setTabOrder(spinboxd3_fractal_rotation_y, dial3_fractal_rotation_z);
        QWidget::setTabOrder(dial3_fractal_rotation_z, spinboxd3_fractal_rotation_z);
        QWidget::setTabOrder(spinboxd3_fractal_rotation_z, vect3_repeat_x);
        QWidget::setTabOrder(vect3_repeat_x, vect3_repeat_y);
        QWidget::setTabOrder(vect3_repeat_y, vect3_repeat_z);
        QWidget::setTabOrder(vect3_repeat_z, checkBox_hybrid_fractal_enable);
        QWidget::setTabOrder(checkBox_hybrid_fractal_enable, checkBox_linear_DE_mode);
        QWidget::setTabOrder(checkBox_linear_DE_mode, scrollArea_primitives);
        QWidget::setTabOrder(scrollArea_primitives, pushButton_add_primitive_rectangle);
        QWidget::setTabOrder(pushButton_add_primitive_rectangle, pushButton_add_primitive_circle);
        QWidget::setTabOrder(pushButton_add_primitive_circle, pushButton_add_primitive_box);
        QWidget::setTabOrder(pushButton_add_primitive_box, pushButton_add_primitive_cylinder);
        QWidget::setTabOrder(pushButton_add_primitive_cylinder, pushButton_add_primitive_cone);
        QWidget::setTabOrder(pushButton_add_primitive_cone, pushButton_add_primitive_sphere);
        QWidget::setTabOrder(pushButton_add_primitive_sphere, pushButton_add_primitive_torus);
        QWidget::setTabOrder(pushButton_add_primitive_torus, pushButton_add_primitive_plane);
        QWidget::setTabOrder(pushButton_add_primitive_plane, pushButton_add_primitive_water);
        QWidget::setTabOrder(pushButton_add_primitive_water, vect3_all_primitives_position_x);
        QWidget::setTabOrder(vect3_all_primitives_position_x, vect3_all_primitives_position_y);
        QWidget::setTabOrder(vect3_all_primitives_position_y, vect3_all_primitives_position_z);
        QWidget::setTabOrder(vect3_all_primitives_position_z, dial3_all_primitives_rotation_x);
        QWidget::setTabOrder(dial3_all_primitives_rotation_x, spinboxd3_all_primitives_rotation_x);
        QWidget::setTabOrder(spinboxd3_all_primitives_rotation_x, dial3_all_primitives_rotation_y);
        QWidget::setTabOrder(dial3_all_primitives_rotation_y, spinboxd3_all_primitives_rotation_y);
        QWidget::setTabOrder(spinboxd3_all_primitives_rotation_y, dial3_all_primitives_rotation_z);
        QWidget::setTabOrder(dial3_all_primitives_rotation_z, spinboxd3_all_primitives_rotation_z);
        QWidget::setTabOrder(spinboxd3_all_primitives_rotation_z, sliderInt_N);
        QWidget::setTabOrder(sliderInt_N, spinboxInt_N);
        QWidget::setTabOrder(spinboxInt_N, logslider_detail_level);
        QWidget::setTabOrder(logslider_detail_level, logedit_detail_level);
        QWidget::setTabOrder(logedit_detail_level, logslider_DE_factor);
        QWidget::setTabOrder(logslider_DE_factor, logedit_DE_factor);
        QWidget::setTabOrder(logedit_DE_factor, logslider_smoothness);
        QWidget::setTabOrder(logslider_smoothness, logedit_smoothness);
        QWidget::setTabOrder(logedit_smoothness, logslider_view_distance_max);
        QWidget::setTabOrder(logslider_view_distance_max, logedit_view_distance_max);
        QWidget::setTabOrder(logedit_view_distance_max, logslider_view_distance_min);
        QWidget::setTabOrder(logslider_view_distance_min, logedit_view_distance_min);
        QWidget::setTabOrder(logedit_view_distance_min, checkBox_iteration_threshold_mode);
        QWidget::setTabOrder(checkBox_iteration_threshold_mode, checkBox_interior_mode);
        QWidget::setTabOrder(checkBox_interior_mode, checkBox_slow_shading);
        QWidget::setTabOrder(checkBox_slow_shading, groupCheck_constant_DE_threshold);
        QWidget::setTabOrder(groupCheck_constant_DE_threshold, logslider_DE_thresh);
        QWidget::setTabOrder(logslider_DE_thresh, logedit_DE_thresh);
        QWidget::setTabOrder(logedit_DE_thresh, groupCheck_limits_enabled);
        QWidget::setTabOrder(groupCheck_limits_enabled, vect3_limit_min_x);
        QWidget::setTabOrder(vect3_limit_min_x, vect3_limit_min_y);
        QWidget::setTabOrder(vect3_limit_min_y, vect3_limit_min_z);
        QWidget::setTabOrder(vect3_limit_min_z, vect3_limit_max_x);
        QWidget::setTabOrder(vect3_limit_max_x, vect3_limit_max_y);
        QWidget::setTabOrder(vect3_limit_max_y, vect3_limit_max_z);
        QWidget::setTabOrder(vect3_limit_max_z, pushButton_render);
        QWidget::setTabOrder(pushButton_render, pushButton_stop);
        QWidget::setTabOrder(pushButton_stop, scrollArea_4);
        QWidget::setTabOrder(scrollArea_4, vect3_camera_x);
        QWidget::setTabOrder(vect3_camera_x, vect3_camera_y);
        QWidget::setTabOrder(vect3_camera_y, vect3_camera_z);
        QWidget::setTabOrder(vect3_camera_z, vect3_target_x);
        QWidget::setTabOrder(vect3_target_x, vect3_target_y);
        QWidget::setTabOrder(vect3_target_y, vect3_target_z);
        QWidget::setTabOrder(vect3_target_z, pushButton_reset_view);
        QWidget::setTabOrder(pushButton_reset_view, comboBox_camera_movement_mode);
        QWidget::setTabOrder(comboBox_camera_movement_mode, logedit_camera_distance_to_target);
        QWidget::setTabOrder(logedit_camera_distance_to_target, logslider_camera_distance_to_target);
        QWidget::setTabOrder(logslider_camera_distance_to_target, bu_move_forward);
        QWidget::setTabOrder(bu_move_forward, bu_move_up);
        QWidget::setTabOrder(bu_move_up, bu_move_backward);
        QWidget::setTabOrder(bu_move_backward, bu_move_left);
        QWidget::setTabOrder(bu_move_left, bu_move_down);
        QWidget::setTabOrder(bu_move_down, bu_move_right);
        QWidget::setTabOrder(bu_move_right, logedit_camera_movement_step);
        QWidget::setTabOrder(logedit_camera_movement_step, logslider_camera_movement_step);
        QWidget::setTabOrder(logslider_camera_movement_step, comboBox_camera_absolute_distance_mode);
        QWidget::setTabOrder(comboBox_camera_absolute_distance_mode, bu_rotate_roll_left);
        QWidget::setTabOrder(bu_rotate_roll_left, bu_rotate_up);
        QWidget::setTabOrder(bu_rotate_up, bu_rotate_roll_right);
        QWidget::setTabOrder(bu_rotate_roll_right, bu_rotate_left);
        QWidget::setTabOrder(bu_rotate_left, bu_rotate_down);
        QWidget::setTabOrder(bu_rotate_down, bu_rotate_right);
        QWidget::setTabOrder(bu_rotate_right, spinbox_camera_rotation_step);
        QWidget::setTabOrder(spinbox_camera_rotation_step, comboBox_camera_rotation_mode);
        QWidget::setTabOrder(comboBox_camera_rotation_mode, comboBox_camera_straight_rotation);
        QWidget::setTabOrder(comboBox_camera_straight_rotation, vect3_camera_rotation_x);
        QWidget::setTabOrder(vect3_camera_rotation_x, vect3_camera_rotation_y);
        QWidget::setTabOrder(vect3_camera_rotation_y, vect3_camera_rotation_z);
        QWidget::setTabOrder(vect3_camera_rotation_z, comboBox_mouse_click_function);
        QWidget::setTabOrder(comboBox_mouse_click_function, comboBox_image_preview_scale);
        QWidget::setTabOrder(comboBox_image_preview_scale, checkBox_show_cursor);
        QWidget::setTabOrder(checkBox_show_cursor, slider_flight_roll_speed);
        QWidget::setTabOrder(slider_flight_roll_speed, spinbox_flight_roll_speed);
        QWidget::setTabOrder(spinbox_flight_roll_speed, comboBox_flight_speed_control);
        QWidget::setTabOrder(comboBox_flight_speed_control, slider_flight_sec_per_frame);
        QWidget::setTabOrder(slider_flight_sec_per_frame, spinbox_flight_sec_per_frame);
        QWidget::setTabOrder(spinbox_flight_sec_per_frame, text_anim_flight_dir);
        QWidget::setTabOrder(text_anim_flight_dir, button_selectAnimFlightImageDir);
        QWidget::setTabOrder(button_selectAnimFlightImageDir, checkBox_flight_show_thumbnails);
        QWidget::setTabOrder(checkBox_flight_show_thumbnails, checkBox_flight_add_speeds);
        QWidget::setTabOrder(checkBox_flight_add_speeds, scrollArea_flyght_animation_parameters);
        QWidget::setTabOrder(scrollArea_flyght_animation_parameters, scrollArea);
        QWidget::setTabOrder(scrollArea, tabWidget_2);
        QWidget::setTabOrder(tabWidget_2, scrollArea_7);
        QWidget::setTabOrder(scrollArea_7, tabWidget_fractal);
        QWidget::setTabOrder(tabWidget_fractal, scrollArea_8);
        QWidget::setTabOrder(scrollArea_8, scrollAreaForImage);
        QWidget::setTabOrder(scrollAreaForImage, tabWidgetFlightKeyframe);
        QWidget::setTabOrder(tabWidgetFlightKeyframe, tableWidget_flightAnimation);
        QWidget::setTabOrder(tableWidget_flightAnimation, scrollArea_2);
        QWidget::setTabOrder(scrollArea_2, scrollArea_5);
        QWidget::setTabOrder(scrollArea_5, pushButton_render_flight);
        QWidget::setTabOrder(pushButton_render_flight, pushButton_record_flight);
        QWidget::setTabOrder(pushButton_record_flight, pushButton_continue_recording);
        QWidget::setTabOrder(pushButton_continue_recording, pushButton_show_animation);
        QWidget::setTabOrder(pushButton_show_animation, pushButton_delete_all_images);
        QWidget::setTabOrder(pushButton_delete_all_images, pushButton_flight_refresh_table);
        QWidget::setTabOrder(pushButton_flight_refresh_table, logslider_flight_speed);
        QWidget::setTabOrder(logslider_flight_speed, logedit_flight_speed);
        QWidget::setTabOrder(logedit_flight_speed, slider_flight_inertia);
        QWidget::setTabOrder(slider_flight_inertia, spinbox_flight_inertia);
        QWidget::setTabOrder(spinbox_flight_inertia, slider_flight_rotation_speed);
        QWidget::setTabOrder(slider_flight_rotation_speed, spinbox_flight_rotation_speed);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuEdit->menuAction());
        menubar->addAction(menuImage->menuAction());
        menubar->addAction(menuView->menuAction());
        menubar->addAction(menuAbout->menuAction());
        menuImage->addAction(actionSave_as_JPG);
        menuImage->addAction(actionSave_as_PNG);
        menuImage->addAction(actionSave_as_PNG_16_bit);
        menuImage->addAction(actionSave_as_PNG_16_bit_with_alpha_channel);
        menuFile->addAction(actionLoad_settings);
        menuFile->addAction(actionLoad_example);
        menuFile->addSeparator();
        menuFile->addAction(actionSave_settings);
        menuFile->addSeparator();
        menuFile->addAction(actionImport_settings_from_old_Mandelbulber);
        menuFile->addSeparator();
        menuFile->addAction(actionProgramSettings);
        menuFile->addSeparator();
        menuFile->addAction(actionQuit);
        menuView->addAction(actionSave_docks_positions);
        menuView->addAction(actionDefault_docks_positions);
        menuView->addAction(actionStack_all_docks);
        menuView->addSeparator();
        menuView->addSeparator();
        menuView->addAction(actionShow_animation_dock);
        menuView->addAction(actionShow_info_dock);
        menuView->addAction(actionShow_toolbar);
        menuAbout->addAction(actionAbout_Mandelbulber);
        menuAbout->addAction(actionAbout_Qt);
        menuEdit->addAction(actionUndo);
        menuEdit->addAction(actionRedo);

        retranslateUi(RenderWindow);

        comboBox_image_preview_scale->setCurrentIndex(3);
        tabWidget_2->setCurrentIndex(0);
        tabWidget_fractal->setCurrentIndex(0);
        tabWidget_fractals->setCurrentIndex(0);
        combo_netrender_mode->setCurrentIndex(1);
        tabWidgetFlightKeyframe->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(RenderWindow);
    } // setupUi

    void retranslateUi(QMainWindow *RenderWindow)
    {
        RenderWindow->setWindowTitle(QApplication::translate("RenderWindow", "Mandelbulber", 0));
        actionSave_as_JPG->setText(QApplication::translate("RenderWindow", "Save as JPG...", 0));
        actionSave_as_PNG->setText(QApplication::translate("RenderWindow", "Save as PNG...", 0));
        actionSave_as_PNG_16_bit->setText(QApplication::translate("RenderWindow", "Save as PNG 16 bit...", 0));
        actionSave_as_PNG_16_bit_with_alpha_channel->setText(QApplication::translate("RenderWindow", "Save as PNG 16 bit with alpha channel", 0));
        actionLoad_settings->setText(QApplication::translate("RenderWindow", "Load settings...", 0));
        actionSave_settings->setText(QApplication::translate("RenderWindow", "Save settings", 0));
        actionSave_settings_as->setText(QApplication::translate("RenderWindow", "Save settings as...", 0));
#ifndef QT_NO_STATUSTIP
        actionSave_settings_as->setStatusTip(QApplication::translate("RenderWindow", "Save settings in selected file", 0));
#endif // QT_NO_STATUSTIP
        actionProgramSettings->setText(QApplication::translate("RenderWindow", "Program Settings", 0));
        actionQuit->setText(QApplication::translate("RenderWindow", "Quit", 0));
        actionSave_docks_positions->setText(QApplication::translate("RenderWindow", "Save window state", 0));
        actionDefault_docks_positions->setText(QApplication::translate("RenderWindow", "Default docks positions", 0));
        actionAbout_Qt->setText(QApplication::translate("RenderWindow", "About Qt", 0));
        actionAbout_Mandelbulber->setText(QApplication::translate("RenderWindow", "About Mandelbulber", 0));
        actionUndo->setText(QApplication::translate("RenderWindow", "Undo", 0));
        actionUndo->setShortcut(QApplication::translate("RenderWindow", "Ctrl+Z", 0));
        actionRedo->setText(QApplication::translate("RenderWindow", "Redo", 0));
        actionRedo->setShortcut(QApplication::translate("RenderWindow", "Ctrl+Y", 0));
        actionImport_settings_from_old_Mandelbulber->setText(QApplication::translate("RenderWindow", "Import settings from old Mandelbulber (v1.21)...", 0));
        actionLoad_example->setText(QApplication::translate("RenderWindow", "Load example...", 0));
        actionShow_animation_dock->setText(QApplication::translate("RenderWindow", "Show animation dock", 0));
        actionShow_info_dock->setText(QApplication::translate("RenderWindow", "Show Info dock", 0));
        actionShow_toolbar->setText(QApplication::translate("RenderWindow", "Show toolbar", 0));
        actionStack_all_docks->setText(QApplication::translate("RenderWindow", "Stack all docks", 0));
        label->setText(QApplication::translate("RenderWindow", "Zoom:", 0));
        comboBox_image_preview_scale->clear();
        comboBox_image_preview_scale->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Fit to window", 0)
         << QApplication::translate("RenderWindow", "400%", 0)
         << QApplication::translate("RenderWindow", "200%", 0)
         << QApplication::translate("RenderWindow", "100%", 0)
         << QApplication::translate("RenderWindow", "50%", 0)
         << QApplication::translate("RenderWindow", "25%", 0)
         << QApplication::translate("RenderWindow", "10%", 0)
        );
        checkBox_show_cursor->setText(QApplication::translate("RenderWindow", "Show cursor", 0));
        menuImage->setTitle(QApplication::translate("RenderWindow", "Image", 0));
        menuFile->setTitle(QApplication::translate("RenderWindow", "File", 0));
        menuView->setTitle(QApplication::translate("RenderWindow", "View", 0));
        menuAbout->setTitle(QApplication::translate("RenderWindow", "About", 0));
        menuEdit->setTitle(QApplication::translate("RenderWindow", "Edit", 0));
        dockWidget_image_adjustments->setWindowTitle(QApplication::translate("RenderWindow", "Image adjustments", 0));
        groupBox_3->setTitle(QApplication::translate("RenderWindow", "Image resolution", 0));
        label_100->setText(QApplication::translate("RenderWindow", "Image width:", 0));
        label_101->setText(QApplication::translate("RenderWindow", "Image height:", 0));
        label_102->setText(QApplication::translate("RenderWindow", "Image proportion:", 0));
        comboBox_image_proportion->clear();
        comboBox_image_proportion->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Free", 0)
         << QApplication::translate("RenderWindow", "1:1", 0)
         << QApplication::translate("RenderWindow", "4:3", 0)
         << QApplication::translate("RenderWindow", "3:2", 0)
         << QApplication::translate("RenderWindow", "16:9", 0)
         << QApplication::translate("RenderWindow", "16:10", 0)
         << QApplication::translate("RenderWindow", "2:1", 0)
        );
        groupBox_6->setTitle(QApplication::translate("RenderWindow", "Presets", 0));
        pushButton_resolution_preset_2160->setText(QApplication::translate("RenderWindow", "4096\303\2272160", 0));
        pushButton_resolution_preset_720->setText(QApplication::translate("RenderWindow", "1280x720", 0));
        pushButton_resolution_preset_1080->setText(QApplication::translate("RenderWindow", "1920x1080", 0));
        pushButton_resolution_preset_4320->setText(QApplication::translate("RenderWindow", "7680\303\2274320", 0));
        pushButton_resolution_preset_480->setText(QApplication::translate("RenderWindow", "720x480", 0));
        pushButton_resolution_preset_1440->setText(QApplication::translate("RenderWindow", "2560x1440", 0));
        pushButton_resolution_preset_240->setText(QApplication::translate("RenderWindow", "320x240", 0));
        pushButton_resolution_preset_600->setText(QApplication::translate("RenderWindow", "800x600", 0));
        pushButton_resolution_preset_1200->setText(QApplication::translate("RenderWindow", "1600x1200", 0));
        groupBox_ImageAdjustments->setTitle(QApplication::translate("RenderWindow", "Picture", 0));
        spinbox_contrast->setPrefix(QString());
        spinbox_contrast->setSuffix(QString());
        spinbox_gamma->setPrefix(QString());
        spinbox_gamma->setSuffix(QString());
        label_4->setText(QApplication::translate("RenderWindow", "Gamma:", 0));
        spinbox_brightness->setPrefix(QString());
        spinbox_brightness->setSuffix(QString());
        label_3->setText(QApplication::translate("RenderWindow", "Brightness:", 0));
        label_45->setText(QApplication::translate("RenderWindow", "Contrast:", 0));
        checkBox_hdr->setText(QApplication::translate("RenderWindow", "High Dynamic Range (HDR)", 0));
        pushButton_apply_image_changes->setText(QApplication::translate("RenderWindow", "Apply changes", 0));
        groupBox_5->setTitle(QApplication::translate("RenderWindow", "Camera", 0));
        label_54->setText(QApplication::translate("RenderWindow", "Field of view:", 0));
        spinbox_fov->setPrefix(QString());
        spinbox_fov->setSuffix(QString());
        comboBox_perspective_type->clear();
        comboBox_perspective_type->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Three-point perspective", 0)
         << QApplication::translate("RenderWindow", "Fish eye", 0)
         << QApplication::translate("RenderWindow", "Equirectangular", 0)
         << QApplication::translate("RenderWindow", "Fulldome", 0)
        );
        label_126->setText(QApplication::translate("RenderWindow", "Perspective type:", 0));
        checkBox_legacy_coordinate_system->setText(QApplication::translate("RenderWindow", "Coordinate system like in Mandelbulber v1.21", 0));
        dockWidget_navigation->setWindowTitle(QApplication::translate("RenderWindow", "Navigation", 0));
        pushButton_render->setText(QApplication::translate("RenderWindow", "RENDER", 0));
        pushButton_stop->setText(QApplication::translate("RenderWindow", "STOP", 0));
        groupBox_coordinates->setTitle(QApplication::translate("RenderWindow", "Coordinates:", 0));
        groupBox_cameraPosition->setTitle(QApplication::translate("RenderWindow", "Camera", 0));
        label_18->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_19->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_20->setText(QApplication::translate("RenderWindow", "z:", 0));
        groupBox_targetPosition->setTitle(QApplication::translate("RenderWindow", "Target", 0));
        label_121->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_122->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_123->setText(QApplication::translate("RenderWindow", "z:", 0));
        pushButton_reset_view->setText(QApplication::translate("RenderWindow", "Reset view", 0));
        comboBox_camera_movement_mode->clear();
        comboBox_camera_movement_mode->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Move camera and target", 0)
         << QApplication::translate("RenderWindow", "Move camera", 0)
         << QApplication::translate("RenderWindow", "Move target", 0)
        );
        label_124->setText(QApplication::translate("RenderWindow", "Camera distance\n"
"to target:", 0));
        bu_move_right->setText(QString());
        bu_move_left->setText(QString());
        bu_move_up->setText(QString());
        bu_move_forward->setText(QString());
        bu_move_backward->setText(QString());
        bu_move_down->setText(QString());
        label_9->setText(QApplication::translate("RenderWindow", "step:", 0));
        comboBox_camera_absolute_distance_mode->clear();
        comboBox_camera_absolute_distance_mode->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Relative step mode", 0)
         << QApplication::translate("RenderWindow", "Absolute step mode", 0)
        );
        groupBox_rotation->setTitle(QApplication::translate("RenderWindow", "Camera rotation:", 0));
        bu_rotate_left->setText(QString());
        bu_rotate_up->setText(QString());
        bu_rotate_right->setText(QString());
        bu_rotate_roll_right->setText(QString());
        bu_rotate_roll_left->setText(QString());
        bu_rotate_down->setText(QString());
        label_125->setText(QApplication::translate("RenderWindow", "rotation step:", 0));
        spinbox_camera_rotation_step->setPrefix(QString());
        spinbox_camera_rotation_step->setSuffix(QString());
        comboBox_camera_rotation_mode->clear();
        comboBox_camera_rotation_mode->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Rotate camera", 0)
         << QApplication::translate("RenderWindow", "Rotate around target", 0)
        );
        comboBox_camera_straight_rotation->clear();
        comboBox_camera_straight_rotation->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Fixed roll angle", 0)
         << QApplication::translate("RenderWindow", "Staight rotation", 0)
        );
        label_15->setText(QApplication::translate("RenderWindow", "yaw:", 0));
        label_16->setText(QApplication::translate("RenderWindow", "pitch:", 0));
        label_17->setText(QApplication::translate("RenderWindow", "roll:", 0));
        label_mouse_click_functions->setText(QApplication::translate("RenderWindow", "Mouse click function:", 0));
        comboBox_mouse_click_function->clear();
        comboBox_mouse_click_function->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "No action", 0)
        );
        toolBar->setWindowTitle(QApplication::translate("RenderWindow", "toolBar", 0));
        dockWidget_effects->setWindowTitle(QApplication::translate("RenderWindow", "Effects", 0));
        label_172->setText(QApplication::translate("RenderWindow", "Color of volume:", 0));
        colorButton_transparency_interior_color->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        spinbox_ambient_occlusion->setPrefix(QString());
        spinbox_ambient_occlusion->setSuffix(QString());
        spinbox_reflect->setPrefix(QString());
        spinbox_reflect->setSuffix(QString());
        label_55->setText(QApplication::translate("RenderWindow", "Ambient occlusion:", 0));
        label_56->setText(QApplication::translate("RenderWindow", "Reflection:", 0));
        spinbox_shading->setPrefix(QString());
        spinbox_shading->setSuffix(QString());
        spinbox_specular->setPrefix(QString());
        spinbox_specular->setSuffix(QString());
        label_52->setText(QApplication::translate("RenderWindow", "Shading:", 0));
        label_53->setText(QApplication::translate("RenderWindow", "Specularity:", 0));
        label_171->setText(QApplication::translate("RenderWindow", "Transparency of volume:", 0));
        label_170->setText(QApplication::translate("RenderWindow", "Transparency of surface:", 0));
        spinbox_transparency_of_surface->setPrefix(QString());
        spinbox_transparency_of_surface->setSuffix(QString());
        label_173->setText(QApplication::translate("RenderWindow", "Index of refraction:", 0));
        spinbox_transparency_index_of_refraction->setPrefix(QString());
        spinbox_transparency_index_of_refraction->setSuffix(QString());
        checkBox_fresnel_reflectance->setText(QApplication::translate("RenderWindow", "Fresnel's equations for reflectance", 0));
        groupCheck_ambient_occlusion_enabled->setTitle(QApplication::translate("RenderWindow", "Ambient occlusion", 0));
        label_68->setText(QApplication::translate("RenderWindow", "Fast AO tune:", 0));
        label_69->setText(QApplication::translate("RenderWindow", "Quality:", 0));
        label_70->setText(QApplication::translate("RenderWindow", "Type:", 0));
        comboBox_ambient_occlusion_mode->clear();
        comboBox_ambient_occlusion_mode->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Fast", 0)
         << QApplication::translate("RenderWindow", "Multiple rays with light map", 0)
         << QApplication::translate("RenderWindow", "Screen space", 0)
        );
        spinbox_ambient_occlusion_fast_tune->setPrefix(QString());
        spinbox_ambient_occlusion_fast_tune->setSuffix(QString());
        button_selectLightMapTexture->setText(QApplication::translate("RenderWindow", "Select file", 0));
        label_133->setText(QApplication::translate("RenderWindow", "Light map texture:", 0));
        label_lightmapTextureView->setText(QString());
        groupCheck_fractal_color->setTitle(QApplication::translate("RenderWindow", "Surface color", 0));
        label_75->setText(QApplication::translate("RenderWindow", "Color speed:", 0));
        label_74->setText(QApplication::translate("RenderWindow", "Random seed:", 0));
        label_73->setText(QApplication::translate("RenderWindow", "Saturation:", 0));
        spinbox_coloring_saturation->setPrefix(QString());
        spinbox_coloring_saturation->setSuffix(QString());
        spinbox_coloring_speed->setPrefix(QString());
        spinbox_coloring_speed->setSuffix(QString());
        pushButton_getPaletteFromImage->setText(QApplication::translate("RenderWindow", "Grab colors from image...", 0));
        label_127->setText(QApplication::translate("RenderWindow", "Palette size:", 0));
        label_71->setText(QApplication::translate("RenderWindow", "Palette:\n"
"(click to edit)", 0));
        label_72->setText(QApplication::translate("RenderWindow", "Palette offset:", 0));
        spinbox_coloring_palette_offset->setPrefix(QString());
        spinbox_coloring_palette_offset->setSuffix(QString());
        pushButton_randomPalette->setText(QApplication::translate("RenderWindow", "Generate new random palette", 0));
        pushButton_randomize->setText(QApplication::translate("RenderWindow", "Randomize", 0));
        groupCheck_env_mapping_enable->setTitle(QApplication::translate("RenderWindow", "Environment mappring", 0));
        button_selectEnvMapTexture->setText(QApplication::translate("RenderWindow", "Select file", 0));
        label_132->setText(QApplication::translate("RenderWindow", "Texture path:", 0));
        label_envmapTextureView->setText(QString());
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab), QApplication::translate("RenderWindow", "Material", 0));
        groupCheck_raytraced_reflections->setTitle(QApplication::translate("RenderWindow", "Ray-traced reflections and transparency", 0));
        label_62->setText(QApplication::translate("RenderWindow", "Reflections depth:", 0));
        groupCheck_DOF_enabled->setTitle(QApplication::translate("RenderWindow", "Depth of field", 0));
        label_131->setText(QApplication::translate("RenderWindow", "Focus distance:", 0));
        label_136->setText(QApplication::translate("RenderWindow", "Radius:", 0));
        spinbox_DOF_radius->setPrefix(QString());
        spinbox_DOF_radius->setSuffix(QString());
        pushButton_DOF_update->setText(QApplication::translate("RenderWindow", "Update image", 0));
        pushButton_DOF_set_focus->setText(QApplication::translate("RenderWindow", "Set focus distance by mouse", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_2), QApplication::translate("RenderWindow", "Ray-tracing", 0));
        groupCheck_basic_fog_enabled->setTitle(QApplication::translate("RenderWindow", "Basic fog", 0));
        label_64->setText(QApplication::translate("RenderWindow", "Color:", 0));
        colorButton_basic_fog_color->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        label_63->setText(QApplication::translate("RenderWindow", "Visibility distance:", 0));
        pushButton_set_fog_by_mouse->setText(QApplication::translate("RenderWindow", "Set visibility distance by mouse", 0));
        groupCheck_glow_enabled->setTitle(QApplication::translate("RenderWindow", "Glow", 0));
        label_88->setText(QApplication::translate("RenderWindow", "Color #1:", 0));
        label_89->setText(QApplication::translate("RenderWindow", "Color #2:", 0));
        colorButton_glow_color_2->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        colorButton_glow_color_1->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        label_87->setText(QApplication::translate("RenderWindow", "Intensity:", 0));
        groupCheck_volumetric_fog_enabled->setTitle(QApplication::translate("RenderWindow", "Fog based on distance", 0));
        label_77->setText(QApplication::translate("RenderWindow", "Fog distance factor:", 0));
        label_76->setText(QApplication::translate("RenderWindow", "Distance of color #2:", 0));
        label_67->setText(QApplication::translate("RenderWindow", "Distance of color #1:", 0));
        colorButton_fog_color_1->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        label_65->setText(QApplication::translate("RenderWindow", "Density:", 0));
        label_78->setText(QApplication::translate("RenderWindow", "Color #2:", 0));
        colorButton_fog_color_2->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        label_79->setText(QApplication::translate("RenderWindow", "Color #3:", 0));
        colorButton_fog_color_3->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        button_calculateFog->setText(QApplication::translate("RenderWindow", "Optimal distances calculation", 0));
        label_66->setText(QApplication::translate("RenderWindow", "Color #1:", 0));
        groupCheck_iteration_fog_enable->setTitle(QApplication::translate("RenderWindow", "Fog based on iteration count", 0));
        colorButton_iteration_fog_color_1->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        spinbox_iteration_fog_opacity_trim->setPrefix(QString());
        spinbox_iteration_fog_opacity_trim->setSuffix(QString());
        label_85->setText(QApplication::translate("RenderWindow", "Color #2:", 0));
        spinbox_iteration_fog_color_1_maxiter->setPrefix(QString());
        spinbox_iteration_fog_color_1_maxiter->setSuffix(QString());
        colorButton_iteration_fog_color_3->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        colorButton_iteration_fog_color_2->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        label_84->setText(QApplication::translate("RenderWindow", "Color #1:", 0));
        spinbox_iteration_fog_color_2_maxiter->setPrefix(QString());
        spinbox_iteration_fog_color_2_maxiter->setSuffix(QString());
        label_80->setText(QApplication::translate("RenderWindow", "Opacity:", 0));
        label_86->setText(QApplication::translate("RenderWindow", "Color #3:", 0));
        label_81->setText(QApplication::translate("RenderWindow", "Low iterations trim:", 0));
        label_83->setText(QApplication::translate("RenderWindow", "Max iter. for color#2:", 0));
        label_82->setText(QApplication::translate("RenderWindow", "Max iter. for color#1:", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_3), QApplication::translate("RenderWindow", "Volumetric", 0));
        groupBox_14->setTitle(QApplication::translate("RenderWindow", "Colored background", 0));
        colorButton_background_color_2->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        label_58->setText(QApplication::translate("RenderWindow", "Color #2:", 0));
        label_57->setText(QApplication::translate("RenderWindow", "Color #1:", 0));
        colorButton_background_color_1->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        label_59->setText(QApplication::translate("RenderWindow", "Color #3:", 0));
        colorButton_background_color_3->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        groupCheck_textured_background->setTitle(QApplication::translate("RenderWindow", "Textured background", 0));
        button_selectBackgroundTexture->setText(QApplication::translate("RenderWindow", "Select file", 0));
        label_61->setText(QApplication::translate("RenderWindow", "Texture path:", 0));
        label_90->setText(QApplication::translate("RenderWindow", "Map type:", 0));
        comboBox_textured_background_map_type->clear();
        comboBox_textured_background_map_type->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Equirectangular", 0)
         << QApplication::translate("RenderWindow", "Double hemisphere", 0)
        );
        label_backgroundTextureView->setText(QString());
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_4), QApplication::translate("RenderWindow", "Background", 0));
        groupBox_7->setTitle(QApplication::translate("RenderWindow", "Common light options", 0));
        checkBox_shadows_enabled->setText(QApplication::translate("RenderWindow", "Cast shadows", 0));
        checkBox_penetrating_lights->setText(QApplication::translate("RenderWindow", "Penetrating lights", 0));
        groupCheck_main_light_enable->setTitle(QApplication::translate("RenderWindow", "Main light source", 0));
        label_8->setText(QApplication::translate("RenderWindow", "Horizontal angle:", 0));
        label_2->setText(QApplication::translate("RenderWindow", "Intensity:", 0));
        spinboxd_main_light_alpha->setPrefix(QString());
        spinboxd_main_light_alpha->setSuffix(QString());
        spinbox_main_light_visibility_size->setPrefix(QString());
        spinbox_main_light_visibility_size->setSuffix(QString());
        spinbox_main_light_intensity->setPrefix(QString());
        spinbox_main_light_intensity->setSuffix(QString());
        spinbox_main_light_visibility->setPrefix(QString());
        spinbox_main_light_visibility->setSuffix(QString());
        label_5->setText(QApplication::translate("RenderWindow", "Size:", 0));
        spinbox_shadows_cone_angle->setPrefix(QString());
        spinbox_shadows_cone_angle->setSuffix(QString());
        label_10->setText(QApplication::translate("RenderWindow", "Vertical angle:", 0));
        spinboxd_main_light_beta->setPrefix(QString());
        spinboxd_main_light_beta->setSuffix(QString());
        label_30->setText(QApplication::translate("RenderWindow", "Soft shadow cone angle:", 0));
        label_6->setText(QApplication::translate("RenderWindow", "Visibility:", 0));
        label_7->setText(QApplication::translate("RenderWindow", "Color:", 0));
        colorButton_main_light_colour->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        checkBox_main_light_position_relative->setText(QApplication::translate("RenderWindow", "Position relative to the camera", 0));
        groupBox_Lights->setTitle(QApplication::translate("RenderWindow", "Custom lights", 0));
        groupCheck_aux_light_enabled_1->setTitle(QApplication::translate("RenderWindow", "Light #1", 0));
        label_21->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_22->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_23->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_11->setText(QApplication::translate("RenderWindow", "Intensity:", 0));
        label_12->setText(QApplication::translate("RenderWindow", "Color:", 0));
        colorButton_aux_light_colour_1->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        pushButton_place_light_by_mouse_1->setText(QApplication::translate("RenderWindow", "Place by mouse", 0));
        groupCheck_aux_light_enabled_2->setTitle(QApplication::translate("RenderWindow", "Light #2", 0));
        label_24->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_25->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_26->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_13->setText(QApplication::translate("RenderWindow", "Intensity:", 0));
        label_14->setText(QApplication::translate("RenderWindow", "Color:", 0));
        colorButton_aux_light_colour_2->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        pushButton_place_light_by_mouse_2->setText(QApplication::translate("RenderWindow", "Place by mouse", 0));
        groupCheck_aux_light_enabled_3->setTitle(QApplication::translate("RenderWindow", "Light #3", 0));
        label_27->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_28->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_29->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_31->setText(QApplication::translate("RenderWindow", "Intensity:", 0));
        label_32->setText(QApplication::translate("RenderWindow", "Color:", 0));
        colorButton_aux_light_colour_3->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        pushButton_place_light_by_mouse_3->setText(QApplication::translate("RenderWindow", "Place by mouse", 0));
        groupCheck_aux_light_enabled_4->setTitle(QApplication::translate("RenderWindow", "Light #4", 0));
        label_33->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_34->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_35->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_36->setText(QApplication::translate("RenderWindow", "Intensity:", 0));
        label_37->setText(QApplication::translate("RenderWindow", "Color:", 0));
        colorButton_aux_light_colour_4->setProperty("text", QVariant(QApplication::translate("RenderWindow", "PushButton", 0)));
        pushButton_place_light_by_mouse_4->setText(QApplication::translate("RenderWindow", "Place by mouse", 0));
        groupBox_8->setTitle(QApplication::translate("RenderWindow", "Custom lights options", 0));
        label_38->setText(QApplication::translate("RenderWindow", "Size:", 0));
        label_39->setText(QApplication::translate("RenderWindow", "Visibility:", 0));
        label_134->setText(QApplication::translate("RenderWindow", "Placement distance\n"
"(by mouse):", 0));
        groupBox_9->setTitle(QApplication::translate("RenderWindow", "Volumetric lights", 0));
        label_40->setText(QApplication::translate("RenderWindow", "Visibility of light #2:", 0));
        label_41->setText(QApplication::translate("RenderWindow", "Visibility of light #1:", 0));
        label_42->setText(QApplication::translate("RenderWindow", "Visibility of main light:", 0));
        label_43->setText(QApplication::translate("RenderWindow", "Visibility of light #3:", 0));
        label_44->setText(QApplication::translate("RenderWindow", "Visibility of light #4:", 0));
        checkBox_main_light_volumetric_enabled->setText(QApplication::translate("RenderWindow", "Main light as volumetric", 0));
        checkBox_aux_light_volumetric_enabled_1->setText(QApplication::translate("RenderWindow", "Light #1 as volumetric", 0));
        checkBox_aux_light_volumetric_enabled_2->setText(QApplication::translate("RenderWindow", "Light #2 as volumetric", 0));
        checkBox_aux_light_volumetric_enabled_3->setText(QApplication::translate("RenderWindow", "Light #3 as volumetric", 0));
        checkBox_aux_light_volumetric_enabled_4->setText(QApplication::translate("RenderWindow", "Light #4 as volumetric", 0));
        groupCheck_fake_lights_enabled->setTitle(QApplication::translate("RenderWindow", "Fake lights based on orbit traps", 0));
        label_94->setText(QApplication::translate("RenderWindow", "Size:", 0));
        label_60->setText(QApplication::translate("RenderWindow", "Minimum iteration:", 0));
        label_92->setText(QApplication::translate("RenderWindow", "Intensity:", 0));
        spinbox_fake_lights_visibility_size->setPrefix(QString());
        spinbox_fake_lights_visibility_size->setSuffix(QString());
        label_97->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_91->setText(QApplication::translate("RenderWindow", "Maximum iteration:", 0));
        label_93->setText(QApplication::translate("RenderWindow", "Visibility:", 0));
        label_95->setText(QApplication::translate("RenderWindow", "Orbit trap:", 0));
        label_96->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_98->setText(QApplication::translate("RenderWindow", "z:", 0));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_5), QApplication::translate("RenderWindow", "Lights", 0));
        dockWidget_fractal->setWindowTitle(QApplication::translate("RenderWindow", "Fractal", 0));
        label_formula_iterations_1->setText(QApplication::translate("RenderWindow", "Iterations:", 0));
        groupBox_formula_parameters_1->setTitle(QApplication::translate("RenderWindow", "Formula specific parameters", 0));
        groupBox_formula_transform_1->setTitle(QApplication::translate("RenderWindow", "Transform", 0));
        label_158->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_163->setText(QApplication::translate("RenderWindow", "shift:", 0));
        label_157->setText(QApplication::translate("RenderWindow", "Y-axis rotation:", 0));
        label_159->setText(QApplication::translate("RenderWindow", "x:", 0));
        spinboxd3_formula_rotation_1_z->setPrefix(QString());
        spinboxd3_formula_rotation_1_z->setSuffix(QString());
        spinboxd3_formula_rotation_1_y->setPrefix(QString());
        spinboxd3_formula_rotation_1_y->setSuffix(QString());
        label_167->setText(QApplication::translate("RenderWindow", "y:", 0));
        spinboxd3_formula_rotation_1_x->setPrefix(QString());
        spinboxd3_formula_rotation_1_x->setSuffix(QString());
        label_160->setText(QApplication::translate("RenderWindow", "X-axis rotation:", 0));
        label_162->setText(QApplication::translate("RenderWindow", "Z-axis rotation:", 0));
        label_161->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_165->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_166->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_164->setText(QApplication::translate("RenderWindow", "Repeat", 0));
        label_168->setText(QApplication::translate("RenderWindow", "scale:", 0));
        tabWidget_fractals->setTabText(tabWidget_fractals->indexOf(tab_fractal_formula_1), QApplication::translate("RenderWindow", "Formula #1", 0));
        label_formula_iterations_2->setText(QApplication::translate("RenderWindow", "Iterations:", 0));
        groupBox_formula_parameters_2->setTitle(QApplication::translate("RenderWindow", "Formula specific parameters", 0));
        groupBox_formula_transform_2->setTitle(QApplication::translate("RenderWindow", "Transform", 0));
        label_179->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_180->setText(QApplication::translate("RenderWindow", "shift:", 0));
        label_181->setText(QApplication::translate("RenderWindow", "Y-axis rotation:", 0));
        label_182->setText(QApplication::translate("RenderWindow", "x:", 0));
        spinboxd3_formula_rotation_2_z->setPrefix(QString());
        spinboxd3_formula_rotation_2_z->setSuffix(QString());
        spinboxd3_formula_rotation_2_y->setPrefix(QString());
        spinboxd3_formula_rotation_2_y->setSuffix(QString());
        label_183->setText(QApplication::translate("RenderWindow", "y:", 0));
        spinboxd3_formula_rotation_2_x->setPrefix(QString());
        spinboxd3_formula_rotation_2_x->setSuffix(QString());
        label_184->setText(QApplication::translate("RenderWindow", "X-axis rotation:", 0));
        label_186->setText(QApplication::translate("RenderWindow", "Z-axis rotation:", 0));
        label_185->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_187->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_188->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_189->setText(QApplication::translate("RenderWindow", "Repeat", 0));
        label_214->setText(QApplication::translate("RenderWindow", "scale:", 0));
        tabWidget_fractals->setTabText(tabWidget_fractals->indexOf(tab_fractal_formula_2), QApplication::translate("RenderWindow", "Formula #2", 0));
        label_formula_iterations_3->setText(QApplication::translate("RenderWindow", "Iterations:", 0));
        groupBox_formula_parameters_3->setTitle(QApplication::translate("RenderWindow", "Formula specific parameters", 0));
        groupBox_formula_transform_3->setTitle(QApplication::translate("RenderWindow", "Transform", 0));
        spinboxd3_formula_rotation_3_y->setPrefix(QString());
        spinboxd3_formula_rotation_3_y->setSuffix(QString());
        label_190->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_191->setText(QApplication::translate("RenderWindow", "shift:", 0));
        label_192->setText(QApplication::translate("RenderWindow", "Y-axis rotation:", 0));
        label_193->setText(QApplication::translate("RenderWindow", "x:", 0));
        spinboxd3_formula_rotation_3_z->setPrefix(QString());
        spinboxd3_formula_rotation_3_z->setSuffix(QString());
        label_194->setText(QApplication::translate("RenderWindow", "y:", 0));
        spinboxd3_formula_rotation_3_x->setPrefix(QString());
        spinboxd3_formula_rotation_3_x->setSuffix(QString());
        label_195->setText(QApplication::translate("RenderWindow", "X-axis rotation:", 0));
        label_197->setText(QApplication::translate("RenderWindow", "Z-axis rotation:", 0));
        label_196->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_198->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_199->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_200->setText(QApplication::translate("RenderWindow", "Repeat", 0));
        label_215->setText(QApplication::translate("RenderWindow", "scale:", 0));
        tabWidget_fractals->setTabText(tabWidget_fractals->indexOf(tab_fractal_formula_3), QApplication::translate("RenderWindow", "Formula #3", 0));
        label_formula_iterations_4->setText(QApplication::translate("RenderWindow", "Iterations:", 0));
        groupBox_formula_parameters_4->setTitle(QApplication::translate("RenderWindow", "Formula specific parameters", 0));
        groupBox_formula_transform_4->setTitle(QApplication::translate("RenderWindow", "Transform", 0));
        label_201->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_202->setText(QApplication::translate("RenderWindow", "shift:", 0));
        label_203->setText(QApplication::translate("RenderWindow", "Y-axis rotation:", 0));
        label_204->setText(QApplication::translate("RenderWindow", "x:", 0));
        spinboxd3_formula_rotation_4_z->setPrefix(QString());
        spinboxd3_formula_rotation_4_z->setSuffix(QString());
        spinboxd3_formula_rotation_4_y->setPrefix(QString());
        spinboxd3_formula_rotation_4_y->setSuffix(QString());
        label_205->setText(QApplication::translate("RenderWindow", "y:", 0));
        spinboxd3_formula_rotation_4_x->setPrefix(QString());
        spinboxd3_formula_rotation_4_x->setSuffix(QString());
        label_206->setText(QApplication::translate("RenderWindow", "X-axis rotation:", 0));
        label_208->setText(QApplication::translate("RenderWindow", "Z-axis rotation:", 0));
        label_207->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_209->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_210->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_211->setText(QApplication::translate("RenderWindow", "Repeat", 0));
        tabWidget_fractals->setTabText(tabWidget_fractals->indexOf(tab_fractal_formula_4), QApplication::translate("RenderWindow", "Formula #4", 0));
        tabWidget_fractal->setTabText(tabWidget_fractal->indexOf(tabWidget_fractal_formulas), QApplication::translate("RenderWindow", "Formulas", 0));
        groupCheck_julia_mode->setTitle(QApplication::translate("RenderWindow", "Julia mode", 0));
        label_116->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_113->setText(QApplication::translate("RenderWindow", "Julia constant (c):", 0));
        label_120->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_115->setText(QApplication::translate("RenderWindow", "x:", 0));
        pushButton_get_julia_constant->setText(QApplication::translate("RenderWindow", "Get Julia constant by mouse pointer", 0));
        label_135->setText(QApplication::translate("RenderWindow", "Constant multiplier:", 0));
        spinbox_fractal_constant_factor->setPrefix(QString());
        spinbox_fractal_constant_factor->setSuffix(QString());
        label_139->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_140->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_46->setText(QApplication::translate("RenderWindow", "X-axis rotation:", 0));
        label_138->setText(QApplication::translate("RenderWindow", "fractal position:", 0));
        label_137->setText(QApplication::translate("RenderWindow", "y:", 0));
        spinboxd3_fractal_rotation_x->setPrefix(QString());
        spinboxd3_fractal_rotation_x->setSuffix(QString());
        spinboxd3_fractal_rotation_y->setPrefix(QString());
        spinboxd3_fractal_rotation_y->setSuffix(QString());
        spinboxd3_fractal_rotation_z->setPrefix(QString());
        spinboxd3_fractal_rotation_z->setSuffix(QString());
        label_48->setText(QApplication::translate("RenderWindow", "Z-axis rotation:", 0));
        label_47->setText(QApplication::translate("RenderWindow", "Y-axis rotation:", 0));
        label_repeat_x_2->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_repeat_y_2->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_repeat_z_2->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_145->setText(QApplication::translate("RenderWindow", "Repeat", 0));
        tabWidget_fractal->setTabText(tabWidget_fractal->indexOf(tabWidget_fractal_common), QApplication::translate("RenderWindow", "Options", 0));
        checkBox_hybrid_fractal_enable->setText(QApplication::translate("RenderWindow", "Enable hybrid fractals", 0));
        checkBox_linear_DE_mode->setText(QApplication::translate("RenderWindow", "Linear distance estimation (good for Mandelbox or IFS)", 0));
        groupCheck_boolean_operators->setTitle(QApplication::translate("RenderWindow", "Boolean operators", 0));
        comboBox_boolean_operator_1->clear();
        comboBox_boolean_operator_1->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Intersection (AND)", 0)
         << QApplication::translate("RenderWindow", "Union (OR)", 0)
         << QApplication::translate("RenderWindow", "Complement (1st minus 2nd)", 0)
         << QString()
         << QString()
         << QString()
         << QString()
         << QString()
         << QString()
        );
        label_154->setText(QApplication::translate("RenderWindow", "1st <-> 2nd formula:", 0));
        comboBox_boolean_operator_2->clear();
        comboBox_boolean_operator_2->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Intersection (AND)", 0)
         << QApplication::translate("RenderWindow", "Union (OR)", 0)
         << QApplication::translate("RenderWindow", "Complement (2nd minus 3rd)", 0)
         << QString()
         << QString()
         << QString()
         << QString()
         << QString()
         << QString()
        );
        comboBox_boolean_operator_3->clear();
        comboBox_boolean_operator_3->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Intersection (AND)", 0)
         << QApplication::translate("RenderWindow", "Union (OR)", 0)
         << QApplication::translate("RenderWindow", "Complement (3rd minus 4th)", 0)
         << QString()
         << QString()
         << QString()
         << QString()
         << QString()
         << QString()
        );
        label_155->setText(QApplication::translate("RenderWindow", "2st <-> 3rd formula:", 0));
        label_156->setText(QApplication::translate("RenderWindow", "3rd <-> 4th formula:", 0));
        groupCheck_box_folding->setTitle(QApplication::translate("RenderWindow", "Box Folding", 0));
        label_128->setText(QApplication::translate("RenderWindow", "Folding limit:", 0));
        spinbox_box_folding_limit->setPrefix(QString());
        spinbox_box_folding_limit->setSuffix(QString());
        label_129->setText(QApplication::translate("RenderWindow", "Folding value:", 0));
        spinbox_box_folding_value->setPrefix(QString());
        spinbox_box_folding_value->setSuffix(QString());
        groupCheck_spherical_folding->setTitle(QApplication::translate("RenderWindow", "Spherical Folding", 0));
        label_130->setText(QApplication::translate("RenderWindow", "Other radius:", 0));
        spinbox_spherical_folding_outher->setPrefix(QString());
        spinbox_spherical_folding_outher->setSuffix(QString());
        label_169->setText(QApplication::translate("RenderWindow", "Inner radius:", 0));
        spinbox_spherical_folding_inner->setPrefix(QString());
        spinbox_spherical_folding_inner->setSuffix(QString());
        tabWidget_fractal->setTabText(tabWidget_fractal->indexOf(tabWidget_fractal_hybrid), QApplication::translate("RenderWindow", "Hybrid", 0));
        pushButton_add_primitive_cylinder->setText(QString());
        pushButton_add_primitive_cone->setText(QString());
        pushButton_add_primitive_rectangle->setText(QString());
        pushButton_add_primitive_circle->setText(QString());
        pushButton_add_primitive_box->setText(QString());
        pushButton_add_primitive_water->setText(QString());
        pushButton_add_primitive_plane->setText(QString());
        pushButton_add_primitive_torus->setText(QString());
        pushButton_add_primitive_sphere->setText(QString());
        spinboxd3_all_primitives_rotation_x->setPrefix(QString());
        spinboxd3_all_primitives_rotation_x->setSuffix(QString());
        label_50->setText(QApplication::translate("RenderWindow", "Y-axis rotation:", 0));
        label_141->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_142->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_49->setText(QApplication::translate("RenderWindow", "X-axis rotation:", 0));
        label_144->setText(QApplication::translate("RenderWindow", "y:", 0));
        spinboxd3_all_primitives_rotation_y->setPrefix(QString());
        spinboxd3_all_primitives_rotation_y->setSuffix(QString());
        spinboxd3_all_primitives_rotation_z->setPrefix(QString());
        spinboxd3_all_primitives_rotation_z->setSuffix(QString());
        label_51->setText(QApplication::translate("RenderWindow", "Z-axis rotation:", 0));
        label_143->setText(QApplication::translate("RenderWindow", "all primitives\n"
"position\n"
"(except plane\n"
"and water):", 0));
        tabWidget_fractal->setTabText(tabWidget_fractal->indexOf(tab_primitives), QApplication::translate("RenderWindow", "Primitives", 0));
        dockWidget_rendering_engine->setWindowTitle(QApplication::translate("RenderWindow", "Rendering engine", 0));
        groupBox_4->setTitle(QApplication::translate("RenderWindow", "Common rendering settings", 0));
        label_103->setText(QApplication::translate("RenderWindow", "Max. fractal iterations:", 0));
        checkBox_iteration_threshold_mode->setText(QApplication::translate("RenderWindow", "Stop at maximum iteration", 0));
        checkBox_interior_mode->setText(QApplication::translate("RenderWindow", "Interior mode", 0));
        label_105->setText(QApplication::translate("RenderWindow", "Raymarching step mult.:", 0));
        label_104->setText(QApplication::translate("RenderWindow", "Detail level:", 0));
        label_108->setText(QApplication::translate("RenderWindow", "minimum view distance:", 0));
        label_107->setText(QApplication::translate("RenderWindow", "maximum view distance:", 0));
        label_106->setText(QApplication::translate("RenderWindow", "Smoothness:", 0));
        checkBox_slow_shading->setText(QApplication::translate("RenderWindow", "Non-DE shading mode (slow)", 0));
        groupCheck_constant_DE_threshold->setTitle(QApplication::translate("RenderWindow", "Constant detail size", 0));
        label_99->setText(QApplication::translate("RenderWindow", "distance threshold:", 0));
        groupCheck_limits_enabled->setTitle(QApplication::translate("RenderWindow", "Limits (box)", 0));
        label_110->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_109->setText(QApplication::translate("RenderWindow", "bottom left front corner:", 0));
        label_111->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_112->setText(QApplication::translate("RenderWindow", "z:", 0));
        label_114->setText(QApplication::translate("RenderWindow", "top right back corner:", 0));
        label_117->setText(QApplication::translate("RenderWindow", "x:", 0));
        label_118->setText(QApplication::translate("RenderWindow", "y:", 0));
        label_119->setText(QApplication::translate("RenderWindow", "z:", 0));
        group_netrender->setTitle(QApplication::translate("RenderWindow", "NetRender", 0));
        label_176->setText(QApplication::translate("RenderWindow", "Mode:", 0));
        combo_netrender_mode->clear();
        combo_netrender_mode->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Client", 0)
         << QApplication::translate("RenderWindow", "Server", 0)
        );
        groupBox_netrender_client_config->setTitle(QApplication::translate("RenderWindow", "Client configuration:", 0));
        label_178->setText(QApplication::translate("RenderWindow", "Remote server address:", 0));
        label_212->setText(QApplication::translate("RenderWindow", "Remote server port:", 0));
        bu_netrender_connect->setText(QApplication::translate("RenderWindow", "Connect to server", 0));
        bu_netrender_disconnect->setText(QApplication::translate("RenderWindow", "Disconnect", 0));
        label_->setText(QApplication::translate("RenderWindow", "Status:", 0));
        label_netrender_client_status->setText(QApplication::translate("RenderWindow", "DISABLED", 0));
        groupBox_netrender_server_config->setTitle(QApplication::translate("RenderWindow", "Server configuration:", 0));
        label_216->setText(QApplication::translate("RenderWindow", "Local server port:", 0));
        bu_netrender_start_server->setText(QApplication::translate("RenderWindow", "Launch server and watch for clients", 0));
        bu_netrender_stop_server->setText(QApplication::translate("RenderWindow", "Stop Server", 0));
        label_1->setText(QApplication::translate("RenderWindow", "Status:", 0));
        label_netrender_server_status->setText(QApplication::translate("RenderWindow", "DISABLED", 0));
        label_175->setText(QApplication::translate("RenderWindow", "List of connected clients", 0));
        dockWidget_info->setWindowTitle(QApplication::translate("RenderWindow", "Info", 0));
        label_174->setText(QApplication::translate("RenderWindow", "Histogram of ray-marching step count", 0));
        label_1741->setText(QApplication::translate("RenderWindow", "Histogram of fractal interation count", 0));
        dockWidget_animation->setWindowTitle(QApplication::translate("RenderWindow", "Animation", 0));
        pushButton_render_flight->setText(QApplication::translate("RenderWindow", "Render flight animation", 0));
        pushButton_record_flight->setText(QApplication::translate("RenderWindow", "Record flight path", 0));
        pushButton_delete_all_images->setText(QApplication::translate("RenderWindow", "Delete all images", 0));
        pushButton_show_animation->setText(QApplication::translate("RenderWindow", "Show Animation", 0));
        pushButton_continue_recording->setText(QApplication::translate("RenderWindow", "Continue recording", 0));
        pushButton_flight_refresh_table->setText(QApplication::translate("RenderWindow", "Refresh table", 0));
        label_150->setText(QApplication::translate("RenderWindow", "Path for images:", 0));
        label_147->setText(QApplication::translate("RenderWindow", "inertia:", 0));
        label_146->setText(QApplication::translate("RenderWindow", "speed:", 0));
        label_148->setText(QApplication::translate("RenderWindow", "speed control:", 0));
        comboBox_flight_speed_control->clear();
        comboBox_flight_speed_control->insertItems(0, QStringList()
         << QApplication::translate("RenderWindow", "Relative to distance", 0)
         << QApplication::translate("RenderWindow", "Constant", 0)
        );
        button_selectAnimFlightImageDir->setText(QApplication::translate("RenderWindow", "Select folder", 0));
        spinbox_flight_inertia->setPrefix(QString());
        spinbox_flight_inertia->setSuffix(QString());
        label_151->setText(QApplication::translate("RenderWindow", "seconds per frame:", 0));
        spinbox_flight_sec_per_frame->setPrefix(QString());
        spinbox_flight_sec_per_frame->setSuffix(QString());
        spinbox_flight_rotation_speed->setPrefix(QString());
        spinbox_flight_rotation_speed->setSuffix(QString());
        label_153->setText(QApplication::translate("RenderWindow", "roll speed:", 0));
        spinbox_flight_roll_speed->setPrefix(QString());
        spinbox_flight_roll_speed->setSuffix(QString());
        checkBox_flight_show_thumbnails->setText(QApplication::translate("RenderWindow", "Show thumbnails", 0));
        label_152->setText(QApplication::translate("RenderWindow", "rotation speed:", 0));
        checkBox_flight_add_speeds->setText(QApplication::translate("RenderWindow", "Add flight and rotation speed to parameters\n"
"(needed to continue recording animation)", 0));
        tabWidgetFlightKeyframe->setTabText(tabWidgetFlightKeyframe->indexOf(tab_flight_animation), QApplication::translate("RenderWindow", "Flight animation", 0));
        label_149->setText(QApplication::translate("RenderWindow", "Comming soon", 0));
        tabWidgetFlightKeyframe->setTabText(tabWidgetFlightKeyframe->indexOf(tab_7), QApplication::translate("RenderWindow", "Keyframe animation", 0));
    } // retranslateUi

};

namespace Ui {
    class RenderWindow: public Ui_RenderWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RENDER_WINDOW_H
