package com.example.cilksamples;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.os.Build;

public class MainActivity extends Activity {
	private TextView txtResults;
	private Button btnLinearRecurrence, btnQSort, btnMatrix, btnMatrixMultiply, btnClearResult;
	private OnClickListener handlerLinearRecurrence, handlerClear, handlerQSort , handlerMatrix, handlerMatrixMultiply;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		String sOsArch=System.getProperty("os.arch"); 
		Log.v("CilkSample", sOsArch);

		if (sOsArch.equals("x86_64"))
			setTitle("CilkSample-x64"); 
		
		txtResults = (TextView) this.findViewById(R.id.txtResults);
		btnLinearRecurrence = (Button) this.findViewById(R.id.btnLinearRecurrence);
		btnQSort = (Button) this.findViewById(R.id.btnQSort);
		btnMatrix = (Button) this.findViewById(R.id.btnMatrix);
		btnMatrixMultiply = (Button) this.findViewById(R.id.btnMatrixMultiply);
		btnMatrixMultiply = (Button) this.findViewById(R.id.btnMatrixMultiply);
		btnClearResult = (Button) this.findViewById(R.id.btnClear);

		handlerLinearRecurrence = new View.OnClickListener() {
			public void onClick(View v) {
				long t1, t2, t3;
				
				String results = txtResults.getText().toString();  
				results += "Linear recurrence:\r\n";

				// Initialization: allocate a memory for linear recurrence, initialize the memory, return the memory pointer
				long nn = 5000000; 
				int init_value = 12;
				linear_rec_init(nn);

				// single thread
				t1 = System.currentTimeMillis();
				
				long sx = compute_linear_rec_sequential (nn, init_value);
				t2 = System.currentTimeMillis();
				
				// multiple threads using cilk_for
				long px=  compute_linear_rec_parallel (nn, init_value);
				t3 = System.currentTimeMillis();

				// Release memory
				linear_rec_release();
				
				long msInScalar = t2 - t1;
				results += "\tvalue computed in scalar: " + sx + ", time spent: " + msInScalar + " ms;\r\n";
				
				long msInCilk = t3 - t2;
				results += "\tvalue computed in parallel: " + px + ", time spent: " + msInCilk + " ms;\r\n\r\n";
				
				results += "\tSpeedup: " + (float) Math.round(((msInScalar*1.0)/msInCilk)*100)/100 +"x";
				results += "\r\n\r\n";

				txtResults.setText(results);
			}
		};
		handlerQSort = new View.OnClickListener() {
			public void onClick(View v) {
				String results = txtResults.getText().toString();  
				results += "Quick Sort:\r\n";
				
				int n = 10 * 1000 * 1000;
				qsort_init(n);
				
				long msInScalar = qmain(n, false);
				long msInCilk = qmain(n, true);
				
				qsort_release(); 
				
				results += "\tTime used in scalar: " + msInScalar + 
						"ms\r\n\tTime used in parallel:" + msInCilk+"ms\r\n\t"+
						"Speedup:" + (float) Math.round(((msInScalar*1.0)/msInCilk)*100)/100 +"x";
				results += "\r\n\r\n";
				txtResults.setText(results);
			}			
		};
		handlerMatrix = new View.OnClickListener() {
			public void onClick(View v) {
				String results = "Matrix:\r\n";
				int ii = 687, jj = 1107, kk = 837;
				if (init_matrix_cilk(ii, jj, kk))
				{
					// Using the iterative algorithm
					long msInScalar = matrix_main_native_iter(ii, jj, kk, false);
					long msInCilk = matrix_main_native_iter(ii, jj, kk, true);
					// public native long matrix_main_recur(int ii, int jj, int kk, boolean bUseCilk);
	
					// Release the matrix memories
					release_matrix(); 
	
					results += "\tTime used in scalar: " + msInScalar + 
							"ms\r\n\tTime used in parallel:" + msInCilk+"ms\r\n\t"+
							"Speedup:" + (float) Math.round(((msInScalar*1.0)/msInCilk)*100)/100 +"x";
					results += "\r\n\r\n";
				} else 
					results += "Not enough memory\r\n\r\n";
					
				txtResults.setText(results);
			}			
		};
		handlerMatrixMultiply = new View.OnClickListener() {
			public void onClick(View v) {
				String results = "Matrix Multiply:\r\n";
				
				int nn = 1000;
				if (matrix_init(nn))
				{
					// Using the iterative algorithm
					long msInScalar = matrix_multiplication(nn, false);
					long msInCilk = matrix_multiplication(nn, true);
					
					// Release the matrix memories
					matrix_release(); 
	
					results += "\tTime used in scalar: " + msInScalar + 
							"ms\r\n\tTime used in parallel:" + msInCilk+"ms\r\n\t"+
							"Speedup:" + (float) Math.round(((msInScalar*1.0)/msInCilk)*100)/100 +"x";
					results += "\r\n\r\n";
				} else
					results += "Not enough memory\r\n\r\n";
				
				txtResults.setText(results);
			}
		};
		// clicked "clear" button
		handlerClear = new View.OnClickListener() {
			public void onClick(View v) {
				txtResults.setText("");
			}
		};
		
		btnLinearRecurrence.setOnClickListener(handlerLinearRecurrence);
		btnQSort.setOnClickListener(handlerQSort);
		btnMatrix.setOnClickListener(handlerMatrix);
		btnMatrixMultiply.setOnClickListener(handlerMatrixMultiply);
		btnClearResult.setOnClickListener(handlerClear);
	}
	public native double calculatePI();
	public native double calculatePICilk();
	
	// Linear Recurrence
	// return time in milliseconds used
	public native long compute_linear_rec_sequential(long nn, long x_init);
	// return time in milliseconds used
	public native long compute_linear_rec_parallel(long nn, long x_init);
	public native void linear_rec_init(long nn);
	public native void linear_rec_release();

	// Quick Sort
	// return time used for the sorting in milliseconds
	public native long qmain(int n, boolean bUseCilk);
	public native void qsort_init(int n);
	public native void qsort_release();

	// Matrix
	public native boolean init_matrix_cilk(int i, int j, int k);
	// return time in milliseconds used
	public native long matrix_main_native_iter(int ii, int jj, int kk, boolean bUseCilk);
	// return time in milliseconds used
	public native long matrix_main_recur(int ii, int jj, int kk, boolean bUseCilk);
	public native void release_matrix(); 
	
	// Matrix Multiplication
	// return time in milliseconds used
	public native long matrix_multiplication(int nnMatrixSize, boolean bUseCilk);
	public native boolean matrix_init(int nnMatrixSize);
	public native void matrix_release();

	static {
		System.loadLibrary("gnustl_shared");
		System.loadLibrary("cilkrts");
		System.loadLibrary("CilkSamples");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}
}
