/*
 * Copyright (C) 2014 Intel Corporation. All Rights Reserved.
 *
 * The source code contained or described herein and all
 * documents related to the source code ("Material") are owned by 
 * Intel Corporation or its suppliers or licensors. Title to the
 * Material remains with Intel Corporation or its suppliers and
 * licensors. The Material is protected by worldwide copyright
 * laws and treaty provisions.  No part of the Material may be
 * used, copied, reproduced, modified, published, uploaded,
 * posted, transmitted, distributed,  or disclosed in any way
 * except as expressly provided in the license provided with the
 * Materials.  No license under any patent, copyright, trade
 * secret or other intellectual property right is granted to or
 * conferred upon you by disclosure or delivery of the Materials,
 * either expressly, by implication, inducement, estoppel or
 * otherwise, except as expressly provided in the license
 * provided with the Materials. 
 */
#include "com_example_CilkSamples.h"
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "MYLOG", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "MYLOG", __VA_ARGS__)
#include <cstdlib>
#include <cilk/cilk.h>
#include <iostream>
#include <cstddef>
#include "comm_util.h"
#include "matrix.h"

#define RECURSION_THRESHOLD 10

// a naive, iterative, sequential matrix multiplication algorithm
template<typename T> void multiply_iter_seq(int ii, int jj, int kk, T* A, T* B, T* C)
{
	// Note the loop order. Exchanging the two inner loops degrades performance
	// because of cache access.
    for (int i = 0; i < ii; ++i)
        for (int k = 0; k < kk; ++k)
            for (int j = 0; j < jj; ++j)
                C[i * jj + j] += A[i * kk + k] + B[k * jj + j];
}

// a naive, iterative, parallel matrix multiplication algorithm
template<typename T> void multiply_iter_par(int ii, int jj, int kk, T* A, T* B,
    T* C)
{
    cilk_for(int i = 0; i < ii; ++i)
        for (int k = 0; k < kk; ++k)
            for(int j = 0; j < jj; ++j)
                C[i * jj + j] += A[i * kk + k] + B[k * jj + j];
}

// a recursive, sequential matrix multiplication algorithm
template<typename T> void multiply_rec_seq_helper(int i0, int i1, int j0,
    int j1, int k0, int k1, T* A, ptrdiff_t lda, T* B, ptrdiff_t ldb, T* C,
    ptrdiff_t ldc)
{
    int di = i1 - i0;
    int dj = j1 - j0;
    int dk = k1 - k0;
    if (di >= dj && di >= dk && di >= RECURSION_THRESHOLD) {
        int mi = i0 + di / 2;
        multiply_rec_seq_helper(i0, mi, j0, j1, k0, k1, A, lda, B, ldb, C, ldc);
        multiply_rec_seq_helper(mi, i1, j0, j1, k0, k1, A, lda, B, ldb, C, ldc);
    } else if (dj >= dk && dj >= RECURSION_THRESHOLD) {
        int mj = j0 + dj / 2;
        multiply_rec_seq_helper(i0, i1, j0, mj, k0, k1, A, lda, B, ldb, C, ldc);
        multiply_rec_seq_helper(i0, i1, mj, j1, k0, k1, A, lda, B, ldb, C, ldc);
    } else if (dk >= RECURSION_THRESHOLD) {
        int mk = k0 + dk / 2;
        multiply_rec_seq_helper(i0, i1, j0, j1, k0, mk, A, lda, B, ldb, C, ldc);
        multiply_rec_seq_helper(i0, i1, j0, j1, mk, k1, A, lda, B, ldb, C, ldc);
    } else {
        for (int i = i0; i < i1; ++i)
            for (int k = k0; k < k1; ++k)
                for (int j = j0; j < j1; ++j)
                    C[i * ldc + j] += A[i * lda + k] * B[k * ldb + j];
    }
}

template<typename T> inline void multiply_rec_seq(int ii, int jj, int kk, T* A,
    T* B, T* C)
{
    multiply_rec_seq_helper(0, ii, 0, jj, 0, kk, A, kk, B, jj, C, jj);
}

// a recursive, parallel matrix multiplication algorithm
template<typename T> void multiply_rec_par_helper(int i0, int i1, int j0,
    int j1, int k0, int k1, T* A, ptrdiff_t lda, T* B, ptrdiff_t ldb, T* C,
    ptrdiff_t ldc)
{
    int di = i1 - i0;
    int dj = j1 - j0;
    int dk = k1 - k0;
    if (di >= dj && di >= dk && di >= RECURSION_THRESHOLD) {
        int mi = i0 + di / 2;
        cilk_spawn multiply_rec_par_helper(i0, mi, j0, j1, k0, k1, A, lda, B,
            ldb, C, ldc);
        multiply_rec_par_helper(mi, i1, j0, j1, k0, k1, A, lda, B, ldb, C, ldc);
        cilk_sync;
    } else if (dj >= dk && dj >= RECURSION_THRESHOLD) {
        int mj = j0 + dj / 2;
        cilk_spawn multiply_rec_par_helper(i0, i1, j0, mj, k0, k1, A, lda, B,
            ldb, C, ldc);
        multiply_rec_par_helper(i0, i1, mj, j1, k0, k1, A, lda, B, ldb, C, ldc);
        cilk_sync;
    } else if (dk >= RECURSION_THRESHOLD) {
        int mk = k0 + dk / 2;
        // N.B. These two calls cannot be run in parallel without introducing
        //      a race.
        multiply_rec_par_helper(i0, i1, j0, j1, k0, mk, A, lda, B, ldb, C, ldc);
        multiply_rec_par_helper(i0, i1, j0, j1, mk, k1, A, lda, B, ldb, C, ldc);
    } else {
        for (int i = i0; i < i1; ++i)
            for (int k = k0; k < k1; ++k)
                for (int j = j0; j < j1; ++j)
                    C[i * ldc + j] += A[i * lda + k] * B[k * ldb + j];
    }
}

template<typename T> inline void multiply_rec_par(int ii, int jj, int kk, T* A,
    T* B, T* C)
{
    multiply_rec_par_helper(0, ii, 0, jj, 0, kk, A, kk, B, jj, C, jj);
}

long matrix_main_native_iter(int ii, int jj, int kk, bool bUseCilk)
{
    double *A, *B, *C;

	A = g_Matrix.pA;
	B = g_Matrix.pB;
	C = g_Matrix.pC;

    unsigned long long start_tick, end_tick;

    // Compare various matrix multiplication algorithms on these two inputs.
	long tickUsed;
	if (bUseCilk)
		std::cout << "  Running Iterative Parallel cilk_for version..." ;
	else
		std::cout << "  Running Iterative Sequential version...";

    start_tick = cilk_getticks();
	if (bUseCilk)
		multiply_iter_par(ii, jj, kk, A, B, C);
	else
		multiply_iter_seq(ii, jj, kk, A, B, C);
	end_tick = cilk_getticks();

	tickUsed = (long)(end_tick - start_tick);

	long timeMSUsed = cilk_ticks_to_seconds(tickUsed) * 1000 ; 
	std::cout << " used " << timeMSUsed << " milliseconds." << std::endl;

	return timeMSUsed;
}

long matrix_main_recur(int ii, int jj, int kk, bool bUseCilk)
{
    double *A, *B, *C;

	A = g_Matrix.pA;
	B = g_Matrix.pB;
	C = g_Matrix.pC;

	unsigned long long start_tick, end_tick;

	// Compare various matrix multiplication algorithms on these two inputs.
	long tickUsed; 
	if (bUseCilk)
		std::cout << "  Running Recursive Parallel cilk_spawn version...";
	else
		std::cout << "  Running Recursive Sequential version...";

	start_tick = cilk_getticks();
	if (bUseCilk)
		multiply_rec_par(ii, jj, kk, A, B, C);
	else
		multiply_rec_seq(ii, jj, kk, A, B, C);
	end_tick = cilk_getticks();

	tickUsed = (long)(end_tick - start_tick);
	long timeUsedms = cilk_ticks_to_seconds(tickUsed)*1000; 
	std::cout << " used " << timeUsedms << " milliseconds." << std::endl;

	return timeUsedms;
}

// Initialize the matrixes: allocate the memory and initialize the memory
bool init_matrix_cilk(int ii, int jj, int kk)
{
    double *A, *B, *C;

	// allocation memory and initialize two random input matrices.
	g_Matrix.pA = (double*)calloc(ii* kk, sizeof(double));
	g_Matrix.pB = (double*)calloc(kk* jj, sizeof(double));
	g_Matrix.pC = (double*)calloc(ii* jj, sizeof(double));

	A = g_Matrix.pA;
	B = g_Matrix.pB;
	C = g_Matrix.pC;
	if (A == NULL || B == NULL || C == NULL)
		return false; 

	int nAMax = ii*kk; 
	int nBMax = kk*jj; 

	// Populate A 
	cilk_for(int i = 0; i < nAMax; i++)
		A[i] = (double)((i * i) % 1024 - 512) / 512;

	// Populate A 
	cilk_for(int i = 0; i < nBMax; i++)
		B[i] = (double)((i * i) % 1024 - 512) / 512;

	return true; 
}

bool release_matrix()
{
	free(g_Matrix.pA);
	free(g_Matrix.pB);
	free(g_Matrix.pC);

	return true; 
}

/*
 * Class:     com_example_cilksamples_MainActivity
 * Method:    init_matrix_cilk
 * Signature: (III)Z
 */
JNIEXPORT jboolean JNICALL Java_com_example_cilksamples_MainActivity_init_1matrix_1cilk
(JNIEnv *, jobject, jint ii, jint jj, jint kk)
{
	return init_matrix_cilk(ii, jj, kk);
}

/*
 * Class:     com_example_cilksamples_MainActivity
 * Method:    matrix_main_native_iter
 * Signature: (IIIZ)J
 */
JNIEXPORT jlong JNICALL Java_com_example_cilksamples_MainActivity_matrix_1main_1native_1iter
(JNIEnv *, jobject, jint ii, jint jj, jint kk, jboolean bUseCilk)
{
	return matrix_main_native_iter(ii, jj, kk, bUseCilk);
}

/*
 * Class:     com_example_cilksamples_MainActivity
 * Method:    matrix_main_recur
 * Signature: (IIIZ)J
 */
JNIEXPORT jlong JNICALL Java_com_example_cilksamples_MainActivity_matrix_1main_1recur
(JNIEnv *, jobject, jint ii, jint jj, jint kk, jboolean bUseCilk)
{
	return matrix_main_recur(ii, jj, kk, bUseCilk);
}

/*
 * Class:     com_example_cilksamples_MainActivity
 * Method:    release_matrix
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_com_example_cilksamples_MainActivity_release_1matrix
(JNIEnv *, jobject)
{
	release_matrix();
}
