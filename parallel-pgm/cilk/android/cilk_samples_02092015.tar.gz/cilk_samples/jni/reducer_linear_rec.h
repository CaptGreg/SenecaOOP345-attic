
#include "linear-recurrence.h"
#include <cilk/cilk.h>
#include <cilk/reducer.h>

//reducer to store partial products of the R_k matrices, 
//each R_k matrix is represented by value of a_k and b_k, 
class Recurrence_Reducer
{
public:
	// Per-strand view of the data
	class View
	{
		friend class Recurrence_Reducer;

	public:
		//Identity value for reducer: a = 0, b = 1,
		//which gives a unit 2x2 matrix
		View() : a(0), b(1) { }

	private:
		long a;
		long b;
	};

public:
	// View of reducer data
	struct Monoid : cilk::monoid_base<View>
	{
		static void reduce(View *left, View *right) {
			left->a = right->a + left->a * right->b;
			left->b = right->b * left->b;
		}
	};

private:
	// Hyperobject to serve up views
	cilk::reducer<Monoid> imp_;

public:
	Recurrence_Reducer() : imp_() { }

	// Update operations
	inline Recurrence_Reducer& cal_next(const Para& value) {
		View &v = imp_.view();

		v.a = value.a + value.b * v.a;
		v.b = value.b * v.b;
		return *this;
	}
	long get_a() { return imp_.view().a; }
	long get_b() { return imp_.view().b; }
};
