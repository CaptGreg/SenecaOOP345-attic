/*
 * linear-recurrence.cpp
 *
 * Copyright (C) 2014 Intel Corporation. All Rights Reserved.
 *
 * The source code contained or described herein and all
 * documents related to the source code ("Material") are owned by 
 * Intel Corporation or its suppliers or licensors. Title to the
 * Material remains with Intel Corporation or its suppliers and
 * licensors. The Material is protected by worldwide copyright
 * laws and treaty provisions.  No part of the Material may be
 * used, copied, reproduced, modified, published, uploaded,
 * posted, transmitted, distributed,  or disclosed in any way
 * except as expressly provided in the license provided with the
 * Materials.  No license under any patent, copyright, trade
 * secret or other intellectual property right is granted to or
 * conferred upon you by disclosure or delivery of the Materials,
 * either expressly, by implication, inducement, estoppel or
 * otherwise, except as expressly provided in the license
 * provided with the Materials. 
 */

/*
   A demonstration of an Intel(R) Cilk(TM) Plus reducer.
 
   This example demonstrates the use of Intel(R) Cilk(TM) Plus reducerss to compute a
   linear recurrence relation in parallel.  Specifically, 
   given x_0, {a_1, ... , a_n}, and {b_1, ... , b_n}, the program
   computes x_n according to the following recurrence relation:

        x_k = a_k + b_k * x_{k-1}   for 1 <= k <= n.
     
   You would think that the recurrence is inherently sequential, and
   that there is no way to compute x_k without knowing x_{k-1}.
   However, the recurrence can be solved in parallel by first
   rewriting it according to the following trick.  Write the recurrence
   as a linear recurrence over 2x1 vectors:

        [ 1   ]       [ 1    0   ]    [    1    ]
        [     ]   =   [          ] *  [         ]
        [ x_k ]       [ a_k  b_k ]    [ x_{k-1} ]

   Because matrix product is associative, it is clear that the
   problem can be solved  by first computing the product
   of the n 2x2 matrices

                [ 1    0   ] 
         R_k =  [          ]  ,
                [ a_k  b_k ] 

   which can be computed in parallel.

   The reducer Recurrence_Reducer below stores partial products
   of the R_k matrices, and effects the associative reduction via
   a specialized matrix multiplication.
*/
#include "com_example_CilkSamples.h"
#include <cstdlib>
#include "comm_util.h"
#include "reducer_linear_rec.h"
#include "linear-recurrence.h"


// parallel code to compute linear recurrence
//      return time spent in miniseconds
long compute_linear_rec_parallel (int nn, long x_init)
{
	Para *list = g_plist;
	long px;

    // long start_tick = cilk_getticks();

	Recurrence_Reducer rr;
    cilk_for(int i = 0; i < nn; ++i) {
        rr.cal_next(list[i]);
    }

    //long end_tick = cilk_getticks();
	//long timeMS = cilk_ticks_to_seconds(end_tick - start_tick) * 1000;
    px = rr.get_a() + rr.get_b() * x_init;

	return px;
}

inline long cal_next(long a, long b, long x) {
    return a + b * x;
}

// sequential code to compute linear recurrence
// return time spent in 
long compute_linear_rec_sequential (int nn, long x_init)
{
    //long start_tick = cilk_getticks();
	//long retTimeMS;
	Para *list = g_plist;
	long sx;
	
	long x = x_init;
    for(int i = 0; i < nn; ++i) {
       x = cal_next(list[i].a, list[i].b, x);
    }

	//long end_tick = cilk_getticks();
	//retTimeMS = cilk_ticks_to_seconds(end_tick-start_tick) * 1000;
	sx = x;

    return sx;
}

void linear_rec_init(int nn)
{
	g_plist = NULL;

    // allocate space for parameter list
    Para *plist = new Para[nn];
    if (plist == NULL) {
        return ;
    }

    // initialize parameter list with random numbers
    cilk_for(int i = 0; i < nn; i++) {
        plist[i].a = rand() % 22 - 10 ;
        plist[i].b = rand() % 13 - 6 ;
    }
	g_plist = plist;

	return ;
}

void linear_rec_release()
{
	delete[] g_plist;
}

JNIEXPORT jlong JNICALL Java_com_example_cilksamples_MainActivity_compute_1linear_1rec_1sequential
  (JNIEnv *, jobject, jlong nn, jlong x_init)
{
	return compute_linear_rec_sequential (nn, x_init);
}

/*
 * Class:     com_example_cilksamples_MainActivity
 * Method:    compute_linear_rec_parallel
 * Signature: (IJ)J
 */
JNIEXPORT jlong JNICALL Java_com_example_cilksamples_MainActivity_compute_1linear_1rec_1parallel
  (JNIEnv *jenv, jobject jobj, jlong nn, jlong x_init)
{
	return compute_linear_rec_parallel (nn, x_init);
}

/*
 * Class:     com_example_cilksamples_MainActivity
 * Method:    linear_rec_init
 * Signature: (I)V
 */
JNIEXPORT void JNICALL Java_com_example_cilksamples_MainActivity_linear_1rec_1init
  (JNIEnv *, jobject, jlong nn)
{
	linear_rec_init(nn);
	return;
}

/*
 * Class:     com_example_cilksamples_MainActivity
 * Method:    linear_rec_release
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_com_example_cilksamples_MainActivity_linear_1rec_1release
  (JNIEnv *, jobject)
{
	linear_rec_release();
	return;
}

