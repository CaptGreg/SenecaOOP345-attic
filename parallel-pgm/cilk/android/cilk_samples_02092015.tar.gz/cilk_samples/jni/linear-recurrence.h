// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the LINEARRECURRENCEDLL_EXPORTS
// symbol defined on the command line. This symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// LINEARRECURRENCEDLL_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.

#pragma once

//structure to hold parameter a, b
typedef struct _Para {
	long a;
	long b;
} Para;

Para* g_plist;

//sequential code to compute linear recurrence
long compute_linear_rec_sequential (int nn, long* psr, long x_init);
long compute_linear_rec_parallel (int nn, long* pr, long x_init);

// Initialization: allocate a memory for linear recurrence, initialize the memory, return the memory pointer
void linear_rec_init(int n);

// Release memory
void linear_rec_release();
