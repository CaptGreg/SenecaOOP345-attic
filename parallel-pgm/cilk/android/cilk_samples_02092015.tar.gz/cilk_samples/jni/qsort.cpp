/*
 * qsortDll.cpp : Defines the exported functions for the DLL application.
 *
 * An implementation of quicksort using Intel(R) Cilk(TM) Plus parallelization.
 *
 * Copyright (C) 2014 Intel Corporation. All Rights Reserved.
 *
 * The source code contained or described herein and all
 * documents related to the source code ("Material") are owned by 
 * Intel Corporation or its suppliers or licensors. Title to the
 * Material remains with Intel Corporation or its suppliers and
 * licensors. The Material is protected by worldwide copyright
 * laws and treaty provisions.  No part of the Material may be
 * used, copied, reproduced, modified, published, uploaded,
 * posted, transmitted, distributed,  or disclosed in any way
 * except as expressly provided in the license provided with the
 * Materials.  No license under any patent, copyright, trade
 * secret or other intellectual property right is granted to or
 * conferred upon you by disclosure or delivery of the Materials,
 * either expressly, by implication, inducement, estoppel or
 * otherwise, except as expressly provided in the license
 * provided with the Materials. 
 */
#include "com_example_CilkSamples.h"
#include "qsort.h"
#include <cilk/cilk.h>
#include "comm_util.h"
#include <algorithm>
#include <iostream>
#include <iterator>
#include <functional>

// Sort the range between bidirectional iterators begin and end.
// end is one past the final element in the range.
// Use the Quick Sort algorithm, using recursive divide and conquer.
// This function is NOT the same as the Standard C Library qsort() function.
// This implementation is pure C++ code before Intel(R) Cilk(TM) Plus conversion.
void sample_qsort_cilk(int * begin, int * end)
{
    if (begin != end) {
        --end;  // Exclude last element (pivot) from partition
        int * middle = std::partition(begin, end,
                          std::bind2nd(std::less<int>(), *end));
        using std::swap;
        swap(*end, *middle);    // move pivot to middle
		cilk_spawn sample_qsort_cilk(begin, middle);
		sample_qsort_cilk(++middle, ++end); // Exclude pivot and restore end
        cilk_sync;
    }
}

void sample_qsort_serial(int * begin, int * end)
{
	if (begin != end) {
		--end;  // Exclude last element (pivot) from partition
		int * middle = std::partition(begin, end,
			std::bind2nd(std::less<int>(), *end));
		using std::swap;
		swap(*end, *middle);    // move pivot to middle
		sample_qsort_serial(begin, middle);
		sample_qsort_serial(++middle, ++end); // Exclude pivot and restore end
	}
}

// checking if the sorting succeeded and print out the message if not. 
bool sorting_succeeded(int* arr, int n)
{
	// Confirm that a is sorted and that each element contains the index.
	for (int i = 0; i < n - 1; ++i) {
		if (arr[i] >= arr[i + 1] || arr[i] != i) {
			std::cout << "    Sort failed at location: i=" << i << " a[i] = "
				<< arr[i] << " a[i+1] = " << arr[i + 1] << std::endl;
			return false;
		}
	}
	return true;
}

// A simple test harness 
long  qmain(int n, bool bUseCilk)
{
	int* a = g_pArr;

    std::random_shuffle(a, a + n);
	std::cout << "Sorting " << n << " integers " << (bUseCilk? "using Intel(R) Cilk Plus technology: cilk_spawn": "using serial") << std::endl;

	unsigned long long start_ticks, end_ticks;
	start_ticks = cilk_getticks();
	if (bUseCilk)
		sample_qsort_cilk(a, a + n);
	else 
		sample_qsort_serial(a, a + n);
	end_ticks = cilk_getticks();

    // Confirm that a is sorted
	if (sorting_succeeded(a, n)) {
		long timeMS = cilk_ticks_to_seconds(end_ticks - start_ticks)*1000; 
		std::cout << "    Sort succeeded in " << timeMS << " milliseconds." << std::endl;
		return timeMS; 
	}

    return 0;
}

void qsort_init(int n)
{
	if (n <= 0) 
		return;

	// initializing
	int* a = new int[n];
	cilk_for(int i = 0; i < n; ++i)
		a[i] = i;
	g_pArr = a;

	return ;
}

void qsort_release()
{
	delete[] g_pArr;
}

JNIEXPORT jlong JNICALL Java_com_example_cilksamples_MainActivity_qmain
  (JNIEnv *, jobject, jint nn, jboolean objBool)
{
	return qmain(nn, objBool);
}
JNIEXPORT void JNICALL Java_com_example_cilksamples_MainActivity_qsort_1init
  (JNIEnv *, jobject, jint nn)
{
	qsort_init(nn);
}

JNIEXPORT void JNICALL Java_com_example_cilksamples_MainActivity_qsort_1release
  (JNIEnv *, jobject)
{
	qsort_release();
}

