//==============================================================
//
// SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT,
// http://software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
//
// Copyright 2010-2013 Intel Corporation
//
// THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
//
// ===============================================================

// Initial conditions: rectangle (for image) = { (-2.5, -0.875), (1, 0.875) }
//                     height = 1024
//                     width = 2048
//                     max_depth = 100
//
// Finds the mandelbrot set given initial conditions, and saves results to a bmp image.
// The real portion of the complex number is the x-axis, and the imaginary portion is the y-axis
//
// You can optionally compile with GCC and MSC, but just the linear, scalar version will compile
// and it will not have all optimizations

#include <cmath>
#include <complex>
#ifdef __INTEL_COMPILER
#include <cilk/cilk.h>
#endif
#include "mandelbrot.h"
#include "bmp_image.h"
#include "timer.h"

#include <stdio.h>
#include <stdlib.h>
#include <emmintrin.h>

int main(int argc, char* argv[]) {
	double x0 = -2.5;
	double y0 = -0.875;
	double x1 = 1;
	double y1 = 0.875;
	int height = 10240;
	// Width should be a multiple of 8
	int width = 20480;
	assert(width%8==0);
	int max_depth = 100;

#ifndef __INTEL_COMPILER
	CUtilTimer timer;
	printf("This example will check how many iterations of z_n+1 = z_n^2 + c a complex set will remain bounded.\n");
#ifdef PERF_NUM
	double avg_time = 0;
	for(int i=0; i<5; ++i) {
#endif
	printf("Starting serial, scalar Mandelbrot...\n");
	io::BMPImage image(width, height, 8);
	timer.start();
	unsigned char * output = serial_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
	timer.stop();
	printf("Calculation finished. Time taken is %.0fms\n", timer.get_time()*1000.0);
	printf("Saving image...\n\n");
	image.from_gray(output);
	image.save("mandelbrot_serial.bmp");
	image.valsig("mandelbrot_serial.valsig");
	_mm_free(output);
#ifdef PERF_NUM
	avg_time += timer.get_time();
	}
	printf("avg time: %.0fms\n", avg_time*1000.0/5);
#endif
#else
	int option = 0;
#ifndef PERF_NUM
	// Checks to see if option was given at command line
	if(argc>1) {
		// Prints out instructions and quits
		if(argv[1][0] == 'h') {
		printf("This example will check how many iterations of z_n+1 = z_n^2 + c a complex set will remain bounded. Pick which parallel method you would like to use.\n");
		    printf("[0] all tests\n[1] serial/scalar\n[2] serial/array notation\n[3] cilk_for/scalar\n[4] cilk_for/array notation\n");
#ifdef _WIN32
			system("PAUSE");
#endif
			return 0;
		}
		else {			
		option = atoi(argv[1]);
		}
	}
	// If no options are given, prompt user to choose an option
	else {
		printf("This example will check how many iterations of z_n+1 = z_n^2 + c a complex set will remain bounded. Pick which parallel method you would like to use.\n");
		printf("[0] all tests\n[1] serial/scalar\n[2] serial/array notation\n[3] cilk_for/scalar\n[4] cilk_for/array notation\n  > ");
		scanf("%i", &option);
	}
#endif // !PERF_NUM

	CUtilTimer timer;
	double serial_time, vec_time, cilk_time, cilk_vec_time;

	// Load up the Intel(R) Cilk(TM) Plus runtime to to get accurate performance numbers
	double g = 2.0;
	cilk_for (int i = 0; i < 100; i++) {
		g /= sin(g);
	}

	io::BMPImage image(width, height, 8);
	unsigned char* output;
	switch (option) {
	case 0:
#ifdef PERF_NUM
		double avg_time[4];
		avg_time[:] = 0.0;
		for(int i=0; i<5; ++i) {
#endif
        printf("\nRunning all tests\n");

		printf("Starting serial, scalar Mandelbrot...\n");
		timer.start();
		output = serial_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		serial_time = timer.get_time();
		printf("Calculation finished. Time taken is %.0fms\n", serial_time*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_serial.bmp");
		image.valsig("mandelbrot_serial.valsig");
		_mm_free(output);

        printf("\nStarting pragma simd Mandelbrot...\n");
		timer.start();
		output = simd_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		vec_time = timer.get_time();
		printf("Calculation finished. Time taken is %.0fms\n", vec_time*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_simd.bmp");
		image.valsig("mandelbrot_simd.valsig");
		_mm_free(output);

        printf("\nStarting cilk_for Mandelbrot...\n");
		timer.start();
		output = cilk_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		cilk_time = timer.get_time();
		printf("Calculation finished. Time taken is %.0fms\n", cilk_time*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_cilk.bmp");
		image.valsig("mandelbrot_cilk.valsig");
		_mm_free(output);

        printf("\nStarting cilk_for + pragma simd Mandelbrot...\n");
		timer.start();
		output = cilk_simd_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		cilk_vec_time = timer.get_time();
		printf("Calculation finished. Time taken is %.0fms\n", cilk_vec_time*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_cilk_simd.bmp");
		image.valsig("mandelbrot_cilk_simd.valsig");
		_mm_free(output);
#ifdef PERF_NUM
		avg_time[0] += serial_time;
		avg_time[1] += vec_time;
		avg_time[2] += cilk_time;
		avg_time[3] += cilk_vec_time;
		}
		printf("avg time: %.0f\n", avg_time[:]*1000.0/5);
#endif
		break;

	case 1:
		printf("Starting serial, scalar Mandelbrot...\n");
		timer.start();
		output = serial_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		printf("Calculation finished. Time taken is %.0fms\n", timer.get_time()*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_serial.bmp");
		image.valsig("mandelbrot_serial.valsig");
		_mm_free(output);
		break;

	case 2:
        printf("\nStarting pragma simd Mandelbrot...\n");
		timer.start();
		output = simd_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		printf("Calculation finished. Time taken is %.0fms\n", timer.get_time()*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_simd.bmp");
		image.valsig("mandelbrot_simd.valsig");
		_mm_free(output);
		break;

	case 3:
        printf("\nStarting cilk_for Mandelbrot...\n");
		timer.start();
		output = cilk_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		printf("Calculation finished. Time taken is %.0fms\n", timer.get_time()*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_cilk.bmp");
		image.valsig("mandelbrot_cilk.valsig");
		_mm_free(output);
		break;

	case 4:
        printf("\nStarting cilk_for + pragma simd Mandelbrot...\n");
		timer.start();
		output = cilk_simd_mandelbrot(x0, y0, x1, y1, width, height, max_depth);
		timer.stop();
		printf("Calculation finished. Time taken is %.0fms\n", timer.get_time()*1000.0);
		printf("Saving image...\n");
		image.from_gray(output);
		image.save("mandelbrot_cilk_simd.bmp");
		image.valsig("mandelbrot_cilk_simd.valsig");
		_mm_free(output);
		break;

	default:
        printf("Please pick a valid option\n");
		break;
	}
#endif

#ifdef _WIN32
    system("PAUSE");
#endif
    return 0; 
}
