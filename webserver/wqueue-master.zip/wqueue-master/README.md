wqueue
======

Example source code for the article 'Multithreaded Work Queue in C++'

Build
=====

1. Get the threads code at https://github.com/vichargrave/threads.git.
2. Place the threads and wqueue directories at the same directory level, 
   e.g. ${HOME}/src/threads and ${HOME}/src/wqueue.
3. cd to ${HOME}/src/wqueue.
4. Type 'make'.
