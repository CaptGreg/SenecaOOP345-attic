threads
=======

Example source code for the article 'Java Style Threads Class in C++'.

Build
=====

1. cd to the 'threads' directory.
2. Type 'make'.
3. Run the test application 'thread'.
