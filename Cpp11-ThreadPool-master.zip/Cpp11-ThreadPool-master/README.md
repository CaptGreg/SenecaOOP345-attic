ThreadPool
==========

A basic thread pool built using C++11 standard features.
