#include "readerwriterqueue.h"

using namespace moodycamel;

#include <exception>
#include <fstream>
#include <thread>
#include <cstdlib>		// rand()
#include <unistd.h>		// usleep()

void unpredictableDelay(int extra = 0)
{
/*	if ((rand() & 4095) == 0) {
		usleep(2000 + extra);	// in microseconds
	}*/
}

int main(int argc, char** argv)
{
	std::ofstream log("log.txt");

	try {
		for (unsigned int i = 0; true; ++i) {
			log << "Test #" << i << std::endl;

			ReaderWriterQueue<unsigned long long> q((rand() % 32) + 1);
	
			std::thread writer([&]() {
				for (unsigned long long j = 0; j < 1024ULL * 1024ULL * 32ULL; ++j) {
					unpredictableDelay(500);
					q.enqueue(j);
				}
			});
	
			std::thread reader([&]() {
				unsigned long long element;
				for (unsigned long long j = 0; j < 1024ULL * 1024ULL * 32ULL;) {
					if ((j & (1024 * 1024 * 16 - 1)) == 0) {
						log << "  ... iteration " << j << std::endl;
					}
					unpredictableDelay();
					if (q.try_dequeue(element)) {
						if (element != j) {
							log << "  ERROR DETECTED: Expected to read " << j << " but found " << element << std::endl;
						}
						++j;
					}
				}
				if (q.try_dequeue(element)) {
					 log << "  ERROR DETECTED: Expected queue to be empty" << std::endl;
				}
			});
		
			writer.join();
			reader.join();
		}
	}
	catch (std::exception const& ex) {
		log << "  ERROR DETECTED: Exception thrown: " << ex.what() << std::endl;
	}
	
	return 0;
}
