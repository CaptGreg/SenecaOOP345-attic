
/*
 * Copyright (C) 2010-2014 Intel Corporation. All Rights Reserved.
 *
 * The source code contained or described herein and all
 * documents related to the source code ("Material") are owned by
 * Intel Corporation or its suppliers or licensors. Title to the
 * Material remains with Intel Corporation or its suppliers and
 * licensors. The Material is protected by worldwide copyright
 * laws and treaty provisions.  No part of the Material may be
 * used, copied, reproduced, modified, published, uploaded,
 * posted, transmitted, distributed,  or disclosed in any way
 * except as expressly provided in the license provided with the
 * Materials.  No license under any patent, copyright, trade
 * secret or other intellectual property right is granted to or
 * conferred upon you by disclosure or delivery of the Materials,
 * either expressly, by implication, inducement, estoppel or
 * otherwise, except as expressly provided in the license
 * provided with the Materials.
 *
 * Part of the vec_samples tutorial. See "Tutorial: Auto-vectorization"
 * in the Intel(R) C++ Compiler Tutorials document
 */
#include <time.h>
#include "init.h"

//routine to initialize an array with data
void init_matrix(int row, int col, FTYPE off, FTYPE  a[][COLWIDTH])
{
	int i,j;

	for (i=0; i< row;i++) {
		for (j=0; j< col;j++) {
			a[i][j] = fmod(i*j+off,10.0);
		}
	}
	if (COLBUF>0)
		for  (i=0;i<row;i++)
			for (j=col;j<COLWIDTH;j++)
				a[i][j]=0.0;
}

void init_array(int length, FTYPE off, FTYPE a[])
{
	int i;

	for (i=0; i< length;i++)
		a[i] = fmod(i+off,10.0);
	if (COLBUF>0)
		for  (i=length;i<COLWIDTH;i++)
				a[i]=0.0;
}

/*
// Calculate time taken by a request
long gettickcount()
{
// Calculate time taken by a request
struct timespec requestStart;
clock_gettime(CLOCK_MONOTONIC, &requestStart);
return requestStart.tv_nsec/1000;

}
*/

// from android samples
/* return current time in milliseconds */
long gettickcount(void) {

    struct timespec res;
    clock_gettime(CLOCK_REALTIME, &res);
    return 1000 * res.tv_sec + res.tv_nsec / 1e6;
    //return res.tv_nsec/1000 ;

}
