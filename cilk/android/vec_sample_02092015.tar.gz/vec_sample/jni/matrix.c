#include <jni.h>
#include <android/log.h>
#include <stdlib.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "MYLOG", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "MYLOG", __VA_ARGS__)

/*extern "C" {*/
jlong Java_com_intel_cilkmatrixmultiply_MainActivity_multiplyMatrixNative(
		JNIEnv * env, jobject obj, jint mode)
{

	jlong s;

	// multiply matrix
	if (mode == 1)
		s = fvec_matrix();
	else
		s = fscal_matrix();

//	LOGI("LogSum: %lld\n", s);
	return s;
}
/*}*/


