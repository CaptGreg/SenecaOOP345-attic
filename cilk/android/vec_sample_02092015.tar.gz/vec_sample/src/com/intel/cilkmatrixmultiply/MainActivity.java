package com.intel.cilkmatrixmultiply;

import com.intel.matrixmultiply.R;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {
	private TextView txt;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		String sOsArch=System.getProperty("os.arch"); 
		Log.v("VecSample", sOsArch);

		if (sOsArch.equals("x86_64"))
			setTitle("VecSample-x64"); 

		txt = (TextView) this.findViewById(R.id.txt);
	}

	public native long multiplyMatrixNative(int mode);

	static {
		System.loadLibrary("matrixmultiply");
	}

	// Button clicked
	public void onClickButtons(View v) {
		long time=0, time2=0;
		long duration=0, duration2=0;
		String results, results2;
		long sum2 = 0;
		long sum = 0;


		// Matrix multiply Scalar
		time2 = System.currentTimeMillis();
		sum2 = multiplyMatrixNative(0);
		duration2 = System.currentTimeMillis() - time2;


		// Matrix multiply Vector
		time = System.currentTimeMillis();
		sum = multiplyMatrixNative(1);
		duration = System.currentTimeMillis() - time;
		//results = "Vectorized Time: " + duration + ", " + "Sum: " + sum;
		results = "Vectorized Time: " + duration;
		
		
		// Show results
		//results2 = "\nScalar Computation\nScalarTime: " + duration2 + ", " + "Sum: " + sum2;
		results2 = "\nScalar Computation Results\nScalarTime: " + duration2;
		txt.setText(results + results2);
	}
}
