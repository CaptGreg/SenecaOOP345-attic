#!/bin/sh

if [ "$1" == "rebuild" ]  
then
	android update project -p . -n VecMatrixMultiply -s -t android-19; ndk-build clean; ndk-build V=1 -B; ant debug;  adb install -r bin\CilkSamples-debug.apk 
fi
if [ "$1" == "run" ]  
then
	adb shell am start -n com.intel.cilkmatrixmultiply/com.intel.cilkmatrixmultiply.MainActivity
fi

if [ "$1" == "help" ]  
then
	echo build-osx rebuild|run
fi
