//==============================================================
//
// SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT,
// http://software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
//
// Copyright 2012-2013 Intel Corporation
//
// THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
// NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
//
// ===============================================================
// This sample is derived from code published by Bernt Arne Odegaard,
// http://finance.bi.no/~bernt/gcc_prog/recipes/recipes/

#include "black_scholes.h"
#include "timer.h"
#include <cstdio>
#include <cstdlib>
#ifdef __INTEL_COMPILER
#include <cilk/cilk.h>
#endif
#include <xmmintrin.h>

// Print helper function
void print_average(float *CallResult, float *PutResult, double time);

int main(int argc, char* argv[])
{
	float *CallResult = (float *)_mm_malloc(c_num_options*sizeof(float), 32);
	float *PutResult  = (float *)_mm_malloc(c_num_options*sizeof(float), 32);
	float *StockPrice    = (float *)_mm_malloc(c_num_options*sizeof(float), 32);
	float *OptionStrike  = (float *)_mm_malloc(c_num_options*sizeof(float), 32);
	float *OptionYears   = (float *)_mm_malloc(c_num_options*sizeof(float), 32);

	// Randomly initialize variables within specified bounds
	srand(5); 
	for(int i = 0; i<c_num_options; ++i) {
		CallResult[i] = 0.0f;
		PutResult[i]  = -1.0f;
		StockPrice[i]    = RandFloat(5.0f, 30.0f);
		OptionStrike[i]  = RandFloat(1.0f, 100.0f);
		OptionYears[i]   = RandFloat(0.25f, 10.0f);
	}

#if 1
	
#ifndef __INTEL_COMPILER // Using cl/gcc
	CUtilTimer timer;
#ifdef PERF_NUM
	double avg_time = 0;
	for(int i=0; i<5; ++i) {
#endif // PERF_NUM
	printf("The Black Scholes Formula estimates the price of an option over time. It can be used in a wide variety of financial applications.\n");
	printf("Starting serial, scalar sample...\n");
	timer.start();
	black_scholes_serial(StockPrice, OptionStrike, OptionYears, CallResult, PutResult);
	timer.stop();
	print_average(CallResult, PutResult, timer.get_time()*1000.0);
#ifdef PERF_NUM
	avg_time += timer.get_time();
	}
	printf("avg time: %.0fms\n", avg_time*1000.0/5);
#endif // PERF_NUM
#else // __INTEL_COMPILER is defined, using icl/icpc
	int option = 0;
	// If PERF_NUM is defined, then no options taken...run all tests
#ifndef PERF_NUM
	// Checks to see if option was given at command line
	if(argc>1) {
		// Prints out instructions and quits
		if(argv[1][0] == 'h') {
			printf("The Black Scholes Formula estimates the price of an option over time. It can be used in a wide variety of financial applications.\n");
		    printf("[0] both tests\n[1] serial\n[2] cilk_for\n");
#ifdef _WIN32
			system("PAUSE");
#endif // _WIN32
			return 0;
		}
		// option is assumed an option
		else {			
			option = atoi(argv[1]);
		}
	}
	// If no options are given, prompt user to choose an option
	else {
		printf("The Black Scholes Formula estimates the price of an option over time. It can be used in a wide variety of financial applications.\n");
		printf("[0] both tests\n[1] serial\n[2] cilk_for\n  > ");
		scanf("%i", &option);
	}
#endif // !PERF_NUM

	CUtilTimer timer;
	double serial_time, cilk_time;

	// Load up the Intel(R) Cilk(TM) Plus runtime to to get accurate performance numbers
	double g = 2.0;
	cilk_for (int i = 0; i < 100; i++) {
		g /= sin(g);
	}

	switch (option) {
	case 0:
#ifdef PERF_NUM
		double avg_time[2];
		avg_time[:] = 0.0;
		for(int i=0; i<5; ++i) {
#endif // PERF_NUM
        printf("\nRunning all tests\n");

		printf("Starting serial sample...\n");
		timer.start();
		black_scholes_serial(StockPrice, OptionStrike, OptionYears, CallResult, PutResult);
		timer.stop();
		serial_time = timer.get_time();
		print_average(CallResult, PutResult, serial_time*1000.0);

        printf("\nStarting cilk_for sample...\n");
		timer.start();
		black_scholes_cilk(StockPrice, OptionStrike, OptionYears, CallResult, PutResult);
		timer.stop();
		cilk_time = timer.get_time();
		print_average(CallResult, PutResult, cilk_time*1000.0);

#ifdef PERF_NUM
		avg_time[0] += serial_time;
		avg_time[1] += cilk_time;
		}
		printf("avg time: %.0f\n", avg_time[:]*1000.0/5);
#endif // PERF_NUM
		break;
	case 1:
		printf("Starting serial, scalar sample...\n");
		timer.start();
		black_scholes_serial(StockPrice, OptionStrike, OptionYears, CallResult, PutResult);
		timer.stop();
		print_average(CallResult, PutResult, timer.get_time()*1000.0);
		break;

	case 2:
        printf("\nStarting cilk_for sample...\n");
		timer.start();
		black_scholes_cilk(StockPrice, OptionStrike, OptionYears, CallResult, PutResult);
		timer.stop();
		print_average(CallResult, PutResult, timer.get_time()*1000.0);
		break;

	default:
        printf("Please pick a valid option\n");
		break;
	}
#endif // __INTEL_COMPILER is defined
	
#else
	CUtilTimer timer;
	timer.start();
	black_scholes_cilk(StockPrice, OptionStrike, OptionYears, CallResult, PutResult);
	timer.stop();
	double time = timer.get_time();

    printf("Completed pricing %f million options in %f seconds:\n", 2*(c_num_iterations)*(c_num_options/1e6), time);
    printf("Parallel version runs at %7.5f Billion option per second.\n", (2.0f*(c_num_iterations)*c_num_options)/(1e9*time));
#endif
	
	_mm_free(CallResult);
	_mm_free(PutResult);
	_mm_free(StockPrice);
	_mm_free(OptionStrike);
	_mm_free(OptionYears);
	
#ifdef _WIN32
    system("PAUSE");
#endif
    return 0; 
}

// Prints avg call and put + time taken
void print_average(float *CallResult, float *PutResult, double time) {
	float sum_call=0.f, sum_put=0.f;
	for(int i=0; i<c_num_options; ++i) {
		sum_call += CallResult[i];
		sum_put += PutResult[i];
	}
	printf("Calculation finished. Average call price: %.6f,  average put price: %.6f\nTime to calculate %.0f million options: %.0fms\n",
		sum_call/c_num_options, sum_put/c_num_options, 2*(c_num_iterations)*(c_num_options/1e6), time);
}

// Returns uniformly distributed random float between [low, high]
inline float RandFloat(float low, float high){
    float t = (float)rand() / (float)RAND_MAX;
    return (1.0f - t) * low + t * high;
}
