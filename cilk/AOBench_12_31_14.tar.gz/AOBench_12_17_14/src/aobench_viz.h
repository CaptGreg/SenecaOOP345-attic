// ==============================================================
// 
//  SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT,
//  http:// software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
// 
//  Copyright 2011-2013 Intel Corporation
// 
//  THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
//  NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
//  PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
// 
//  ===============================================================
//
// Partially based on code from Syoyo Fujita: http://code.google.com/p/aobench/
//
// Dynamic-links with code from:
// The FreeType project: http://www.freetype.org/license.html
// Simple DirectMedia Layer: http://www.libsdl.org/index.php
// SDL TrueType font rendering library, from Sam Lantinga: http://www.libsdl.org/projects/SDL_ttf/

#ifndef AOBENCH_VIZ_H
#define AOBENCH_VIZ_H

#include "render.h"

#ifdef _WIN32
#include "sdl.h"
#include "sdl_ttf.h"
#else
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#endif

//Height of font used
static int aobench_text_height = 0;

// Function prototype for the rendering method to be passed to animate()
// Rendering can occur linear/scalar, with cilk_for, with array notation, and with cilk_for + array notation
typedef void (*render_func)(int width, int height, float *fimg);

// Creates the screen for the animation
SDL_Surface *create_output_window();
// Gets the appropriate font from the system fonts for rendering to the screen
TTF_Font* get_display_font(char* s);
// Draws a line of text to the screen based on row/col offset
void draw_text(TTF_Font *font, SDL_Surface *screen, int row, int col, char *text);
// Waits for a keypress
void wait_for_key();
// Clears an entire horizontal line of text based on the row offset
void clear_line_of_text(SDL_Surface *screen, int row);
// Creates images for each calculation of ambient occlusion
// Calls the rendering function and writes results to the screen
// Records the fps at each frame, and returns final average fps
float animate(char *testname, render_func render, TTF_Font *font, SDL_Surface *screen);
// Draws the speedup seen from using different functions for "func"
// Baseline is serial/scalar, comparison with cilk_for, array notation, and cilk_for + array notation
void draw_speedup(float fps, float reference_fps, TTF_Font *font, SDL_Surface *screen, int row, int col);

#endif // AOBENCH_VIZ_H
