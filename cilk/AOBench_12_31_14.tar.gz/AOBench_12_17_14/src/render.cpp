// ==============================================================
// 
//  SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT,
//  http:// software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
// 
//  Copyright 2011-2013 Intel Corporation
// 
//  THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
//  NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
//  PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
// 
//  ===============================================================
//
// Partially based on code from Syoyo Fujita: http://code.google.com/p/aobench/
//
// Dynamic-links with code from:
// The FreeType project: http://www.freetype.org/license.html
// Simple DirectMedia Layer: http://www.libsdl.org/index.php
// SDL TrueType font rendering library, from Sam Lantinga: http://www.libsdl.org/projects/SDL_ttf/

#include "render.h"

#ifdef __INTEL_COMPILER
#include <cilk/cilk.h>
#endif

typedef Vector (*ao_func)(const Intersection * isect);

// Calls ambient occlusion for a single line
// Calculation is either scalar or array notation, based on ao_func
// Writes color to fimg
void render_x(int width, int height, int y, ao_func ao, float *fimg);

// Scalar ambient occlusion calculation
// Returns color of the pixel
Vector ambient_occlusion_scalar(const Intersection *isect);
#ifdef __INTEL_COMPILER
// Pragma simd ambient occlusion calculation
// Returns color of the pixel
Vector ambient_occlusion_simd(const Intersection *isect);
#endif

// The number of sub pixels in the x and y direction
const int c_num_sub_pixels = 2;
// The number of samples to take per sub pixel to derive the color
const int c_num_ao_samples = 8;
// Spheres and plane exist between frames
Sphere spheres[3];
Plane plane;

// Positions the spheres in the scene given the frame number
void init_scene(float frame_num)
{
	spheres[0].center.x = -2.0f + frame_num/5.0f;
	spheres[0].center.y =  0.0f;
	spheres[0].center.z = -3.5f + frame_num/6.0f;
	spheres[0].radius = 0.5f;

	spheres[1].center.x = -0.5f - frame_num/7.0f;
	spheres[1].center.y =  0.0f;
	spheres[1].center.z = -3.0f - frame_num/8.0f;
	spheres[1].radius = 0.5f;

	spheres[2].center.x =  1.0f + frame_num/9.0f;
	spheres[2].center.y =  0.0f;
	spheres[2].center.z = -2.2f + frame_num/10.0f;
	spheres[2].radius = 0.5f;

	plane.point.x = 0.0f;
	plane.point.y = -0.5f;
	plane.point.z = 0.0f;

	plane.normal.x = 0.0f;
	plane.normal.y = 1.0f;
	plane.normal.z = 0.0f;
}

// Description:
// Uses serial for loop to render multiple lines
// Uses scalar methods to render a single line
// [in]: width, height
// [out]: fimg
void render_serial(int width, int height, float *fimg) {
	for (int y = 0; y < height; ++y) {
		render_x(width, height, y, ambient_occlusion_scalar, fimg);
	}
}

#ifdef __INTEL_COMPILER
// Description:
// Uses serial for loop to render multiple lines
// Uses array notation to render a single line with vectorization
// [in]: width, height
// [out]: fimg
void render_vector(int width, int height, float *fimg) {
	for (int y = 0; y < height; ++y) {
		render_x(width, height, y, ambient_occlusion_simd, fimg);
	}
}

// Description:
// Uses cilk_for to render multiple lines in parallel
// Uses scalar methods to render a single line
// [in]: width, height
// [out]: fimg
void render_cilk(int width, int height, float *fimg) {
	cilk_for (int y = 0; y < height; ++y) {
		render_x(width, height, y, ambient_occlusion_scalar, fimg);
	}
}

// Description:
// Uses cilk_for to render multiple lines in parallel
// Uses array notation to render a single line with vectorization
// [in]: width, height
// [out]: fimg
void render_vector_cilk(int width, int height, float *fimg) {
	cilk_for (int y = 0; y < height; ++y) {
		render_x(width, height, y, ambient_occlusion_simd, fimg);
	}
}
#endif // !__INTEL_COMPILER

// Description:
// Calls the ambient occlusion algorithm for each subpixel in a single line
// Ambient occlusion will either be array notation or scalar depending on ao_func
// [in]: width, height, y, ao
// [out]: fimg
void render_x(int width, int height, int y, ao_func ao, float *fimg) {
	// For each pixel in the line,
	for (int x = 0; x < width; ++x) {
		// For each vertical subpixel in the pixel,
		for (int v = 0; v < c_num_sub_pixels; ++v) {
			// For each horizontal subpixel in the pixel,
			for (int u = 0; u < c_num_sub_pixels; ++u) {				
				// Check for visibility by casting a ray from the origin to the screen, and testing for intersection
				Ray ray;
				ray.origin.x = 0.0f;
				ray.origin.y = 0.0f;
				ray.origin.z = 0.0f;

				ray.direction.x = (x + (u / static_cast<float>(c_num_sub_pixels) ) - (width / 2.0f)) / (width / 2.0f);
				ray.direction.y = -(y + (v / static_cast<float>(c_num_sub_pixels) ) - (height / 2.0f)) / (height / 2.0f);
				ray.direction.z = -1.0;
				vnormalize(&(ray.direction));

				Intersection isect;
				isect.magnitude = 1.0e+17f;
				isect.hit = 0;

				ray_sphere_intersect(&ray, &spheres[0], &isect);
				ray_sphere_intersect(&ray, &spheres[1], &isect);
				ray_sphere_intersect(&ray, &spheres[2], &isect);
				ray_plane_intersect(&ray, &plane, &isect);

				// If visible, call ambient occlusion to find the color
				if (isect.hit) {
					Vector color = ao(&isect);
					fimg[3 * (y * width + x) + 0] += color.x;
					fimg[3 * (y * width + x) + 1] += color.y;
					fimg[3 * (y * width + x) + 2] += color.z;
				}
			}
		}

		fimg[3 * (y * width + x) + 0] /= static_cast<float>(c_num_sub_pixels * c_num_sub_pixels);
		fimg[3 * (y * width + x) + 1] /= static_cast<float>(c_num_sub_pixels * c_num_sub_pixels);
		fimg[3 * (y * width + x) + 2] /= static_cast<float>(c_num_sub_pixels * c_num_sub_pixels);
	}	
}

// Description:
// Calculates ambient occlusion of point in scalar
// [in]: isect
// [out]: color of point
Vector ambient_occlusion_scalar(const Intersection *isect) {
	Vector point; 
	float eps = 0.0001f; // offset the ray slightly to avoid error
	point.x = isect->point.x + eps * isect->normal.x;
	point.y = isect->point.y + eps * isect->normal.y;
	point.z = isect->point.z + eps * isect->normal.z;

	Vector basis[3];
	orthoBasis(isect->normal, basis);
	
	int ntheta = c_num_ao_samples;
	int nphi = c_num_ao_samples;
	float occlusion = 0.0f;
	for (int j = 0; j < ntheta; ++j) {
		for (int i = 0; i < nphi; ++i) {
		    float theta = sqrtf(random_table[2*(nphi*j+i)]);
		    float phi = 2.0f * static_cast<float>(M_PI) * random_table[2*(nphi*j+i)+1];


            float x = cos(phi) * theta;
            float y = sin(phi) * theta;
            float z = sqrtf(1.0f - theta * theta);

			float rx = x * basis[0].x + y * basis[1].x + z * basis[2].x;
			float ry = x * basis[0].y + y * basis[1].y + z * basis[2].y;
			float rz = x * basis[0].z + y * basis[1].z + z * basis[2].z;

			Ray ray;
			ray.origin = point;
			ray.direction.x = rx;
			ray.direction.y = ry;
			ray.direction.z = rz;

			Intersection occIsect;
			occIsect.magnitude = 1.0e+17f;
			occIsect.hit = 0;

			ray_sphere_intersect(&ray, &spheres[0], &occIsect); 
			ray_sphere_intersect(&ray, &spheres[1], &occIsect); 
			ray_sphere_intersect(&ray, &spheres[2], &occIsect); 
			ray_plane_intersect(&ray, &plane, &occIsect);

			if (occIsect.hit) {
				occlusion += 1.0f;
			}
		}
	}

	occlusion = (ntheta * nphi - occlusion) / static_cast<float>(ntheta * nphi);
	Vector color;
	color.x = occlusion;
	color.y = occlusion;
	color.z = occlusion;
	return color;
}

#ifdef __INTEL_COMPILER
// Description:
// Calculates ambient occlusion of point using pragma simd
// [in]: isect
// [out]: color of point
Vector ambient_occlusion_simd(const Intersection *isect) {
	Vector point; 
	float eps = 0.0001f; // offset the ray slightly to avoid error
	point.x = isect->point.x + eps * isect->normal.x;
	point.y = isect->point.y + eps * isect->normal.y;
	point.z = isect->point.z + eps * isect->normal.z;

	Vector basis[3];
	orthoBasis(isect->normal, basis);
	
	const int ntheta = c_num_ao_samples;
	const int nphi = c_num_ao_samples;
	float occlusion = 0.0f;
	for (int j = 0; j < ntheta; ++j) {
#pragma simd vectorlength(c_simd_vector_length)
		for (int i = 0; i < nphi; ++i) {
		    float theta = sqrtf(random_table[2*(nphi*j+i)]);
		    float phi = 2.0f * static_cast<float>(M_PI) * random_table[2*(nphi*j+i)+1];


            float x = cos(phi) * theta;
            float y = sin(phi) * theta;
            float z = sqrtf(1.0f - theta * theta);

			float rx = x * basis[0].x + y * basis[1].x + z * basis[2].x;
			float ry = x * basis[0].y + y * basis[1].y + z * basis[2].y;
			float rz = x * basis[0].z + y * basis[1].z + z * basis[2].z;

			Ray ray;
			ray.origin = point;
			ray.direction.x = rx;
			ray.direction.y = ry;
			ray.direction.z = rz;

			Intersection occIsect;
			occIsect.magnitude = 1.0e+17f;
			occIsect.hit = 0;

			ray_sphere_intersect(&ray, &spheres[0], &occIsect); 
			ray_sphere_intersect(&ray, &spheres[1], &occIsect); 
			ray_sphere_intersect(&ray, &spheres[2], &occIsect); 
			ray_plane_intersect(&ray, &plane, &occIsect);

			if (occIsect.hit) {
				occlusion += 1.0f;
			}
		}
	}

	occlusion = (ntheta * nphi - occlusion) / static_cast<float>(ntheta * nphi);
	Vector color;
	color.x = occlusion;
	color.y = occlusion;
	color.z = occlusion;
	return color;
}
#endif // !__INTEL_COMPILER
