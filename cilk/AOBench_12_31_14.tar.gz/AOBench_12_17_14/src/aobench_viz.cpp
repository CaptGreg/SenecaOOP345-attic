// ==============================================================
// 
//  SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT,
//  http:// software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
// 
//  Copyright 2011-2013 Intel Corporation
// 
//  THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
//  NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
//  PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
// 
//  ===============================================================
//
// Partially based on code from Syoyo Fujita: http://code.google.com/p/aobench/
//
// Dynamic-links with code from:
// The FreeType project: http://www.freetype.org/license.html
// Simple DirectMedia Layer: http://www.libsdl.org/index.php
// SDL TrueType font rendering library, from Sam Lantinga: http://www.libsdl.org/projects/SDL_ttf/

#include "aobench_viz.h"
#include <cstring>

#ifdef __INTEL_COMPILER
#include <cilk/cilk.h>
#endif

#include "timer.h"

// If set to 0, disables the animation (just show a static image)
// Calculation still occurs, but there is no rendering to the screen
const int aobench_is_animated = 1;

// Current text-drawing position.
static int aobench_text_cursor_row = 0;
static int aobench_text_cursor_col = 0;

// There is no portable means of writing formatted strings to a buffer
// A different function must be used for Windows and Linux
#ifdef _WIN32
#define snprintf(str, size, format, ...) sprintf_s<size>(str, format, __VA_ARGS__);
#endif


// Renders a frame to fimg
inline void render_scene(int movement, render_func render, int fimg_width, int fimg_height, float *fimg);
// Draws a rectangle to the screen based on offsets
// Will not overwrite the first aobench_text_height pixels so that labels are not overwritten
void draw_buffer(SDL_Surface *surface, int offset_row, int offset_col, float *fimg, int width, int height);
// Converts a float representation of a color to a uint8
inline Uint8 clamp(float f);
// Draws the fps to the screen every frame
inline void draw_fps(float fps, char *testname, TTF_Font *font, int offset_row, int offset_col, SDL_Surface *screen);
// Drains the event queue which prevents the screen from hanging
void handle_events();


// Description: 
// Creates the window for the animation
// Exits if monitor is not at least 768x768
SDL_Surface *create_output_window() {
	const SDL_VideoInfo* videoinfo = SDL_GetVideoInfo();
	SDL_putenv("SDL_VIDEO_WINDOW_POS");
	SDL_putenv("SDL_VIDEO_CENTERED=1");
	SDL_Surface *screen;
	screen = SDL_SetVideoMode(768, 768, 32, SDL_HWSURFACE);

	if (!screen) {
		fprintf(stderr, "Can't create the video window!\n");
		exit(-1);
	}
	return screen;
}

// Description:
// Returns a system font (Windows Arial, Linux FreeMonoBold)
// Exits if the font cannot be loaded
TTF_Font* get_display_font(char* s) {
	TTF_Font *font;
	char fontpath[1024];
#ifdef _WIN32
	sprintf(fontpath, "%s\\fonts\\arial.ttf", getenv("SystemRoot"));
#elif defined __APPLE__
    sprintf(fontpath, "/Library/Fonts/Arial Narrow.ttf");
#else // Linux
	sprintf(fontpath, "%s", s);
#endif
	font = TTF_OpenFont(fontpath, 24);
	if (font == NULL) {
		fprintf(stderr, "Error: font location not valid: %s\n\
    On Linux, please set FONT_LOCATION to a valid .ttf font, most likely located inside /usr/share/fonts.\n\
    On windows, make sure [SystemRoot]\\fonts\\arial.ttf exists.\n\
    On OS X, make sure \"/Library/Fonts/Arial Narrow.ttf\" exists.\n", fontpath); 
		exit(-1); 
	}

	aobench_text_cursor_row = 0;
	aobench_text_cursor_col = 0;
	aobench_text_height = 0;
	aobench_text_height = TTF_FontHeight(font);
	return font;
}

// Description:
// Draws text at the given position
// If row or col are -1, this will draw to the previous position
void draw_text(TTF_Font *font, SDL_Surface *screen, int row, int col, char *text) {
	SDL_Surface *text_surface;
	SDL_Rect text_rect;
	SDL_Color textColor = { 255, 255, 255 }; // white

	if (row == -1) {
		row = aobench_text_cursor_row;
	}
	else {
		aobench_text_cursor_row = row;
	}
	if (col == -1) {
		col = aobench_text_cursor_col;
	}
	else {
		aobench_text_cursor_col = col;
	}

	text_surface = TTF_RenderText_Solid(font, text, textColor);
	text_rect.h = text_surface->h;
	text_rect.w = text_surface->w;
	text_rect.x = col;
	text_rect.y = row;
	SDL_BlitSurface(text_surface, NULL, screen, &text_rect);
	SDL_FreeSurface(text_surface);
	SDL_UpdateRect(screen, col, row, text_rect.w, text_rect.h);
	aobench_text_cursor_row += text_rect.h;
	aobench_text_cursor_col += text_rect.w;
}

// Description:
// Uses SDL to determine when the user has pressed a key
// A keypress is denoted either by the event type enums SDL_KEYDOWN or SDL_QUIT
void wait_for_key() {	
	int keypress = 0;
	SDL_Event event;
	while(!keypress)
    {
         while(SDL_PollEvent(&event))
         {
              switch (event.type)
              {
                  case SDL_QUIT:
                      keypress = 1;
                      break;
                  case SDL_KEYDOWN:
                       keypress = 1;
                       break;
              }
         }
    }
}

// Description:
// Clears a line of text
void clear_line_of_text(SDL_Surface *screen, int row) {
	SDL_Rect line_on_screen;
	line_on_screen.h = aobench_text_height;
	line_on_screen.w = screen->w;
	line_on_screen.x = 0;
	line_on_screen.y = row;
	SDL_Color blank = { 0, 0, 0 }; //black
	SDL_FillRect(screen, &line_on_screen, SDL_MapRGB(screen->format, 0, 0, 0));
	SDL_UpdateRect(screen, line_on_screen.x, line_on_screen.y, line_on_screen.w, line_on_screen.h);
}

// Description:
// Sets up the buffer fimg for coloring in
// Renders the scene to fimg, method will vary based on "func"
// "func" can be serial/scalar, use cilk_for, use array notation, or use cilk_for + array notation
// Draws the scene to the screen
// Calculates frames per second
// [in]: testname, render, font, screen
// [out]: fps
float animate(char *testname, render_func render, TTF_Font *font, SDL_Surface *screen) {
	//
	int fimg_width = screen->w/2;
	int fimg_height = screen->h/2;
	float *fimg = (float *)_mm_malloc(sizeof(float) * fimg_width * fimg_height * 3, 64);

	// Make sure: (first value - 1) % 10 == 0
	int frames = (aobench_is_animated) ? 41 : 1;
	int frameskip = 0;
	int offset_row = 0;
	int offset_col = 0;
	if(!strcmp(testname, "Serial scalar")) {
		frameskip = 3;
	}
	else if(!strcmp(testname, "Serial SIMD")) {
		frameskip = 4;
		offset_col = fimg_width;
	}
	else if(!strcmp(testname, "cilk_for scalar")) {
		frameskip = 1;
		offset_row = fimg_height;
	}
	else if(!strcmp(testname, "cilk_for SIMD")) {
		frameskip = 1;
		offset_row = fimg_width;
		offset_col = fimg_height;
	}

	int num_frames = 0;
	double total_time = 0;
	float fps = 0;
	CUtilTimer timer;
	for (int frame_num = 0; frame_num < frames; frame_num += frameskip+1) {
		timer.start();
		render_scene((frame_num > frames/2) ? frames - frame_num : frame_num, 
			render, fimg_width, fimg_height, fimg);
		draw_buffer(screen, offset_row, offset_col, fimg, fimg_width, fimg_height);
		timer.stop();
		total_time += timer.get_time();
		fps = static_cast<float>(++num_frames) / total_time;
		draw_fps(fps, testname, font, offset_row, offset_col, screen);
		handle_events();
	}
	return fps;
}

// Draw the FPS speedup (fps/reference_fps) to the SDL screen
void draw_speedup(float fps, float reference_fps, TTF_Font *font, SDL_Surface *screen, int row, int col) {
	printf("%.2f X\n", fps/reference_fps);
	char buf[80];
	//sprintf_s<80>(buf, "%.2f X", fps/reference_fps);
	snprintf(buf, 80, "%.2f X", fps/reference_fps);
	draw_text(font, screen, row, col, buf);
	SDL_Delay(10);
}

// Description:
// Clears fimg and sets up the scene
// Calls the render function
inline void render_scene(int movement, render_func render, int fimg_width, int fimg_height, float *fimg) {

	memset(fimg, 0, 3 * fimg_width * fimg_height * sizeof(float));
	init_scene(movement);
	render(fimg_width, fimg_height, fimg);
}

// Description:
// Draw the contents of fimg to the screen, starting at screen->pixels[offset_row][offset_col].
// width and height are the dimensions of fimg.
void draw_buffer(SDL_Surface *screen, int offset_row, int offset_col, float *fimg, int width, int height) {
	if(SDL_MUSTLOCK(screen)) {
		if(SDL_LockSurface(screen) < 0) return;
	}

// WARNING: Assumes 32bpp aarrggbb format. If this doesn't work, set to 0
#define FAST_32BPP_AARRGGBB_FORMAT 0
#if FAST_32BPP_AARRGGBB_FORMAT && __INTEL_COMPILER
	for (int y = 0; y < height; ++y) {
		for (int x = 0; x < width; x += c_simd_vector_length) { // x is pixels, not array elements of fimg
			Uint8 clamped[c_simd_vector_length*3];
			Uint32 color[c_simd_vector_length];
			int img_index = 3*(y*width+x);
			clamped[:] = clamp(fimg[img_index:c_simd_vector_length*3]); // contains c_simd_vector_length 8-bit r g b r g b... triplets
			color[:] = clamped[0:c_simd_vector_length:3] << 16 | clamped[1:c_simd_vector_length:3] << 8 | clamped[2:c_simd_vector_length:3];
			Uint32 *pixels;
			pixels = (Uint32*)screen->pixels + (y+offset_row)*(screen->w) + x + offset_col;
			pixels[0:c_simd_vector_length] = color[:];
		}
	}
#else
	// slower method, but safe
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			Uint8 r = clamp(fimg[3 * (y*width + x)]);
			Uint8 g = clamp(fimg[(3 * (y*width + x)) + 1]);
			Uint8 b = clamp(fimg[(3 * (y*width + x)) + 2]);
			Uint32 color = SDL_MapRGB(screen->format, r, g, b);
			*((Uint32*)screen->pixels + (y+offset_row)*(screen->w) + x + offset_col) = color;
		}
	}
#endif
	if(SDL_MUSTLOCK(screen)) {
		SDL_UnlockSurface(screen);
	}
	SDL_UpdateRect(screen, offset_col, offset_row + aobench_text_height, width, height - aobench_text_height);
}

// Converts float representation of color to int
inline unsigned char clamp(float f) {
	int i = static_cast<int>(f * 255.5);
	if (i < 0) {
		i = 0;
	}
	else if (i > 255) {
		i = 255;
	}
	return static_cast<Uint8>(i);
}

// Description:
// draws the fps to the screen
inline void draw_fps(float fps, char *testname, TTF_Font *font, int offset_row, int offset_col, SDL_Surface *screen) {
	//sprintf_s<80>(buf, "%s:%.2f frames/sec", testname, fps);
	char buf[80];
	snprintf(buf, 80, "%s: %.2f frames/sec", testname, fps);
	draw_text(font, screen, offset_row, offset_col, buf);
}

// Description:
// Drain the event queue
// If this is not done, the window will hang if it is moved/minimized/etc
void handle_events() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_QUIT) {
			SDL_Quit();
			TTF_Quit();
			exit(0);
		}
		//if there is any keypress, quit the animation
		else if (event.type == SDL_KEYDOWN) {
			SDL_Quit();
			TTF_Quit();
			exit(0);
		}
	}
}
