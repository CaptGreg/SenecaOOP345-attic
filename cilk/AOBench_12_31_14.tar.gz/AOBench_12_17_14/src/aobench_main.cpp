// ==============================================================
// 
//  SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT,
//  http:// software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
// 
//  Copyright 2011-2013 Intel Corporation
// 
//  THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
//  NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
//  PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
// 
//  ===============================================================
//
// Partially based on code from Syoyo Fujita: http://code.google.com/p/aobench/
//
// Dynamic-links with code from:
// The FreeType project: http://www.freetype.org/license.html
// Simple DirectMedia Layer: http://www.libsdl.org/index.php
// SDL TrueType font rendering library, from Sam Lantinga: http://www.libsdl.org/projects/SDL_ttf/

#include <cstdio>

#ifdef __INTEL_COMPILER
#include <cilk/cilk.h>
#endif

#include "aobench_viz.h"
#include <string>

// Prints whether same image is rendered for serial (baseline) and Intel® Cilk™ Plus (test case) implementations
// returns 1 if passed
bool verify(float *fimg_serial, float *fimg_vec, int width, int height) {
    float sumError2 = 0;
    for (unsigned int i = 0; i < 3 * width * height; ++i) {
        float err = fabsf(fimg_serial[i] - fimg_vec[i]);
        sumError2 += err*err;
    }

    float error = sqrtf(sumError2/(3*width*height));
    printf("%s: RMS error = %.3f\n", error < .025 ? "PASSED" : "FAILED", error);
	return (error < .025);
}

int main(int argc, char *argv[]) {
	SDL_Surface *screen = create_output_window(); // Exits if it can't create the video window.
	TTF_Init();
	SDL_Init(SDL_INIT_VIDEO);
#if defined(_WIN32) || defined(__APPLE__)
	TTF_Font *font = get_display_font(""); // Exits if the font can't be loaded.	
#else // Linux
	TTF_Font *font = get_display_font(argv[argc-1]); // Exits if the font can't be loaded.	
#endif
	
#ifdef __INTEL_COMPILER
//#define PERF_NUM
#ifdef PERF_NUM
	int option=0;
#else
	int option;
	// Checks to see if option was given at command line
#if !defined(_WIN32) && !defined(__APPLE__)
	if(argc>2) {
#else
	if(argc>1) {
#endif
		// If help requested, print out instructions and quit
		if(argv[1][0] == 'h') {
			printf("This example calculates ambient occlusion for 3 spheres and a plane to simulate light in a room with non-reflective objects. Pick which parallel method you would like to use.\n");
			printf("[0] all calculations\n[1] serial/scalar\n[2] serial/SIMD\n[3] cilk_for/scalar\n[4] cilk_for/SIMD\n");
#ifdef _WIN32
			system("PAUSE");
#endif
			return 0;
		}
		else {
			option = atoi(argv[1]);
		}
	}
	// If no options are given, prompt user to choose an option
	else {
		printf("This example calculates ambient occlusion for 3 spheres and a plane to simulate light in a room with non-reflective objects. Pick which parallel method you would like to use.\n");
		printf("[0] all calculations\n[1] serial/scalar\n[2] serial/SIMD\n[3] cilk_for/scalar\n[4] cilk_for/SIMD\n  > ");
		scanf("%i", &option);
	}
#endif // PERF_NUM

	// Load up the Intel® Cilk™ Plus runtime to to get accurate performance numbers
	double g = 2.0;
	cilk_for (int i = 0; i < 100; i++) {
			g /= sin(g);
	}
#endif // __INTEL_COMPILER
	
	clear_line_of_text(screen, 0);

	float serial_fps=0, vec_fps=0, cilk_fps=0, cilk_vec_fps=0;
#ifndef __INTEL_COMPILER
#ifdef PERF_NUM
	float avgfps = 0;
	for(int i=0; i<5; ++i) {
#endif
	serial_fps = animate("Serial scalar", render_serial, font, screen);
	printf("serial/scalar fps: %.2f\n", serial_fps);
	draw_speedup(serial_fps, serial_fps, font, screen, -1, 0);
#ifdef PERF_NUM
	avgfps += serial_fps;
	}
	printf("avg fps: %.2f\n", avgfps/5);
#endif
#else
	switch(option) {
	case 0:
#ifdef PERF_NUM
		float avgfps[4];
		avgfps[:] = 0;
		for(int i=0; i<5; ++i) {
#endif
		printf("Running all tests:\n");

		serial_fps = animate("Serial scalar", render_serial, font, screen);
		printf("serial/scalar fps: %.2f\n", serial_fps);
		draw_speedup(serial_fps, serial_fps, font, screen, -1, 0);

		vec_fps = animate("Serial SIMD", render_vector, font, screen);
		printf("serial/SIMD fps: %.2f\n", vec_fps);
		draw_speedup(vec_fps, serial_fps, font, screen, -1, screen->w/2);

		cilk_fps = animate("cilk_for scalar", render_cilk, font, screen);
		printf("cilk_for/scalar fps: %.2f\n", cilk_fps);
		draw_speedup(cilk_fps, serial_fps, font, screen, -1, 0);

		cilk_vec_fps = animate("cilk_for SIMD", render_vector_cilk, font, screen);
		printf("cilk_for/SIMD fps: %.2f\n", cilk_vec_fps);
		draw_speedup(cilk_vec_fps, serial_fps, font, screen, -1, screen->w/2);
		
#ifdef PERF_NUM
		avgfps[0] += serial_fps;
		avgfps[1] += vec_fps;
		avgfps[2] += cilk_fps;
		avgfps[3] += cilk_vec_fps;
		
		}
		printf("avg fps: %.2f\n", avgfps[:]/5);
#endif
		break;
	case 1:
		serial_fps = animate("Serial scalar", render_serial, font, screen);
		printf("serial/scalar fps: %.2f\n", serial_fps);
		break;
	case 2:
		vec_fps = animate("Serial SIMD", render_vector, font, screen);
		printf("serial/SIMD fps: %.2f\n", vec_fps);
		break;
	case 3:
		cilk_fps = animate("cilk_for scalar", render_cilk, font, screen);
		printf("cilk_for/scalar fps: %.2f\n", cilk_fps);
		break;
	case 4:
		cilk_vec_fps = animate("cilk_for SIMD", render_vector_cilk, font, screen);
		printf("cilk_for/SIMD fps: %.2f\n", cilk_vec_fps);
		break;
	default:
		printf("Please pick a valid option\n");
		break;
	}
#endif // __INTEL_COMPILER

#ifdef __CMDLINE_TEST
#ifdef _WIN32
	system("pause");
#endif
#else
	wait_for_key();
#endif

	SDL_Quit();
	TTF_Quit();

    return 0;
}
