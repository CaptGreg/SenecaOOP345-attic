// ==============================================================
// 
//  SAMPLE SOURCE CODE - SUBJECT TO THE TERMS OF SAMPLE CODE LICENSE AGREEMENT,
//  http:// software.intel.com/en-us/articles/intel-sample-source-code-license-agreement/
// 
//  Copyright 2011-2013 Intel Corporation
// 
//  THIS FILE IS PROVIDED "AS IS" WITH NO WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT
//  NOT LIMITED TO ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
//  PURPOSE, NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS.
// 
//  ===============================================================
//
// Partially based on code from Syoyo Fujita: http://code.google.com/p/aobench/
//
// Dynamic-links with code from:
// The FreeType project: http://www.freetype.org/license.html
// Simple DirectMedia Layer: http://www.libsdl.org/index.php
// SDL TrueType font rendering library, from Sam Lantinga: http://www.libsdl.org/projects/SDL_ttf/

#ifndef RENDER_H
#define RENDER_H

#include "aobench_math.h"

const int c_simd_vector_length = 8;

// Sets the scene at the beginning of each frame
// Position of spheres will change based on frame_num
void init_scene(float frame_num);
// Runs ambient occlusion render using strictly linear, scalar methods
// Calls render_x using a for loop, and passes it the scalar ao function pointer
void render_serial(int width, int height, float *fimg);
// Runs ambient occlusion render using linear, array notation methods
// Calls render_x using a for loop, and passes it the array notation ao function pointer
void render_vector(int width, int height, float *fimg);
// Runs ambient occlusion render using cilk_for, scalar methods
// Calls render_x using a cilk_for loop, and passes it the scalar ao function pointer
void render_cilk(int width, int height, float *fimg);
// Runs ambient occlusion render using cilk_for, array notation methods
// Calls render_x using a cilk_for loop, and passes it the array notation ao function pointer
void render_vector_cilk(int width, int height, float *fimg);

#endif // RENDER_H
