# sandstorm-accounts-ui

A merging of meteor's accounts-ui/accounts-ui-unstyled.

This is meant to be a stopgap until we come up with a better design for login.
