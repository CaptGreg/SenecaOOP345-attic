this.simplesmtp = Npm.require("simplesmtp");
this.MailParser = Npm.require("mailparser").MailParser;
this.mimelib = Npm.require("mimelib");
this.MailComposer = Npm.require("mailcomposer").MailComposer;
