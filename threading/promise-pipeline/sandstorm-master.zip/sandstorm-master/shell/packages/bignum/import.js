this.Bignum = Npm.require("bignum");
