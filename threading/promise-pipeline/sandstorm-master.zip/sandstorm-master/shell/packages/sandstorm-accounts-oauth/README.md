# accounts-oauth

Common functionality for OAuth-based login services. See the [project page](https://www.meteor.com/accounts) on Meteor Accounts for more details.