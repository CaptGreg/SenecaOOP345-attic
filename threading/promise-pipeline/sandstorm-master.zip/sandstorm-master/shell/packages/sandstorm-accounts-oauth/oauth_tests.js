// XXX Add a test to ensure that successful logins call Accounts.updateOrCreateUserFromExternalService
// XXX Add a test to ensure that a missing or failed loginResult is handled correctly
