#! /usr/bin/env bash

set -euo pipefail

echo "This script is no longer needed. Go ahead and run autoreconf. For example:"
echo "  autoreconf -i && ./configure && make -j6 check && sudo make install"
